package member.service;

import member.dao.MemberDao;
import member.dao.MemberDaoImpl;
import member.dto.Group;
import member.dto.Member;
import member.dto.MemberAndClass;

public class MemberServiceImpl implements MemberService{

	private MemberDao memberDao = new MemberDaoImpl();
	
	
	@Override
	public boolean login(Member member) {
		int cnt = memberDao.login(member);
		if(cnt > 0) {
			return true;
		} 
		else {
			return false;
		}
	}
	
	@Override
	public String getName(Member member) {
		
		return memberDao.selectName(member);
	}

	@Override
	public boolean join(Member member) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public MemberAndClass getInformation(String id) {
		return memberDao.Info(id);
	}

	@Override
	public boolean updateMember(Member member) {
		int n = memberDao.update(member);
		if(n > 0) {
			return true;
		}
		else {
			return false;
		}
		
	}

	@Override
	public boolean insertClass(Group group) {
		int n = memberDao.insertClass(group);
		if(n>0) {
			return true;
		}
		else {
			return false;
		}
		
		
	}

	@Override
	public MemberAndClass getMyPageInformation(String id) {
		
		return memberDao.myPageInfo(id);
	}

	@Override
	public Member getMemberInformation(String id) {
		
		return memberDao.MemberInfo(id);
	}

	@Override
	public String getPassword(String id) {
		
		return memberDao.userPassword(id);
	}

	@Override
	public Member searchPassword(String id, String name, String email) {
		
		return memberDao.passwordSearch(id, name, email);
	}

	@Override
	public boolean changePassword(String pw, String id, String name, String email) {
		
		int n = memberDao.changePassword(pw, id, name, email);	
		
		System.out.println("-----"+n);
		if(n>0) {
			return true;
		}
		else {
			return false;
		}
		
	}

	


}
