package board.board.Sharecontroller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import board.dto.Board;
import board.dto.Upload;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/share/update.do")
public class ShareUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BoardService boardService = new BoardServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		String param = request.getParameter("boardno");
		
		int boardno=0;
		if(!"".equals(param) && param != null) {
			boardno = Integer.parseInt(param);
		}
		
		Board board = new Board();
		board.setBoardno(boardno);
		
		board = boardService.view(board);
		
		// 첨부 파일 정보
		List<Upload> result = boardService.getUpFile(board); 
		request.setAttribute("fileList", result);
				
		request.setAttribute("board", board);
		
		request.getRequestDispatcher("/view/board.share/update.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		ServletContext context = getServletContext();
		String saveDirectory = context.getRealPath("upload");
		int maxPostSize = 10 * 1024 * 1024; //10MB
		String encoding = "UTF-8";
		FileRenamePolicy policy
			= new DefaultFileRenamePolicy();
		MultipartRequest mul = new MultipartRequest(
				request,
				saveDirectory,
				maxPostSize,
				encoding,
				policy );
		
		Board board = new Board();
		board.setBoardno(Integer.parseInt(mul.getParameter("boardno")));
		board.setTitle((String)mul.getParameter("title"));
		board.setContent(mul.getParameter("content"));
		board.setWriter((String) mul.getParameter("writer")); 
		
		File uploadFile = mul.getFile("file");
		
		if(uploadFile == null || !uploadFile.exists()) {
			
			boardService.update(board);
			
		} else {
			Upload file = new Upload();
			file.setBoardno(board.getBoardno());
			file.setBefore(mul.getOriginalFileName("file"));
			file.setAfter(mul.getFilesystemName("file"));
			
			boardService.fileUpdate(file, board);
		}
		
		
		// 리다이렉트
		response.sendRedirect("/share/view.do?boardno=" + board.getBoardno());
	}

}
