package board.service;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public class BoardServiceImpl implements BoardService {

	@Override
	public List<Board> getList(String boardType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotal(String boardType) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Board> getPagingList(Paging paging) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertBoard(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Board view(int boardNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean recommend(Board recommendBoard) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int recommendCnt(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean uploadFile() {
		// TODO Auto-generated method stub
		return false;
	}
	
}
