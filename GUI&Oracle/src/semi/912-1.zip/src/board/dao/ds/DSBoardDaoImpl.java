package board.dao.ds;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.Board;
import board.dto.BoardFile;
import board.dto.Comment;
import board.util.Paging;

public class DSBoardDaoImpl implements DSBoardDao{

	//멤버필드
	private Connection conn = DBConn.getConnection();
	private Statement st = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	@Override
	public int boardAllCntByTitle(Paging paging) {
		String sql = "SELECT count(*) FROM board Where title Like ?"
				+ " AND boardtype='DS' AND enable=1";	
		
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			 search="%"+search +"%";
		}else {
			search="%%";
		}
		
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return cnt;
	}

	@Override
	public int boardAllCntByBoardNo(Paging paging) {
		
		String sql = "SELECT count(*) FROM board Where boardno Like ?"
				+ " AND boardtype='DS' AND enable=1";	
		
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			 search="%"+search +"%";
		}else {
			search="%%";
		}
		
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return cnt;
	}
	
	@Override
	public int boardAllCntByWriter(Paging paging) {
	
		String sql = "SELECT count(*) FROM board Where writer Like ?"
				+ " AND boardtype='DS' AND enable=1";	
		
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			 search="%"+search +"%";
		}else {
			search="%%";
		}
		
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return cnt;
	}

	@Override
	public int boardAllCntByWriterId(Paging paging) {
		
		String sql = "SELECT count(*) FROM board Where writerid Like ?"
				+ " AND boardtype='DS' AND enable=1";	
		
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			 search="%"+search +"%";
		}else {
			search="%%";
		}
		
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return cnt;
	}

	@Override
	public List<Board> boardAllListByTitle(Paging paging) {
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE boardtype='DS' AND enable=1 AND title LIKE ?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<Board> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, paging.getStartNo() );
			ps.setInt(3, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));

				//추천수 넣기
				int recommend = this.recommendCntByBoardNo(board);
				board.setRecommend(recommend);
				
				//댓글수 넣기
				int commentCnt = this.commentCntByBoardNo(board);
				board.setCommentCnt(commentCnt);
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}

	@Override
	public List<Board> boardAllListByBoardNo(Paging paging) {
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE boardtype='DS' AND enable=1 AND boardno LIKE ?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<Board> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, paging.getStartNo() );
			ps.setInt(3, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));

				//추천수 넣기
				int recommend = this.recommendCntByBoardNo(board);
				board.setRecommend(recommend);
				
				//댓글수 넣기
				int commentCnt = this.commentCntByBoardNo(board);
				board.setCommentCnt(commentCnt);
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}
	
	@Override
	public List<Board> boardAllListByWriter(Paging paging) {
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE boardtype='DS' AND enable=1 AND writer LIKE ?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<Board> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, paging.getStartNo() );
			ps.setInt(3, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));

				//추천수 넣기
				int recommend = this.recommendCntByBoardNo(board);
				board.setRecommend(recommend);
				
				//댓글수 넣기
				int commentCnt = this.commentCntByBoardNo(board);
				board.setCommentCnt(commentCnt);
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}

	@Override
	public List<Board> boardAllListByWriterId(Paging paging) {
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE boardtype='DS' AND enable=1 AND writerid LIKE ?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<Board> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, paging.getStartNo() );
			ps.setInt(3, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));

				//추천수 넣기
				int recommend = this.recommendCntByBoardNo(board);
				board.setRecommend(recommend);
				
				//댓글수 넣기
				int commentCnt = this.commentCntByBoardNo(board);
				board.setCommentCnt(commentCnt);
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return boardList;
	}


	@Override
	public int insertBoard(Board board) {
		String sql = "INSERT INTO board(boardno,writerid,writer,title,content,boardtype)"
				+ "	VALUES(?,?,?,?,?,'DS')";
		int res = 0;
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardNo());
			ps.setString(2, board.getWriterId());
			ps.setString(3, board.getWriter());
			ps.setString(4, board.getTitle());
			ps.setString(5, board.getContent());
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
				try {
					if(ps!=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return res;
	}

	@Override
	public Board viewBoard(Board board) {
		int boardNo = board.getBoardNo();
		String sql = "SELECT * FROM BOARD WHERE boardno = ?";
		
		Board viewBoard = new Board();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			ResultSet rs = ps.executeQuery();
			
			rs.next();
						
			viewBoard.setBoardNo(rs.getInt("boardno"));
			viewBoard.setWriterId(rs.getString("writerid"));
			viewBoard.setWriter(rs.getString("writer"));
			viewBoard.setTitle(rs.getString("title"));
			viewBoard.setContent(rs.getString("content"));
			viewBoard.setHit(rs.getInt("hit"));
			viewBoard.setBoardType(rs.getString("boardtype"));
			viewBoard.setInDate(rs.getString("indate"));

			//추천수 넣기
			int recommend = this.recommendCntByBoardNo(viewBoard);
			viewBoard.setRecommend(recommend);
			
			//댓글수 넣기
			int commentCnt = this.commentCntByBoardNo(board);
			board.setCommentCnt(commentCnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return viewBoard;
	}

	@Override
	public boolean selectRecommendById(Board board) {
		int boardNo = board.getBoardNo();
		String writerId = board.getWriterId();		
		String sql="SELECT count(*) FROM board_recommend WHERE boardno=? AND id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			ps.setString(2, writerId);
			rs = ps.executeQuery();
			rs.next();
			
			if(rs.getInt(1)>0) return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}	
		return false;
	}

	@Override
	public List<Comment> commentList(Board board) {
		
		int boardNo = board.getBoardNo();
		String sql = "SELECT * FROM COMMENTS WHERE boardno=? ORDER BY commentno";
		List<Comment> list = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();	
			
			while(rs.next()) {
				Comment comment = new Comment();
			
				comment.setCommentNo(rs.getInt(1));
				comment.setBoardNo(rs.getInt(2));
				comment.setWriterId(rs.getString(3));
				comment.setWriter(rs.getString(4));
				comment.setInDate(rs.getString(5));
				comment.setContent(rs.getString(6));
				
				list.add(comment);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}		
		return list;
	}

	@Override
	public int updateBoard(Board board) {
		
		String sql= "UPDATE board SET title=?, content=?, inDate=sysdate WHERE boardno=? ";
		
		String title = board.getTitle();
		String content = board.getContent();
		int boardNo = board.getBoardNo();
		
		int res = 0;
		
		try {
			ps= conn.prepareStatement(sql);
			ps.setString(1, title);
			ps.setString(2, content);
			ps.setInt(3, boardNo);
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null)ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
				
		return res;
	}

	@Override
	public void addHit(Board board) {
		
		int boardNo = board.getBoardNo();
		String sql ="UPDATE board SET hit=hit+1 WHERE boardno=?"; 
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		if(res>0)System.out.println("조회수 +1 상승");
		
	}

	@Override
	public int recommendAllDeleteByBoardNo(Board board) {
	
		int boardNo = board.getBoardNo();
		String sql = "DELETE FROM board_recommend WHERE boardno=?";
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null)ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	@Override
	public int commentsAllDeleteByBoardNo(Board board) {
		
		int boardNo = board.getBoardNo();
		String sql = "DELETE FROM comments WHERE boardno = ?";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null)ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	@Override
	public int filesAllDeleteByBoardNo(Board board) {
		
		int boardNo = board.getBoardNo();
		String sql = "DELETE FROM upload WHERE boardno = ?";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null)ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	@Override
	public int deleteBoard(Board board) {
		
		int boardNo = board.getBoardNo();
		String sql = "UPDATE board SET enable = 0 WHERE boardno=?";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return res;
	}

	@Override
	public int insertRecommend(Board board) {
		int boardNo = board.getBoardNo();
		String writerId = board.getWriterId();
		
		String sql = "INSERT INTO board_recommend values(?,?)";
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			ps.setString(2, writerId);
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}				
		return res;	
	}

	@Override
	public int deleteRecommend(Board board) {
		
		int boardNo = board.getBoardNo();
		String writerId = board.getWriterId();
		
		String sql = "DELETE FROM board_recommend WHERE boardno=? AND id=?";
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			ps.setString(2, writerId);
			res = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return res;
	}

	@Override
	public int insertComment(Comment comment) {
		
		String sql = "INSERT INTO comments(commentno,boardno,writerid,writer,content) "
				+ "VALUES(comments_seq.nextVal,?,?,?,?)";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getBoardNo());
			ps.setString(2, comment.getWriterId());
			ps.setString(3, comment.getWriter());
			ps.setString(4, comment.getContent());
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	@Override
	public int deleteComment(Comment comment) {
		
		String sql = "DELETE FROM comments WHERE commentno=?";
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getCommentNo());
			
			res = ps.executeUpdate();
					
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return res;
	}
	
	@Override
	public int recommendCntByBoardNo(Board board) {
		int boardno = board.getBoardNo();
		
		String sql = "SELECT count(*) FROM board_recommend "
				+ "WHERE boardno=?";
		int cnt=0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardno);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return cnt;
	}

	@Override
	public int uploadBoardNo() {
		String sql = "SELECT board_seq.nextVal FROM dual";
		int boardNo = 0;
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			rs.next();
			boardNo = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(st!=null) st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return boardNo;
	}

	@Override
	public int insertFile(BoardFile file) {
		
		String sql = "INSERT INTO upload values(upload_seq.nextval,?,?,?,?,sysdate)";
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, file.getBoardNo());
			ps.setString(2, file.getBefore());
			ps.setString(3, file.getAfter());
			ps.setInt(4, file.getFileSize());
			
			res = ps.executeUpdate();
				
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return res;
	}

	@Override
	public List<BoardFile> fileList(Board board) {
		
		int boardNo = board.getBoardNo();
		String sql = "SELECT * FROM upload WHERE boardno=? ORDER BY fileno";
		List<BoardFile> list = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();	
			
			while(rs.next()) {
				BoardFile file = new BoardFile();
			
				file.setFileNo(rs.getInt(1));
				file.setBoardNo(rs.getInt(2));
				file.setBefore(rs.getString(3));
				file.setAfter(rs.getString(4));
				file.setFileSize(rs.getInt(5));
				file.setDate(rs.getString(6));
				
				list.add(file);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}		
		return list;
	}

	@Override
	public int commentCntByBoardNo(Board board) {
		
		int boardNo = board.getBoardNo();
		
		String sql = "SELECT count(*) FROM comments WHERE boardno=?";
				
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			ResultSet rs = ps.executeQuery();
					
			rs.next();
			cnt = rs.getInt(1);
					
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		
		return cnt;
	}
	
}
