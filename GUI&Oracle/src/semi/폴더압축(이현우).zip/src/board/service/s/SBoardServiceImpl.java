package board.service.s;

import java.util.List;

import board.dao.s.SBoardDaoImpl;
import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public class SBoardServiceImpl implements SBoardService {
	
	SBoardDaoImpl boardDao = new SBoardDaoImpl();
	
	@Override
	public int getAllCnt(PagingModel paging) {
		int level = paging.getLevel();
		String word = paging.getWord();
		String answer = paging.getAnswer();
		int cnt = 0;
		
		if(answer.equals("on")) {		
			cnt = boardDao.boardAllCntByAnswer(paging);
		}else if(level == 0) {
			cnt = boardDao.boardAllCntMsgFromByTitle(paging);	
		}else {
			if(word.equals("writer")) {
				cnt = boardDao.boardAllCntMsgToByWriter(paging);
			}else if(word.equals("writerid")) {
				cnt = boardDao.boardAllCntMsgToByWriterId(paging);
			}else if(word.equals("title")) {
				cnt = boardDao.boardAllCntMsgToByTitle(paging);
			}
		}
		return cnt;
	}

	@Override
	public List<BoardModel> getPagingList(PagingModel paging) {
		
		int level = paging.getLevel();
		String word = paging.getWord();
		String answer = paging.getAnswer();
		List<BoardModel> list = null;		
		
		if(answer.equals("on")) {		
			list = boardDao.boardAllListByAnswer(paging);
		}else if(level == 0) {
			list = boardDao.boardAllListMsgFromByTitle(paging);	
		}else {
			if(word.equals("writer")) {
				list = boardDao.boardAllListMsgToByWriter(paging);
			}else if(word.equals("writerid")) {
				list = boardDao.boardAllListMsgToByWriterId(paging);
			}else if(word.equals("title")) {
				list = boardDao.boardAllListMsgToByTitle(paging);
			}
		}
		return list;
	}
	
	@Override
	public int getWriteBoard(BoardModel board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public BoardModel getViewBoard(BoardModel board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public CommentModel getComment(BoardModel board) {
		return boardDao.selectComment(board);
	}

	@Override
	public int getCntCommentByBoardNo(BoardModel board) {
		return boardDao.commentCntByBoardNo(board);
	}

	@Override
	public int getCommentDeleteByBoardNo(BoardModel board) {
		return boardDao.commentDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(BoardModel board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public int getInsertComment(CommentModel comment) {
		return boardDao.insertComment(comment);
	}

	@Override
	public int getDeleteComment(CommentModel comment) {
		return boardDao.deleteComment(comment);
	}

	@Override
	public int getUpdateComment(CommentModel comment) {
		return boardDao.updateComment(comment);
	}

}
