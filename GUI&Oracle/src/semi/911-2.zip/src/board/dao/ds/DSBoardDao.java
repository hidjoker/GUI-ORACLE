package board.dao.ds;

import java.util.List;

import board.dto.Board;
import board.dto.BoardFile;
import board.dto.Comment;
import board.util.Paging;

public interface DSBoardDao{
	
	// upload boardNo 조회(ALL)
	public int uploadBoardNo();
	
	// 총 게시글 수 조회(+제목)
	public int boardAllCntByTitle(Paging paging);
	
	// 총 게시글 수 조회(글번호)
	public int boardAllCntByBoardNo(Paging paging);
	
	// 총 게시글 수 조회(작성자)
	public int boardAllCntByWriter(Paging paging);
	
	// 총 게시글 수 조회(작성자ID)
	public int boardAllCntByWriterId(Paging paging);
	
	// 총 게시글 리스트 조회(+제목)
	public List<Board> boardAllListByTitle(Paging paging);
	
	// 총 게시글 리스트 조회(글번호)
	public List<Board> boardAllListByBoardNo(Paging paging);
	
	// 총 게시글 리스트 조회(작성자)
	public List<Board> boardAllListByWriter(Paging paging);
	
	// 총 게시글 리스트 조회(작성자ID)
	public List<Board> boardAllListByWriterId(Paging paging);
	
	// 게시글의 추천수 조회
	public int recommendCntByBoardNo(Board board);
	
	// 게시글 추가
	public int insertBoard(Board board);
	
	// 게시글 뷰 얻기
	public Board viewBoard(Board board);
	
	// Id의 추천 여부 조회
	public boolean selectRecommendById(Board board);
	
	// 댓글 리스트 얻기
	public List<Comment> commentList(Board board);
	
	// 게시글 수정하기
	public int updateBoard(Board board);
	
	// 게시글 조회수 +1
	public void addHit(Board board);
	
	// 게시글 추천 제거하기
	public int recommendAllDeleteByBoardNo(Board board);
	
	// 게시글 코멘트 제거하기
	public int commentsAllDeleteByBoardNo(Board board);
	
	// 게시글 첨부파일 제거하기
	public int filesAllDeleteByBoardNo(Board board);
	
	// 게시글 삭제하기
	public int deleteBoard(Board board);
	
	// 추천수 추가하기
	public int insertRecommend(Board board);
	
	// 추천수 제거하기
	public int deleteRecommend(Board board);
	
	// 댓글 추가하기
	public int insertComment(Comment comment);
	
	// 댓글 삭제하기
	public int deleteComment(Comment comment);

	// 파일 추가하기
	public int insertFile(BoardFile file);
	
	// 파일 리스트 얻기
	public List<BoardFile> fileList(Board board);

}
