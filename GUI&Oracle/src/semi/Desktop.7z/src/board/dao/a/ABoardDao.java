package board.dao.a;

import java.util.List;

import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public interface ABoardDao {
	
	// 총 게시글 수 조회
	public int boardAllCnt(Paging paging);
	
	// 총 게시글 리스트 조회
	public List<Board> boardAllList(Paging paging);
	
	// 게시글의 추천수 조회
	public int recommendCntByBoardNo(Board board);
	
	// 게시글 추가
	public int insertBoard(Board board);
	
	// 게시글 뷰 얻기
	public Board viewBoard(Board board);
	
	// Id의 추천 여부 조회
	public boolean selectRecommendById(Board board);
	
	// 댓글 리스트 얻기
	public List<Comment> commentList(Board board);
	
	// 게시글 수정하기
	public int updateBoard(Board board);
	
	// 게시글 조회수 +1
	public void addHit(Board board);
	
	// 게시글 추천 제거하기
	public int recommendAllDeleteByBoardNo(Board board);
	
	// 게시글 코멘트 제거하기
	public int commentsAllDeleteByBoardNo(Board board);
	
	// 게시글 삭제하기
	public int deleteBoard(Board board);
	
	// 추천수 추가하기
	public int insertRecommend(Board board);
	
	// 추천수 제거하기
	public int deleteRecommend(Board board);
	
	// 댓글 추가하기
	public int insertComment(Comment commnet);
	
	// 댓글 삭제하기
	public int deleteComment(Comment comment);
	
}
