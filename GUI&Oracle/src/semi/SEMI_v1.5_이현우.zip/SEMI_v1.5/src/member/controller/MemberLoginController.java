package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.dto.Member;
import member.service.MemberService;
import member.service.MemberServiceImpl;

@WebServlet("/member/login.do")
public class MemberLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private MemberService service = new MemberServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/view/member/login.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();

		Member member = new Member();
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		
		member.setId(id.toUpperCase());
		member.setPassword(password);

		if(service.login(member)) {
			

			
			String loginId =member.getId();
			String[] loginIdArr = loginId.split("-");
			if(loginId.equals("ADMIN")) {
				request.getSession().setAttribute("login", true);
				request.getSession().setAttribute("id", member.getId());
				request.getSession().setAttribute("name", service.getName(member) );
				request.getSession().setAttribute("admin", true);

				System.out.println("로그인 성공 : 관리자");
				response.sendRedirect("/main.do");
			}
			
			else if(loginIdArr[loginIdArr.length-1].equals("0") || loginIdArr[loginIdArr.length-1].equals("1")) {
				request.getSession().setAttribute("login", true);
				request.getSession().setAttribute("id", member.getId());
				request.getSession().setAttribute("name", service.getName(member) );
				request.getSession().setAttribute("teacher", true);
				
				System.out.println("로그인 성공 : 강사");
				response.sendRedirect("/main.do");
			}

			else {
				request.getSession().setAttribute("login", true);
				request.getSession().setAttribute("id", member.getId());
				request.getSession().setAttribute("name", service.getName(member) );
				request.getSession().setAttribute("student", true);

				System.out.println("로그인 성공 : 학생");
				response.sendRedirect("/main.do");
			}
		}
		else {

			// ....;;;
			out.println("<html><head><title></title>");
			out.println("<script>");
			out.println("alert('로그인 실패');");

			out.println("history.go(-1);");
			out.println("</script>");
			out.println("<body></body></html>");
		}

		out.close();

	}

}
