package board.controller.ds;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.BoardModel;
import board.service.ds.DSBoardServiceImpl;
import board.util.PagingModel;

@WebServlet("/board/ds/pagingList.do")
public class DSBoardPagingListController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		//--------------------------------------------------------------		
		// 로그인 세션 처리(초기값) - 관리자
		session.setAttribute("login", true);
		session.setAttribute("name", "관리자");
		session.setAttribute("id", "admin");			
//		
//		// 로그인 세션 처리(초기값) - 강사
//		session.setAttribute("login", true);
//		session.setAttribute("name", "b-pm-0");
//		session.setAttribute("id", 2);
		
		// 로그인 세션 처리(초기값) - 학생
//		session.setAttribute("login", true);
//		session.setAttribute("name", "학생");
//		session.setAttribute("id", "b-pm-2");
		//--------------------------------------------------------------		
		
		// 현재 페이지 처리
		String param = request.getParameter("curPage");		
		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				request.getParameter("curPage") );
		}
		
		// 총 게시글 수 얻어서 paging 객체 생성
		String word = request.getParameter("word");
		if(word == null||word.equals("")) {
			word = "title";
		}
		String search = request.getParameter("search");
		DSBoardServiceImpl service = new DSBoardServiceImpl();
		
		int totalCnt = service.getAllCnt(new PagingModel(search,word));		
		
		PagingModel paging = new PagingModel(totalCnt, curPage);
		paging.setSearch(search);
		paging.setWord(word);
		
		// 총 게시글 리스트 객체 얻기
		List<BoardModel> list = service.getPagingList(paging);
		
		// MODEL 객체에 담기
		request.setAttribute("paging", paging);
		request.setAttribute("boardList", list);
		
		request.getRequestDispatcher("/view/board/ds/ds_list.jsp")
			.forward(request, response);	
		
	}

}
