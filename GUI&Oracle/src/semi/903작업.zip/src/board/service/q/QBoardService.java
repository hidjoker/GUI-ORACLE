package board.service.q;

public interface QBoardService {

}
