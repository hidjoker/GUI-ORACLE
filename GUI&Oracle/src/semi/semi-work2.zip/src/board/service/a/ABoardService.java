package board.service.a;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public interface ABoardService {

	// 총 게시글 수 조회
	public int getAllCnt(Paging paging);
	
	// 총 게시글 리스트 얻기
	public List<Board> getPagingList(Paging paging);
}
