package board.dao.s;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public class SBoardDaoImpl implements SBoardDao{

	//멤버필드
	private Connection conn = DBConn.getConnection();
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	@Override
	public int boardAllCntMsgFromByTitle(PagingModel paging) {
		
		String id = paging.getLogId();
		
		String sql = "SELECT count(*) FROM board Where title Like ?"
				+ " AND boardtype='S' AND enable=1 AND writerid = ?";
		
		// 검색어 처리
		String search = paging.getSearch();
		
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}
				
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			ps.setString(2, id);
			rs = ps.executeQuery();
					
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
					
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
				
		return cnt;
	}
	
	@Override
	public int boardAllCntMsgToByWriter(PagingModel paging) {
		
		int msgTo = paging.getLevel();
		
		String sql = "SELECT count(*) FROM board Where writer Like ?"
				+ " AND boardtype='S' AND enable=1 AND msgto=?";
		
		// 검색어 처리
		String search = paging.getSearch();
		
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}
				
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			ps.setInt(2, msgTo);
			rs = ps.executeQuery();
					
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
					
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
				
		return cnt;
	}

	@Override
	public int boardAllCntMsgToByWriterId(PagingModel paging) {
		
		int msgTo = paging.getLevel();
		
		String sql = "SELECT count(*) FROM board Where writerid Like ?"
				+ " AND boardtype='S' AND enable=1 AND msgto=?";
		
		// 검색어 처리
		String search = paging.getSearch();
		
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}
				
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			ps.setInt(2, msgTo);
			rs = ps.executeQuery();
					
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
					
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
				
		return cnt;
	}
	
	@Override
	public int boardAllCntMsgToByTitle(PagingModel paging) {
		
		int msgTo = paging.getLevel();
		
		String sql = "SELECT count(*) FROM board Where title Like ?"
				+ " AND boardtype='S' AND enable=1 AND msgto=?";
		
		// 검색어 처리
		String search = paging.getSearch();
		
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}
				
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			ps.setInt(2, msgTo);
			rs = ps.executeQuery();
					
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
					
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
				
		return cnt;
	}
	
	@Override
	public List<BoardModel> boardAllListMsgFromByTitle(PagingModel paging) {
		
		String id = paging.getLogId();
		System.out.println(id);
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE title like ? AND boardtype='S' AND enable=1 AND writerid=?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<BoardModel> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setString(2, id);
			ps.setInt(3, paging.getStartNo() );
			ps.setInt(4, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				BoardModel board = new BoardModel();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));
				board.setMsgTo(rs.getInt("msgto"));
				
				//댓글 갯수 받아오기
				board.setCommentCnt(this.commentCntByBoardNo(board));
				
				boardList.add(board);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}

	@Override
	public List<BoardModel> boardAllListMsgToByWriter(PagingModel paging) {
		
		int msgTo = paging.getLevel();
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE boardtype='S' AND enable=1 AND writer LIKE ?" +
	    "        AND msgto=?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<BoardModel> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, msgTo);
			ps.setInt(3, paging.getStartNo() );
			ps.setInt(4, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				BoardModel board = new BoardModel();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));
				board.setMsgTo(rs.getInt("msgto"));
				
				//댓글 갯수 받아오기
				board.setCommentCnt(this.commentCntByBoardNo(board));
				
				boardList.add(board);

			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}
	
	@Override
	public List<BoardModel> boardAllListMsgToByWriterId(PagingModel paging) {
		int msgTo = paging.getLevel();

		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE boardtype='S' AND enable=1 AND writerid LIKE ?" +
	    "        AND msgto=?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<BoardModel> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, msgTo);
			ps.setInt(3, paging.getStartNo() );
			ps.setInt(4, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				BoardModel board = new BoardModel();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));
				board.setMsgTo(rs.getInt("msgto"));
				
				//댓글 갯수 받아오기
				board.setCommentCnt(this.commentCntByBoardNo(board));
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}
	
	@Override
	public List<BoardModel> boardAllListMsgToByTitle(PagingModel paging) {
		
		int msgTo = paging.getLevel();
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE boardtype='S' AND enable=1 AND title LIKE ?" +
	    "        AND msgto=?" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<BoardModel> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, msgTo);
			ps.setInt(3, paging.getStartNo() );
			ps.setInt(4, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				BoardModel board = new BoardModel();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));
				board.setMsgTo(rs.getInt("msgto"));

				//댓글 갯수 받아오기
				board.setCommentCnt(this.commentCntByBoardNo(board));
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}

	@Override
	public int insertBoard(BoardModel board) {
		
		String sql = "INSERT INTO board(boardno,writerid,writer,title,content,boardtype,msgto)"
				+ "	VALUES(board_seq.nextval,?,?,?,?,'S',?)";
		int res = 0;
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, board.getWriterId());
			ps.setString(2, board.getWriter());
			ps.setString(3, board.getTitle());
			ps.setString(4, board.getContent());
			ps.setInt(5, board.getMsgTo());
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
				try {
					if(ps!=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return res;
	}

	@Override
	public BoardModel viewBoard(BoardModel board) {
		int boardNo = board.getBoardNo();
		String sql = "SELECT * FROM BOARD WHERE boardno = ?";
		
		BoardModel viewBoard = new BoardModel();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			ResultSet rs = ps.executeQuery();
			
			rs.next();
						
			viewBoard.setBoardNo(rs.getInt("boardno"));
			viewBoard.setWriterId(rs.getString("writerid"));
			viewBoard.setWriter(rs.getString("writer"));
			viewBoard.setTitle(rs.getString("title"));
			viewBoard.setContent(rs.getString("content"));
			viewBoard.setHit(rs.getInt("hit"));
			viewBoard.setBoardType(rs.getString("boardtype"));
			viewBoard.setInDate(rs.getString("indate"));
			viewBoard.setMsgTo(rs.getInt("msgto"));
					
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return viewBoard;
	}
	
	@Override
	public int commentCntByBoardNo(BoardModel board) {
		int boardNo = board.getBoardNo();
		
		String sql = "SELECT count(*) FROM comments WHERE boardno=?";
				
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();
					
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 댓글 수 : "+cnt);
					
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		return cnt;
	}
	
	
	@Override
	public CommentModel selectComment(BoardModel board) {
		
		int boardNo = board.getBoardNo();
		String sql = "SELECT * FROM COMMENTS WHERE boardno=?";
		CommentModel comment= null;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();	
			
			rs.next(); 
			
			comment = new CommentModel();
			
			comment.setCommentNo(rs.getInt(1));
			comment.setBoardNo(rs.getInt(2));
			comment.setWriterId(rs.getString(3));
			comment.setWriter(rs.getString(4));
			comment.setInDate(rs.getString(5));
			comment.setContent(rs.getString(6));
			
			//cnt=1 넣어주기
			comment.setCommentCnt(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}		
		
		return comment;
	}

	@Override
	public void addHit(BoardModel board) {
		int boardNo = board.getBoardNo();
		String sql ="UPDATE board SET hit=hit+1 WHERE boardno=?"; 
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		if(res>0)System.out.println("조회수 +1 상승");
	}

	@Override
	public int commentDeleteByBoardNo(BoardModel board) {
		
		int boardNo = board.getBoardNo();
		String sql = "DELETE FROM comments WHERE boardno = ?";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null)ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	@Override
	public int deleteBoard(BoardModel board) {
		
		int boardNo = board.getBoardNo();
		String sql = "UPDATE board SET enable = 0 WHERE boardno=?";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			res = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return res;
	}

	@Override
	public int insertComment(CommentModel comment) {
		String sql = "INSERT INTO comments(commentno,boardno,writerid,writer,content) "
				+ "VALUES(comments_seq.nextVal,?,?,?,?)";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getBoardNo());
			ps.setString(2, comment.getWriterId());
			ps.setString(3, comment.getWriter());
			ps.setString(4, comment.getContent());
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	@Override
	public int deleteComment(CommentModel comment) {
		
		String sql = "DELETE FROM comments WHERE commentno=?";
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getCommentNo());
			
			res = ps.executeUpdate();
					
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}		
		return res;
	}

	@Override
	public int updateComment(CommentModel comment) {
		String sql = "UPDATE comments SET content=?, indate=sysdate "
				+ "WHERE commentno =? ";
		int res = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, comment.getContent());
			ps.setInt(2, comment.getCommentNo());
			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	@Override
	public int boardAllCntByAnswer(PagingModel paging) {
		
		int msgTo = paging.getLevel();
	
		String sql = " SELECT count(*) FROM (" +
				 " SELECT * FROM board WHERE boardtype='S' AND enable=1 AND msgto = ?" +
				" MINUS" + 
				" SELECT B.* FROM board B, comments C" +
				" Where B.boardno = C.boardno" + 
				" AND boardtype='S' AND enable=1 AND msgto=?)";
				
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, msgTo);
			ps.setInt(2, msgTo);
			rs = ps.executeQuery();
					
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
					
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
				
		return cnt;
	}

	@Override
	public List<BoardModel> boardAllListByAnswer(PagingModel paging) {
			
		int msgTo = paging.getLevel();
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
				" SELECT * FROM (SELECT * FROM board WHERE boardtype='S' AND enable=1 AND msgto = ?"+
		"        MINUS  "+
		"        SELECT d.* FROM board d, comments c" + 
		"        WHERE boardtype='S' AND enable=1 AND "+
	    "		 d.boardno = c.boardno AND msgto = ?)" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
		
		ArrayList<BoardModel> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, msgTo);
			ps.setInt(2, msgTo);
			ps.setInt(3, paging.getStartNo() );
			ps.setInt(4, paging.getEndNo() );

			// 지역 ResultSet 변수에 담기
			ResultSet rs = ps.executeQuery();
			
			while( rs.next() ) {
				BoardModel board = new BoardModel();
			
				board.setBoardNo(rs.getInt("boardno"));
				board.setWriterId(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setBoardType(rs.getString("boardtype"));
				board.setInDate(rs.getString("indate"));
				board.setMsgTo(rs.getInt("msgto"));

				//댓글 갯수 받아오기
				board.setCommentCnt(this.commentCntByBoardNo(board));
				
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
	}

}
