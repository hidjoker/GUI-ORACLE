package board.board.Sharecontroller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.Comments;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/share/commentinsert.do")
public class ShareCommentInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BoardService boardService = new BoardServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		
		Comments comment = new Comments();
		
		String boardno = (String) request.getParameter("boardNo");
		String writerid = (String) request.getParameter("userid");
		String writer = (String) request.getParameter("commentWriter");
		String content = (String) request.getParameter("content");
		comment.setBoardno( Integer.parseInt(boardno) );
		comment.setWriterid(writerid);
		comment.setWriter(writer);
		comment.setContent(content);
		
		boardService.insertComment(comment);
		
		response.sendRedirect("/share/view.do?boardno="+comment.getBoardno());
	}

}
