package board.service.f;

public interface FBoardService {

}
