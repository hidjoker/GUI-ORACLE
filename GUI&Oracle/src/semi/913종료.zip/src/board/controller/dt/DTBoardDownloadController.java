package board.controller.dt;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

@WebServlet("/board/dt/download.do")
public class DTBoardDownloadController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		String srcName = request.getParameter("file");
		String destName = srcName.split("_")[0];
		
		File srcFile = new File(
				getServletContext().getRealPath("/view/board/upload"),srcName);
		File destFile = new File(new File("./").getAbsolutePath(),destName);
		
		FileUtils.copyFile(srcFile, destFile);
		
//		response.sendRedirect("/board/dt/view.do?boardno="+boardNo);
		
		out.println("<script language='javascript'>");
		out.println("alert('바탕화면에 파일 다운을 완료하였습니다');");
		out.println("location.href = '/board/ds/view.do?boardno="+boardNo+"'"); 
		out.println("</script>"); 
		out.close();
		
	}
}
