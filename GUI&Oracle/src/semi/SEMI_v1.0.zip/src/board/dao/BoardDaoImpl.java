package board.dao;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public class BoardDaoImpl implements BoardDao{

	@Override
	public List<Board> selectAll(String boardType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int selectCntAll(String boardType) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Board> selectPagingList(Paging paging) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertBoard(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Board selectBoardByBoardNo(int boardNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateHit(int boardNo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean update(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int recommendCnt(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean selectRecommend(Board recommendBoard) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void insertRecommend(Board recommendBoard) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteRecommend(Board recommnedBoard) {
		// TODO Auto-generated method stub
		
	}

}
