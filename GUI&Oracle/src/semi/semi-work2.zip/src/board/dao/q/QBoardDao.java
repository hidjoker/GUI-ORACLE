package board.dao.q;

public interface QBoardDao {

}
