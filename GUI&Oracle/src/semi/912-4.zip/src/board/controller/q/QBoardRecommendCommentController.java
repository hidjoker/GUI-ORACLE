package board.controller.q;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import board.dto.BoardModel;
import board.dto.CommentModel;
import board.service.q.QBoardServiceImpl;


@WebServlet("/board/q/recommendComment.do")
public class QBoardRecommendCommentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		int commentNo = Integer.parseInt(request.getParameter("commentno"));
		String id = request.getParameter("commentid");
		System.out.println(id);
		CommentModel comment = new CommentModel();
		comment.setCommentNo(commentNo);
		comment.setWriterId(id);
		comment.setBoardNo(boardNo);
		
		// 댓글 추천 처리
		QBoardServiceImpl service = new QBoardServiceImpl();
		service.getRecommendComment(comment);
		
		// boardNo를 담은 객체
		BoardModel board = new BoardModel();
		board.setBoardNo(boardNo);
		board.setWriterId(id);
				
		// 코멘트 조회
		List<CommentModel> list = new ArrayList<>();
		list = service.getCommentList(board);
				
		Gson gson = new Gson();
		String gsonList = gson.toJson(list);			
		
		out.append(gsonList);	
	}
}
