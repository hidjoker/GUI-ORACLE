package board.service.s;

public interface SBoardService {

}
