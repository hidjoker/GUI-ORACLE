package board.service.dt;

import java.util.List;

import board.dto.BoardModel;
import board.dto.BoardFileModel;
import board.util.PagingModel;

public interface DTBoardService {
	
	// upload BoardNo 조회
	public int getUploadBoardNo();
	
	// 총 게시글 수 조회(search)
	public int getAllCnt(PagingModel paging);
	
	// 총 게시글 리스트 얻기
	public List<BoardModel> getPagingList(PagingModel paging);
	
	// 게시글 입력하기
	public int getWriteBoard(BoardModel board);
	
	// 게시글 뷰 얻기
	public BoardModel getViewBoard(BoardModel board);
	
	// 게시글 수정하기
	public int getUpdateBoard(BoardModel board);
	
	// 게시글 첨부파일 제거하기
	public int getFilesAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 삭제하기
	public int getDeleteBoard(BoardModel board);
	
	// 파일 추가하기
	public int getInsertFile(BoardFileModel file);
	
	// 파일 리스트 얻기
	public List<BoardFileModel> getFileList(BoardModel board);
	
}
