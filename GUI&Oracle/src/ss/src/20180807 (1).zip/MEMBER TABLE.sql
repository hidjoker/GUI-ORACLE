

-- DROP TABLE member;
CREATE TABLE member (
	userid VARCHAR2(50) primary key,
	nick VARCHAR2(100),
	email VARCHAR2(300)
);