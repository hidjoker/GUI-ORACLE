package board.dao.s;

import java.util.List;

import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public interface SBoardDao {
	
	// 총 게시글 수 조회(타이틀-보낸사람)
	public int boardAllCntMsgFromByTitle(Paging paging);
	
	// 총 게시글 수 조회(작성자-받는사람)
	public int boardAllCntMsgToByWriter(Paging paging);
	
	// 총 게시글 수 조회(작성자ID-받는사람)
	public int boardAllCntMsgToByWriterId(Paging paging);
	
	// 총 게시글 수 조회(타이틀-받는사람)
	public int boardAllCntMsgToByTitle(Paging paging);
	
	// 총 게시글 리스트 조회(타이틀-보낸사람)
	public List<Board> boardAllListMsgFromByTitle(Paging paging);
	
	// 총 게시글 리스트 조회(작성자-받는사람)
	public List<Board> boardAllListMsgToByWriter(Paging paging);
	
	// 총 게시글 리스트 조회(작성자ID-받는사람)
	public List<Board> boardAllListMsgToByWriterId(Paging paging);
	
	// 총 게시글 리스트 조회(타이틀-받는사람)
	public List<Board> boardAllListMsgToByTitle(Paging paging);
	
	// 게시글 추가
	public int insertBoard(Board board);
	
	// 게시글 뷰 얻기
	public Board viewBoard(Board board);
	
	// 댓글 리스트 얻기
	public List<Comment> commentList(Board board);
	
	// 게시글 조회수 +1
	public void addHit(Board board);
	
	// 게시글 코멘트 제거하기
	public int commentsAllDeleteByBoardNo(Board board);
	
	// 게시글 수정하기
	public int updateBoard(Board board);
	
	// 게시글 삭제하기
	public int deleteBoard(Board board);
	
	// 댓글 추가하기
	public int insertComment(Comment commnet);
	
	// 댓글 삭제하기
	public int deleteComment(Comment comment);
	
	
}
