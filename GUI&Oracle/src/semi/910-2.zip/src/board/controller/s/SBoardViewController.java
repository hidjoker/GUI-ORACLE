package board.controller.s;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.Board;
import board.dto.Comment;
import board.service.s.SBoardServiceImpl;


@WebServlet("/board/s/view.do")
public class SBoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		HttpSession session = request.getSession();
		String writerId = (String)session.getAttribute("logId");
		
		// boardno를 담은 객체
		Board board = new Board();
		board.setBoardNo(boardNo);
		board.setWriterId(writerId);
		
		// 보드 조회
		SBoardServiceImpl service = new SBoardServiceImpl();
		Board viewBoard = service.getViewBoard(board);
		
		// 코멘트 조회
		int commentCnt = service.getCntCommentByBoardNo(board);
		Comment comment = new Comment();
		if(commentCnt > 0) comment = service.getComment(board);
		
		request.setAttribute("board", viewBoard);
		request.setAttribute("comment", comment);
		
		request.getRequestDispatcher("/view/board/s/s_view.jsp")
			.forward(request, response);	
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");

		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		String commentWriter = request.getParameter("commentWriter");
		String commentId = request.getParameter("commentid");
		String content = request.getParameter("content");
		String sort = request.getParameter("sort");
			
		Comment comment = new Comment();
		comment.setBoardNo(boardNo);
		comment.setWriter(commentWriter);
		comment.setWriterId(commentId);
		comment.setContent(content);
		
		if(request.getParameter("commentno")!=null) {
			int commentNo = Integer.parseInt(request.getParameter("commentno"));
			comment.setCommentNo(commentNo);
		}		
		
		SBoardServiceImpl service = new SBoardServiceImpl();
		
		int res;
		if(sort.equals("add")) {		
			res = service.getInsertComment(comment);
			if(res>0) System.out.println("댓글 추가 완료");
		}else if(sort.equals("del")) {
			res = service.getDeleteComment(comment);
			if(res>0) System.out.println("댓글 삭제 완료");
		}else if(sort.equals("update")) {
			res = service.getUpdateComment(comment);
			if(res>0) System.out.println("댓글 수정 완료");
		}		
		
		// boardno를 담은 객체
		Board board = new Board();
		board.setBoardNo(boardNo);
		board.setWriterId(commentId);
		
		Board viewBoard = service.getViewBoard(board);
		
		// 코멘트 조회
		int commentCnt = service.getCntCommentByBoardNo(board);
		System.out.println("총 댓글 수 : "+commentCnt);
		Comment viewComment = new Comment();
		if(commentCnt > 0) viewComment = service.getComment(board);
		
		request.setAttribute("board", viewBoard);
		request.setAttribute("comment", viewComment);
	
		request.getRequestDispatcher("/view/board/s/s_view.jsp")
			.forward(request, response);
	}
}
