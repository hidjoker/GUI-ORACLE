package admin.service;

import java.util.List;

import com.google.gson.JsonArray;

import admin.dao.AdminDao;
import admin.dto.AdminDto;
import admin.dto.AdminUserDto;

public class AdminServiceImpl implements AdminService {

	
	AdminDao dao = new AdminDao();
	AdminDto dto = new AdminDto();
	
	//전체 클래스 조회(최상단 카드)
	@Override
	public int ClassSelect() {
		return dao.ClassSelect();
		
		
	}

	//전체 학생 조회(최상단 카드)
	@Override
	public int StudentSelect() {
		
		return dao.StudentSelect();
	}

	//전체 강사 조회(최상단카드)
	@Override
	public int TeacherSelect() {
		return dao.teacherSelect();
	}

	
	//클래스 정보 조회(중단 카드)
	@Override
	public List viewClass() {
		// TODO Auto-generated method stub
		return dao.viewClass();
	}

	
	//클래스 뷰 조회
	@Override
	public AdminDto view(String classname) {
		
		return dao.view(classname);
	}

	//클래스 이미지 수정
	@Override
	public void imgmodify(String imgurl, String classname) {
		dao.imgmodify(imgurl, classname);
		
	}

	
	//클래스생성
	@Override
	public boolean createClass(AdminDto dto) {
			
		return dao.createClass(dto);
		
				  
	}

	//유저생성(클래스 생성시 함께 사용)
	@Override
	public int createUser(AdminDto dto) {
		
		return dao.createUser(dto);
	}

	//종강처리
	@Override
	public boolean classclose(String classname) {
		
		return dao.classclose(classname);
	}

	//유저정보 조회
	@Override
	public JsonArray userinfo(String classname) {
		return dao.userinfo(classname);
	}

	//클래스 정보 수정
	@Override
	public void classupdate(AdminDto dto) {
		dao.classupdate(dto);
		
	}

	
	//유저정보 조회 리스트버전
	@Override
	public List userinfoListVersion(String classname) {
		
		return dao.userinfoListVersion(classname);
	}
	//유저 뷰
	@Override
	public AdminUserDto userview(String userid) {
		
		return dao.userview(userid);
	}

	
	//유저 삭제
	@Override
	public void deleteuser(String userid) {
		dao.deleteuser(userid);
		
	}

	@Override
	public void userUpdate(AdminUserDto dto) {
		dao.userUpdate(dto);
		
	}



	

}













