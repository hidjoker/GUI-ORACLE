package board.board.Boardcontroller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import board.dto.Board;
import board.dto.Upload;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/board/write.do")
public class BoardWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private BoardService boardService = new BoardServiceImpl();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/view/board.board/write.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		
		Board board = new Board();
//		board.setBoardno(Integer.parseInt(mul.getParameter("")));
		board.setTitle(request.getParameter("title"));
		board.setContent(request.getParameter("content"));
		board.setBoardtype("board");
		board.setWriterid((String) request.getSession().getAttribute("id")); 
		board.setWriter((String) request.getSession().getAttribute("name"));
		
		boardService.write(board);
		
		
		// 리다이렉트
		response.sendRedirect("/board/pagingList.do");
	}

}














