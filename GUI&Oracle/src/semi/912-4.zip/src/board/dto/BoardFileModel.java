package board.dto;

public class BoardFileModel {
	
	private int fileNo;
	private int boardNo;
	private String before;
	private String after;
	private int fileSize;
	private String date;
	
	
	@Override
	public String toString() {
		return "File [fileNo=" + fileNo + ", boardNo=" + boardNo + ", before=" + before + ", after=" + after
				+ ", fileSize=" + fileSize + ", date=" + date + "]";
	}
	public int getFileNo() {
		return fileNo;
	}
	public void setFileNo(int fileNo) {
		this.fileNo = fileNo;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getBefore() {
		return before;
	}
	public void setBefore(String before) {
		this.before = before;
	}
	public String getAfter() {
		return after;
	}
	public void setAfter(String after) {
		this.after = after;
	}
	public int getFileSize() {
		return fileSize;
	}
	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
		
}
