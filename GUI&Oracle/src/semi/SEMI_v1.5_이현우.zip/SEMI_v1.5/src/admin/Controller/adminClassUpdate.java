package admin.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.dto.AdminDto;
import admin.service.AdminService;
import admin.service.AdminServiceImpl;


@WebServlet("/adminclass/update.do")
public class adminClassUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String classname= request.getParameter("classname");

		AdminService service = new AdminServiceImpl();
		
		
		AdminDto dto= service.view(classname);
		
		request.setAttribute("dto", dto);
	
		
		
		
		//반
		String group = dto.getClassname().split("-")[0];
		//시간
		String time = dto.getClassname().split("-")[1];
		String startY = dto.getStartdate().split("-")[0];
		String startM = dto.getStartdate().split("-")[1];
		String startD = dto.getStartdate().split("-")[2];
		String endY = dto.getEnddate().split("-")[0];
		String endM = dto.getEnddate().split("-")[1];
		String endD = dto.getEnddate().split("-")[2];
		
		
		request.setAttribute("group", group);
		request.setAttribute("time", time);
		request.setAttribute("startY", startY);
		request.setAttribute("startM", startM);
		request.setAttribute("startD", startD);
		
		request.setAttribute("endY", endY);
		request.setAttribute("endM", endM);
		request.setAttribute("endD", endD);
		
		
		
		request.getRequestDispatcher("/admin/adminClassUpdate.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		AdminService service = new AdminServiceImpl();
		AdminDto dto = new AdminDto();
		
		
		//클래스네임
		dto.setClassname(request.getParameter("createclassname"));
		//과목명
		dto.setSubject(request.getParameter("classcreate-name"));

		//시작일
		String startdate = request.getParameter("classcreate-startdate-y")
				+"-"+request.getParameter("classcreate-startdate-m")
				+"-"+request.getParameter("classcreate-startdate-d");
	
		dto.setStartdate(startdate);
		
		//종강일
		
		String enddate = request.getParameter("classcreate-enddate-y")
				+"-"+request.getParameter("classcreate-enddate-m")
				+"-"+request.getParameter("classcreate-enddate-d");
		
		dto.setEnddate(enddate);
		
		//총 수강일
		
		dto.setTotal(Integer.parseInt(request.getParameter("classcreate-totaldate"))); 
	
		//클래스 업데이트
		service.classupdate(dto);
		
		
	

		 response.sendRedirect("/admin/class.do");
	}

}
