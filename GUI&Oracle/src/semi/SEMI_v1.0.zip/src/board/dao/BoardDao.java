package board.dao;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public interface BoardDao {
	/**
	 * 
	 * @param boardType //게시판 이름
	 * @return List<Board> // 해당 게시판의 모든 게시글 객체// 모든 게시글 SELECT
	 */
	public List<Board> selectAll(String boardType);
	/**
	 * @param boardType // 게시판 이름
	 * @return int // 해당 게시판의 모든 게시글 수 // 모든 게시글 count(*)
	 */
	public int selectCntAll(String boardType);
	/**
	 * 
	 * @param paging //페이징 객체
	 * @return List<Board>//페이지의 게시글 목록 리스트 // 해당 페이지의 게시글 목록
	 */
	public List<Board> selectPagingList(Paging paging);
	/**
	 * 
	 * @param board // insert할 board 객체
	 * @return boolean // Insert 성공여부
	 */
	public boolean insertBoard(Board board);
	/**
	 * 
	 * @param boardNo // BoardNo(PK)로 Board 객체 불러오기
	 * @return Board // where boardno =  사용
	 */
	public Board selectBoardByBoardNo(int boardNo);
	/**
	 * @param boardNo // 조회 수를 올릴 boardNo
	 * 	UPDATE board set hit = hit+1 WHERE boardNo =
	 */
	public void updateHit(int boardNo);
	/**
	 * 
	 * @param board // 수정할 Board 객체
	 * @return boolean // update 성공여부
	 */
	public boolean update(Board board);
	/**
	 * 
	 * @param board // 수정할 Board 객체
	 * @return boolean // update 성공여부
	 */
	public boolean delete(Board board);
	/**
	 * 
	 * @param board // 해당 게시글의 추천수 불러오기
	 * @return int // 추천수 알려주기 // count(*) boardNo
	 */
	public int recommendCnt(Board board);
	/**
	 * 
	 * @param recommendBoard // 추천 여부 확인할 Board객체
	 * @return boolean // 해당 user가 추천한적이 있으면 false 반환하기
	 */
	public boolean selectRecommend(Board recommendBoard);
	/**
	 * 
	 * @param recommendBoard // board 추천하기
	 * insert INTO RECOMMEND VALUES(?, ?) //
	 */
	public void insertRecommend(Board recommendBoard);
	/**
	 * 
	 * @param recommnedBoard // board 추천 취소하기
	 * delete recommend where boardno=? AND userid=?
	 */
	public void deleteRecommend(Board recommnedBoard);
}
