package board.service;

import java.util.List;

import board.dao.BoardDao;
import board.dao.BoardDaoImpl;
import board.dao.CommentsDao;
import board.dao.CommentsDaoImpl;
import board.dto.Board;
import board.dto.Comments;
import board.dto.Upload;
import board.util.Paging;

public class BoardServiceImpl implements BoardService {

	private BoardDao boardDao = new BoardDaoImpl();

	private CommentsDao commentDao = new CommentsDaoImpl();

	@Override
	public List getList(String boardType) {
		return boardDao.selectAll(boardType);
	}

	@Override
	public int getTotal(String boardType) {
		return boardDao.selectCntAll(boardType);
	}

	@Override
	public int getTotalSearch(String search, String boardType) {
		return boardDao.selectCntAllSearch(search,boardType);
	}

	@Override
	public List<Board> getPagingList(Paging paging, String boardType) {
		return boardDao.selectPagingList(paging,boardType);
	}
	

	@Override
	public List getPagingListSearch(Paging paging, String boardType) {
		return boardDao.selectPagingListSearch(paging,boardType);
	}

	@Override
	public void write(Board board) {
		boardDao.write(board);
	}

	@Override
	public void write(Board board, Upload file) {
		int boardno = board.getBoardno();
		board.setBoardno(boardno);
		
		boardDao.write(board);	// 먼저 게시글을 작성한다.(board_seq.nextval 호출된다[1증가])
		boardDao.insert(file,boardno);//이후에 파일을 업로드한다(board_seq.currval 호출된다[이전값 사용])
		
	}

	@Override
	public Board view(Board board) {
		boardDao.updateHit(board);
		return boardDao.selectBoardByBoardno(board);
	}

	@Override
	public void update(Board board) {
		boardDao.update(board);
	}

	@Override
	public void fileUpdate(Upload file , Board board ) {
		boardDao.update(board);
		
		boardDao.fileUpdate(file, board);
	}
	
	@Override
	public void delete(Board board) {
		boardDao.delete(board);
	}

	@Override
	public boolean recommendCheck(Board board) {
//		System.out.println(board);
		if( boardDao.selectCountRecommend(board) > 0 ) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override	
	public boolean recommend(Board board) {
		if( recommendCheck(board) ) {
			boardDao.deleteRecommend(board);
			return false;
		} else {
			boardDao.insertRecommend(board);
			return true;
		}
		
	}
	
	@Override
	public int getRecommend(Board board) {
		return boardDao.selectTotalRecommend(board);
	}

	
	
	@Override
	public void insertComment(Comments comment) {
		commentDao.insertComment(comment);
	}

	@Override
	public List getCommentList(Board board) {
		return commentDao.selectComment(board);
	}

	@Override
	public boolean deleteComment(Comments comment) {
		commentDao.deleteComment(comment); 
		
		if( commentDao.countComment(comment) > 0 ) {
			return false;
		} else {
			return true;
		}
	}
	
	
	
	
	@Override
	public void boardListDelete(String names) {
		boardDao.deleteBoardList(names);
		
	}

	@Override
	public List<Upload> getUpFile(Board board) {
		
		return boardDao.selectFileByBoardno(board);
	}
	
	@Override
	public void deleteFile(Integer fileNo) {
		boardDao.deleteFile(fileNo);
	}

	@Override
	public Upload downFile(int fileNo) {
		return boardDao.downFile(fileNo);
	}
	
}
