package board.dto;

public class Comment {
	
	private int commentNo;
	private int boardNo;
	private String writerId;
	private String writer;
	private String inDate;
	private String content;
	private int recommend;
	private boolean doRecommend; //질문게시판(코멘트 추천여부)
	private int commentCnt; //건의게시판(답변개수)
	
	
	public int getCommentCnt() {
		return commentCnt;
	}
	public void setCommentCnt(int commentCnt) {
		this.commentCnt = commentCnt;
	}
	public boolean isDoRecommend() {
		return doRecommend;
	}
	public void setDoRecommend(boolean doRecommend) {
		this.doRecommend = doRecommend;
	}
		
	public int getCommentNo() {
		return commentNo;
	}
	public int getRecommend() {
		return recommend;
	}
	public void setRecommend(int recommend) {
		this.recommend = recommend;
	}
	public void setCommentNo(int commentNo) {
		this.commentNo = commentNo;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getWriterId() {
		return writerId;
	}
	public void setWriterId(String writerId) {
		this.writerId = writerId;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getInDate() {
		return inDate;
	}
	public void setInDate(String inDate) {
		this.inDate = inDate;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	
	@Override
	public String toString() {
		return "Comment [commentNo=" + commentNo + ", boardNo=" + boardNo + ", writerId=" + writerId + ", writer="
				+ writer + ", inDate=" + inDate + ", content=" + content + "]";
	}
}
