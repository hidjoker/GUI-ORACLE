package board.dto;

import java.util.Date;

public class Board {

	private int boardno;
	private String writerid;
	private String writer;
	private String title;
	private String content;
	private int hit;
	private String boardtype;
	private int enable;
	private Date indate;
	private int recommend;
	
	
	
	@Override
	public String toString() {
		return "Board [boardno=" + boardno + ", writerid=" + writerid + ", writer=" + writer + ", title=" + title
				+ ", content=" + content + ", hit=" + hit + ", boardtype=" + boardtype + ", enable=" + enable
				+ ", indate=" + indate	+ ", recommend=" + recommend + "]";
	}



	public int getBoardno() {
		return boardno;
	}



	public void setBoardno(int boardno) {
		this.boardno = boardno;
	}



	public String getWriterid() {
		return writerid;
	}



	public void setWriterid(String writerid) {
		this.writerid = writerid;
	}



	public String getWriter() {
		return writer;
	}



	public void setWriter(String writer) {
		this.writer = writer;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getContent() {
		return content;
	}



	public void setContent(String content) {
		this.content = content;
	}



	public int getHit() {
		return hit;
	}



	public void setHit(int hit) {
		this.hit = hit;
	}



	public String getBoardtype() {
		return boardtype;
	}



	public void setBoardtype(String boardtype) {
		this.boardtype = boardtype;
	}



	public int getEnable() {
		return enable;
	}



	public void setEnable(int enable) {
		this.enable = enable;
	}



	public Date getIndate() {
		return indate;
	}



	public void setIndate(Date indate) {
		this.indate = indate;
	}



	public int getRecommend() {
		return recommend;
	}



	public void setRecommend(int recommend) {
		this.recommend = recommend;
	}
	
	




	
}
