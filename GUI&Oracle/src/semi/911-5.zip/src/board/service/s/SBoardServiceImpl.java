package board.service.s;

import java.util.List;

import board.dao.s.SBoardDaoImpl;
import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public class SBoardServiceImpl implements SBoardService {
	
	SBoardDaoImpl boardDao = new SBoardDaoImpl();
	
	@Override
	public int getAllCnt(Paging paging) {
		int level = paging.getLevel();
		String word = paging.getWord();
		int cnt = 0;
		
		if(level == 0) {
			cnt = boardDao.boardAllCntMsgFromByTitle(paging);	
		}else {
			if(word.equals("writer")) {
				cnt = boardDao.boardAllCntMsgToByWriter(paging);
			}else if(word.equals("writerid")) {
				cnt = boardDao.boardAllCntMsgToByWriterId(paging);
			}else if(word.equals("title")) {
				cnt = boardDao.boardAllCntMsgToByTitle(paging);
			}
		}
		return cnt;
	}

	@Override
	public List<Board> getPagingList(Paging paging) {
		
		int level = paging.getLevel();
		String word = paging.getWord();
		List<Board> list = null;		
		
		if(level == 0) {
			list = boardDao.boardAllListMsgFromByTitle(paging);	
		}else {
			if(word.equals("writer")) {
				list = boardDao.boardAllListMsgToByWriter(paging);
			}else if(word.equals("writerid")) {
				list = boardDao.boardAllListMsgToByWriterId(paging);
			}else if(word.equals("title")) {
				list = boardDao.boardAllListMsgToByTitle(paging);
			}
		}
		return list;
	}
	
	@Override
	public int getWriteBoard(Board board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public Board getViewBoard(Board board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public Comment getComment(Board board) {
		return boardDao.selectComment(board);
	}

	@Override
	public int getCntCommentByBoardNo(Board board) {
		return boardDao.commentCntByBoardNo(board);
	}

	@Override
	public int getCommentDeleteByBoardNo(Board board) {
		return boardDao.commentDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(Board board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public int getInsertComment(Comment comment) {
		return boardDao.insertComment(comment);
	}

	@Override
	public int getDeleteComment(Comment comment) {
		return boardDao.deleteComment(comment);
	}

	@Override
	public int getUpdateComment(Comment comment) {
		return boardDao.updateComment(comment);
	}

}
