package member.dto;

public class Member {

}
