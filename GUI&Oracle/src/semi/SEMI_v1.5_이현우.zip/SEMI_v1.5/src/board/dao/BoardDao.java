package board.dao;

import java.util.List;

import board.dto.Board;
import board.dto.Upload;
import board.util.Paging;

public interface BoardDao {
		// board 테이블 전체 조회
		public List selectAll(String boardType);

		// 총 게시글 수 조회
		public int selectCntAll(String boardType);

		// 게시글 검색
		public int selectCntAllSearch(String search,String boardType);

		// 페이징 리스트 조회
		public List selectPagingList(Paging paging,String boardType);

		// 페이징 리스트 검색
		public List selectPagingListSearch(Paging paging,String boardType);

		// 게시글 삽입
//		public void insert(Board board);
		public void write(Board board);

		// 게시글 조회
		public Board selectBoardByBoardno(Board board);

		// 조회수 증가
		public void updateHit(Board board);

		// 게시글 수정
		public void update(Board board);
		public void fileUpdate (Upload file,Board board);
		// 게시글 삭제
		public void delete(Board board);

		// 리스트에서 게시글 삭제하기
		public void deleteBoardList(String names);

		// 추천 수 구하기
		public int selectCountRecommend(Board board);

		// 추천 넣기
		public void insertRecommend(Board board);

		// 추천 삭제
		public void deleteRecommend(Board board);

		// 총 추천 수 구하기
		public int selectTotalRecommend(Board board);
		
		// 첨부파일 업로드
		public void insert(Upload file, int boardNo);
		
		// 첨부파일 삭제
		public void deleteFile(Integer fileNo);

		// 첨부파일 조회
		public List<Upload> selectFileByBoardno(Board board);

		// 파일 다운로드
		public Upload downFile(int fileNo);
}
