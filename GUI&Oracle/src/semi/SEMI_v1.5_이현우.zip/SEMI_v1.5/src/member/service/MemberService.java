package member.service;

import member.dto.Group;
import member.dto.Member;
import member.dto.MemberAndClass;

public interface MemberService {
	
	// 로그인 성공 시 true
	// 로그인 실패 시 false
	public boolean login(Member member);
	
	// 로그인한 아이디에 대한 이름 가져오기
	public String getName(Member member);
	
	// 유저 전체 정보 -- 사용 x
	public MemberAndClass getInformation(String id);
	
	// 마이페이지 유저 정보 가져오기
	public MemberAndClass getMyPageInformation(String id);
	
	// 회원정보수정 유저 정보 보여주기
	public Member getMemberInformation(String id); 
	
	// 회원정보 수정 성공 시 true
	// 회원정보 수정 실패 시 false
	public boolean updateMember(Member member);
	
	public boolean insertClass(Group group);


	public boolean join(Member member);
	
	
	// 아이디에 대한 비밀번호 가져오기
	public String getPassword(String id);
	
	// id, name, email 정보를 입력하여 해당하는 정보가 존재하는지 확인
	public Member searchPassword(String id, String name, String email);
	
	// id, name, email 입력 시 존재할 때 해당 계정의 임시 pw로 update - true
	// 실패 시 false
	public boolean changePassword(String pw, String id, String name, String email);
}
