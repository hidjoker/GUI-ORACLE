package board.service.f;

public class FBoardServiceImpl {

}
