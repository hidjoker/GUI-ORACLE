package chat.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import DBUtil.DBConn;
import chat.dto.Chan;
import chat.dto.Chat;

public class ChatDao {
	private Connection conn = DBConn.getConnection();

	private PreparedStatement ps; // statement 변경하기
	private ResultSet rs;

	public void write(Chat insertChat) {

		String query = "INSERT INTO CHAT(NUM , NAME , MSG, CHAN) VALUES( CHAT_SEQ.nextval , '" + insertChat.getName()
				+ "' , '" + insertChat.getMsg() + "' , '" + insertChat.getChan() + "')";
		try {
			ps = conn.prepareStatement(query);
			ps.executeQuery();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public List<String> proc(String lastReq,String chancode) {

		List<String> result = new ArrayList<String>();
		String query = "";
		if (lastReq == "") {
			query = "SELECT * FROM CHAT WHERE num = ( SELECT MAX(num) FROM CHAT) AND CHAN='"+chancode+"'";
		} else {
			query = "SELECT * FROM CHAT WHERE INDATE > '"+lastReq+"' AND CHAN = '"+chancode+"'";
		}
		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next()) {
				result.add(rs.getString("CHAN") + "_" + rs.getString("NAME") + ">>" + rs.getString("MSG") + "_"
						+ rs.getString("INDATE"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public boolean selectChanName(String chanName) {
		boolean result = false;
		String query = "SELECT COUNT(*) FROM CHATCHAN WHERE NAME = ?";

		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, chanName);
			rs = ps.executeQuery();

			while (rs.next()) {
				if ((0 == rs.getInt(1))) 
				result = true;
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	public List<Chan> checkChan(String userid) {
		List<Chan> result = new ArrayList<Chan>();
		String query = "SELECT NAME,CODE FROM CHATCHAN WHERE USERID LIKE('%"+userid+"%')" ;

		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Chan ch = new Chan();
				ch.setName(rs.getString("NAME"));
				ch.setCode(rs.getString("CODE"));
				result.add(ch);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public String createChan(Chan chan) {
		String result = null;
		String uid = UUID.randomUUID().toString();
		String query = "INSERT INTO CHATCHAN(NAME, HOSTID, CODE, USERID) VALUES(?,?,?, NULL)";
		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, chan.getName());
			ps.setString(2, chan.getHostid());
			ps.setString(3, uid);
			ps.executeQuery();
			result = uid;
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public void exitChan(String chancode, String userid) {
		String query = "update chatchan set userid = replace((select userid from chatchan where  code = ?), ',"+userid+"','')";

		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, chancode);
			ps.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public String joinChan(String code) {
		String query = "SELECT NAME FROM CHATCHAN WHERE CODE = ?";

		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, code);
			rs = ps.executeQuery();
			while (rs.next()) {
				return rs.getString(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return "";
	}
	public void updateChan(String uid,String userid) {
		String query = "UPDATE CHATCHAN SET USERID = USERID||',"+userid+"'WHERE CODE='"+uid+"'";
		try {
			ps = conn.prepareStatement(query);

			rs = ps.executeQuery();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
		}
		
	}

}
