package chat.dto;

public class Chat {
	private String name;
	private String msg;
	private String chan;

	@Override
	public String toString() {
		return "Chat ( name = " +name +",  msg = "+msg+",  chan = "+")";
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getChan() {
		return chan;
	}

	public void setChan(String chan) {
		this.chan = chan;
	}

}
