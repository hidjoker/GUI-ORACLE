package admin.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.dto.AdminDto;
import admin.service.AdminService;
import admin.service.AdminServiceImpl;


@WebServlet("/adminclass/create.do")
public class adminClassCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.getRequestDispatcher("/admin/adminClassCreate.jsp").forward(request, response);
		
		
		
	}
		


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		// 응답객체 문서 형식 설정(+인코딩)
		response.setContentType("text/html;charset=utf-8");
		
		AdminService service = new AdminServiceImpl();
		AdminDto dto = new AdminDto();
		
		
		//과목명
		dto.setSubject(request.getParameter("classcreate-name"));
		//클래스 이름
		dto.setClassname(request.getParameter("classcreate-classname")+"-"+request.getParameter("classcreate-classtime"));
	
		//시작날짜
		
		String startdate = request.getParameter("classcreate-startdate-y")
				+"-"+request.getParameter("classcreate-startdate-m")
				+"-"+request.getParameter("classcreate-startdate-d");
	
		dto.setStartdate(startdate);
		
		//종강날짜
		
		String enddate = request.getParameter("classcreate-enddate-y")
				+"-"+request.getParameter("classcreate-enddate-m")
				+"-"+request.getParameter("classcreate-enddate-d");
		
		dto.setEnddate(enddate);
		
		//총 수강일
		
		if(request.getParameter("classcreate-totaldate").length()==0) {}
		else {dto.setTotal(Integer.parseInt(request.getParameter("classcreate-totaldate"))); }
	
		
		//총 수강생
		if(request.getParameter("classcreate-totalstudent").length()==0) {}
		else {dto.setStuno(Integer.parseInt(request.getParameter("classcreate-totalstudent"))); }
		
		//담당강사
		dto.setTeacher(request.getParameter("classcreate-teacher"));
		
		//취업담임
		dto.setJobteacher(request.getParameter("classcreate-jobteacher"));
		
		
		 
		
		
		//클래스생성
		if(service.createClass(dto)) { request.setAttribute("result", true); }
		 else { request.setAttribute("result",false);}
		 
		service.createUser(dto);
		 

		 response.sendRedirect("/admin/class.do");
		
		
		
		
		
	}

}
