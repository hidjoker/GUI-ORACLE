package admin.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.dao.AdminDao;


@WebServlet("/admin/checkClass.do")
public class adminClassCheckController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
				
							//01 리스폰스겟라이트가응답박식이고
		//02응답방식을 out에 담아서
		PrintWriter out = response.getWriter();
		String param = request.getParameter("classname")+"-"+request.getParameter("time");
		
		
		AdminDao ad = new AdminDao();
		boolean result = ad.checkclass(param);
		if(result) {
			// 결과값을 전달 아까 그페이지
			out.print("true");
		}
		else {
			out.print("false");
		}
	}

}
