package board.controller.a;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import board.dto.Board;
import board.service.a.ABoardServiceImpl;

@WebServlet("/board/a/listDelete.do")
public class ABoardListDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		String jsonList = request.getParameter("chkList");
		Gson gson = new Gson();
		List list = gson.fromJson(jsonList,List.class);
		
		ABoardServiceImpl service = new ABoardServiceImpl();		
		for (Object boardNo : list) {
			int num = Integer.parseInt(String.valueOf(boardNo));
			Board board = new Board();
			board.setBoardNo(num);
			service.getRecommendAllDeleteByBoardNo(board);
			service.getCommentsAllDeleteByBoardNo(board);
			service.getDeleteBoard(board);			
		}
		
		response.sendRedirect("/board/a/pagingList.do");
		
	}

}
