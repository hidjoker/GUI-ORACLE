package board.service.a;

import java.util.List;

import board.dao.a.ABoardDaoImpl;
import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public class ABoardServiceImpl implements ABoardService{

	private ABoardDaoImpl boardDao = new ABoardDaoImpl();
	
	@Override
	public int getAllCnt(Paging paging) {
		return boardDao.boardAllCnt(paging);
	}

	@Override
	public List<Board> getPagingList(Paging paging) {		
		return boardDao.boardAllList(paging);
	}

	@Override
	public int getRecommentCntByBoardNo(Board board) {
		
		return boardDao.recommendCntByBoardNo(board);
	}

	@Override
	public int getWriteBoard(Board board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public Board getViewBoard(Board board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	
	}

	@Override
	public boolean getSelectRecommendById(Board board) {
		return boardDao.selectRecommendById(board);
	}

	@Override
	public List<Comment> getCommentList(Board board) {
		return boardDao.commentList(board);
	}

	@Override
	public int getUpdateBoard(Board board) {
		return boardDao.updateBoard(board);
	}

	@Override
	public int getRecommendAllDeleteByBoardNo(Board board) {
		return boardDao.recommendAllDeleteByBoardNo(board);
	}

	@Override
	public int getCommentsAllDeleteByBoardNo(Board board) {
		return boardDao.commentsAllDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(Board board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public boolean getRecommendBoard(Board board) {
		boolean res = boardDao.selectRecommendById(board);
		if(!res) {
			int r = boardDao.insertRecommend(board);
			if(r>0) System.out.println("게시글 추천 완료!");
			
		}else {
			int r = boardDao.deleteRecommend(board);
			if(r>0) System.out.println("게시글 추천취소 완료!");
		}
		return res;
		
	}

	@Override
	public int getInsertComment(Comment comment) {
		return boardDao.insertComment(comment);
	}

	@Override
	public int getDeleteComment(Comment comment) {
		return boardDao.deleteComment(comment);
	}

}
