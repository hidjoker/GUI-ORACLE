package board.dao.a;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public interface ABoardDao {
	
	// 총 게시글 수 조회
	public int boardAllCnt(Paging paging);
	
	// 총 게시글 리스트 조회
	public List<Board> boardAllList(Paging paging);
	
}
