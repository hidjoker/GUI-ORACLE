package board.service.a;

public class ABoardServiceImpl implements ABoardService{

}
