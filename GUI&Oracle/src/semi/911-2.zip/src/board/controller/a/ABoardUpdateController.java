package board.controller.a;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Board;
import board.service.a.ABoardServiceImpl;

@WebServlet("/board/a/update.do")
public class ABoardUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		
		ABoardServiceImpl service = new ABoardServiceImpl();
		
		Board board = new Board();
		board.setBoardNo(boardNo);
		Board viewBoard = service.getViewBoard(board);
		
		request.setAttribute("board", viewBoard);
		
		request.getRequestDispatcher("/view/board/a/a_update.jsp")
			.forward(request, response);}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		
		System.out.println(title);
		System.out.println(content);
		System.out.println(boardNo);

		Board board = new Board();
		board.setBoardNo(boardNo);
		board.setTitle(title);
		board.setContent(content);
		
		ABoardServiceImpl service =  new ABoardServiceImpl();
		int res = service.getUpdateBoard(board);
		if(res>0) System.out.println("수정 완료!");
		
		response.sendRedirect("/board/a/pagingList.do");	
		
	}

}
