package admin.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.service.AdminService;
import admin.service.AdminServiceImpl;

/**
 * Servlet implementation class adminClassView_Controller
 */
@WebServlet("/adminclass/View.do")
public class adminClassView_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String classname=request.getParameter("classname");
		
		AdminService service = new AdminServiceImpl();
		
		
		
		request.setAttribute("dto", service.view(classname));
		
		request.getRequestDispatcher("/admin/adminClassView.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
