package board.dto;

import java.util.Date;

public class Comments {
	private int rnum;

	private int commentno;
	private int boardno;
	private String writerid;
	private String writer;
	private Date indate;
	private String content;
	
	@Override
	public String toString() {
		return "Comments [commentno=" + commentno + ", boardno=" + boardno + ", writerid=" + writerid + ", writer=" + writer
				+ ", indate=" + indate + ", content=" + content + "]";
	}
	
	public int getCommentno() {
		return commentno;
	}

	public void setCommentno(int commentno) {
		this.commentno = commentno;
	}

	public int getBoardno() {
		return boardno;
	}

	public void setBoardno(int boardno) {
		this.boardno = boardno;
	}

	public String getWriterid() {
		return writerid;
	}

	public void setWriterid(String writerid) {
		this.writerid = writerid;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public Date getIndate() {
		return indate;
	}

	public void setIndate(Date indate) {
		this.indate = indate;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getRnum() {
		return rnum;
	}

	public void setRnum(int rnum) {
		this.rnum = rnum;
	}

	
	
	
}
