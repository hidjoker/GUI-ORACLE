package board.service.a;

import java.util.List;

import board.dao.a.ABoardDaoImpl;
import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public class ABoardServiceImpl implements ABoardService{

	private ABoardDaoImpl boardDao = new ABoardDaoImpl();
	
	@Override
	public int getAllCnt(Paging paging) {
		return boardDao.boardAllCnt(paging);
	}

	@Override
	public List<Board> getPagingList(Paging paging) {		
		return boardDao.boardAllList(paging);
	}

	@Override
	public int getRecommentCntByBoardNo(Board board) {
		
		return boardDao.recommendCntByBoardNo(board);
	}

	@Override
	public int getWriteBoard(Board board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public Board getViewBoard(Board board) {
		return boardDao.viewBoard(board);
	
	}

	@Override
	public boolean getSelectRecommendById(Board board) {
		return boardDao.selectRecommendById(board);
	}

	@Override
	public List<Comment> getCommentList(Board board) {
		return boardDao.commentList(board);
	}

	@Override
	public int getUpdateBoard(Board board) {
		return boardDao.updateBoard(board);
	}

}
