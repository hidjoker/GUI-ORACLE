package member.dao;

import member.dto.Member;

public class MemberDaoImpl implements MemberDao{

	@Override
	public Member login(Member member) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean join(Member member) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkId(String inputId) {
		// TODO Auto-generated method stub
		return false;
	}

}
