package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.Board;
import board.dto.Comments;

public class CommentsDaoImpl implements CommentsDao {

	// DB 연결 객체
	private Connection conn = DBConn.getConnection();

	// JDBC 객체
	private PreparedStatement ps;
	private ResultSet rs;

	// 코멘트 조회
	@Override
	public List selectComment(Board board) {

		String sql = "SELECT * FROM (" + "SELECT rownum rnum, B.* FROM (" + "	SELECT" + "		commentno,"
				+ "		boardno," + "		writerid," + "		writer," + "		indate," + "		content"
				+ "	FROM comments" + "	WHERE boardno = ?" + "	ORDER BY indate DESC" + "	) B" + ") ORDER BY rnum";

		List commentList = new ArrayList();
		try {
			ps = conn.prepareStatement(sql);

			ps.setInt(1, board.getBoardno());

			// ResultSet 반환
			rs = ps.executeQuery();

			while (rs.next()) {
				Comments comments = new Comments();
				comments.setRnum(rs.getInt("rnum"));
				comments.setBoardno(rs.getInt("boardno"));
				comments.setCommentno(rs.getInt("commentno"));
				comments.setWriterid(rs.getString("writerid"));
				comments.setWriter(rs.getString("writer"));
				comments.setIndate(rs.getDate("indate"));
				comments.setContent(rs.getString("content"));

				commentList.add(comments);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		return commentList;
	}

	// 코멘트 INSERT
	@Override
	public void insertComment(Comments comment) {
		String sql = "INSERT INTO comments (commentno,boardno,writerid,writer,content )" + "	VALUES (" + "		comments_seq.nextval,"
				+ "?," + "?," + "?," + "?" + ")";

		try {
			ps = conn.prepareStatement(sql);

			ps.setInt(1, comment.getBoardno());
			ps.setString(2, comment.getWriterid());
			ps.setString(3, comment.getWriter());
			ps.setString(4, comment.getContent());
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	// 댓글 삭제하기
	@Override
	public void deleteComment(Comments comment) {

		String sql = "DELETE comments WHERE commentno = ?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getCommentno());

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 댓글 카운트 - 댓글 존재 여부 확인
	@Override
	public int countComment(Comments comment) {

		String sql = "SELECT COUNT(*) FROM comments WHERE commentno=?";

		int cnt = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, comment.getCommentno());
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return cnt;
	}
}
