package board.controller.s;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Board;
import board.service.s.SBoardServiceImpl;

@WebServlet("/board/s/write.do")
public class SBoardWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/view/board/s/s_write.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		SBoardServiceImpl service =  new SBoardServiceImpl();
		Board board = new Board();
		
		String writerId = (String)request.getSession().getAttribute("logId");
		String writer = (String)request.getSession().getAttribute("logName");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		String to = request.getParameter("msgTo");	
		
		int msgTo=0;
		if(to.equals("admin")) msgTo = 2;
		if(to.equals("teacher")) msgTo = 1;
		
		board.setWriterId(writerId);
		board.setWriter(writer);
		board.setTitle(title);
		board.setContent(content);
		board.setMsgTo(msgTo);
		
		int res = service.getWriteBoard(board);
		if(res>0) System.out.println("게시판 db 추가 성공!");
		
		response.sendRedirect("/board/s/pagingList.do");
	}

}
