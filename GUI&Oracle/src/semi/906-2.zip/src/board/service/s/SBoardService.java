package board.service.s;

import java.util.List;

import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public interface SBoardService {

	// 총 게시글 수 조회
	public int getAllCnt(Paging paging);
	
	// 총 게시글 리스트 얻기
	public List<Board> getPagingList(Paging paging);
	
	// 게시글 입력하기
	public int getWriteBoard(Board board);
	
	// 게시글 뷰 얻기
	public Board getViewBoard(Board board);
	
	// 댓글 얻기
	public Comment getComment(Board board);
	
	// 게시글 코멘트 제거하기
	public int getCommentsAllDeleteByBoardNo(Board board);
	
	// 게시글 삭제하기
	public int getDeleteBoard(Board board);
	
	// 게시글 수정하기
	public int getUpdateBoard(Board board);
	
	// 댓글 추가하기
	public int getInsertComment(Comment comment);
	
	// 댓글 삭제하기
	public int getDeleteComment(Comment comment);
	
	// 댓글 수정하기
	public int getUpdateComment(Comment comment);
	
	// 댓글 수 얻기
	public int getCntCommentByBoardNo(Board board);
	
}
