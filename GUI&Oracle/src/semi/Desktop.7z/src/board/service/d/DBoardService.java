package board.service.d;

public interface DBoardService {

}
