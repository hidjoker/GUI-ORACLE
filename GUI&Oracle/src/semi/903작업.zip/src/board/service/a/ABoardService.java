package board.service.a;

import java.util.List;

import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public interface ABoardService {

	// 총 게시글 수 조회
	public int getAllCnt(Paging paging);
	
	// 총 게시글 리스트 얻기
	public List<Board> getPagingList(Paging paging);
	
	// 해당 게시글 추천수 얻기
	public int getRecommentCntByBoardNo(Board board);
	
	// 게시글 입력하기
	public int getWriteBoard(Board board);
	
	// 게시글 뷰 얻기
	public Board getViewBoard(Board board);
	
	// ID의 추천 여부 조회
	public boolean getSelectRecommendById(Board board);
	
	// 댓글 리스트 얻기
	public List<Comment> getCommentList(Board board);
	
	// 게시글 수정하기
	public int getUpdateBoard(Board board);
}
