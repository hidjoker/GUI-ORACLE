package member.service;

import member.dto.Member;

public interface MemberService {
	
	/**
	 * 
	 * @param member //로그인 요청 Member 객체
	 * @return Member // 로그인 성공시 Member 정보 반환
	 */
	public Member login(Member member);
	
	/**
	 * 
	 * @param member // 회원가입 요청 Member 객체
	 * @return boolean 성공여부 // 서비스 내에서 ID 중복확인 처리하기
	 */
	public boolean join(Member member);
}
