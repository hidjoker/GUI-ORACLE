package board.dao.q;

import java.util.List;

import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public interface QBoardDao {

		// 총 게시글 수 조회(제목)
		public int boardAllCntByTitle(PagingModel paging);
		
		// 총 게시글 수 조회(글번호)
		public int boardAllCntByBoardNo(PagingModel paging);
		
		// 총 게시글 수 조회(작성자)
		public int boardAllCntByWriter(PagingModel paging);
		
		// 총 게시글 수 조회(작성자ID)
		public int boardAllCntByWriterId(PagingModel paging);
		
		// 총 게시글 리스트 조회(제목)
		public List<BoardModel> boardAllListByTitle(PagingModel paging);
		
		// 총 게시글 리스트 조회(글번호)
		public List<BoardModel> boardAllListByBoardNo(PagingModel paging);
		
		// 총 게시글 리스트 조회(작성자)
		public List<BoardModel> boardAllListByWriter(PagingModel paging);
		
		// 총 게시글 리스트 조회(작성자ID)
		public List<BoardModel> boardAllListByWriterId(PagingModel paging);
		
		// 게시글 추가
		public int insertBoard(BoardModel board);
		
		// 게시글 뷰 얻기
		public BoardModel viewBoard(BoardModel board);
		
		// 댓글 리스트 얻기
		public List<CommentModel> commentList(BoardModel board);
		
		// 게시글 조회수 +1
		public void addHit(BoardModel board);
		
		// 게시글 코멘트 제거하기
		public int commentsAllDeleteByBoardNo(BoardModel board);
		
		// 게시글 삭제하기
		public int deleteBoard(BoardModel board);
		
		// 댓글 추가하기
		public int insertComment(CommentModel commnet);
		
		// 댓글 삭제하기
		public int deleteComment(CommentModel comment);
		
		// 댓글 추천 조회하기
		public boolean selectRecommendCommentById(CommentModel comment);
		
		// 댓글 추천 추가하기
		public int insertRecommendComment(CommentModel comment);
		
		// 댓글 추천 취소하기
		public int deleteRecommendComment(CommentModel comment);
		
		// 해당 글 댓글 추천 전부 제거하기
		public int allRecommendDeleteByBoardNo(BoardModel board);
		
		// 해당 댓글 추천 전부 제거하기
		public int allRecommendDeleteByCommentNo(CommentModel comment);
		
		// 댓글 수 얻기
		public int commentCntByBoardNo(BoardModel board);
}
