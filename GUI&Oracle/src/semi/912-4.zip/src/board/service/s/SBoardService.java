package board.service.s;

import java.util.List;

import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public interface SBoardService {

	// 총 게시글 수 조회
	public int getAllCnt(PagingModel paging);
	
	// 총 게시글 리스트 얻기
	public List<BoardModel> getPagingList(PagingModel paging);
	
	// 게시글 입력하기
	public int getWriteBoard(BoardModel board);
	
	// 게시글 뷰 얻기
	public BoardModel getViewBoard(BoardModel board);
	
	// 댓글 얻기
	public CommentModel getComment(BoardModel board);
	
	// 게시글 코멘트 제거하기
	public int getCommentDeleteByBoardNo(BoardModel board);
	
	// 게시글 삭제하기
	public int getDeleteBoard(BoardModel board);
	
	// 댓글 추가하기
	public int getInsertComment(CommentModel comment);
	
	// 댓글 삭제하기
	public int getDeleteComment(CommentModel comment);
	
	// 댓글 수정하기
	public int getUpdateComment(CommentModel comment);
	
	// 댓글 수 얻기
	public int getCntCommentByBoardNo(BoardModel board);
	
}
