package board.dao.f;

public class FBoardDaoImpl implements FBoardDao{

}
