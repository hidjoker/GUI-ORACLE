package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.Member;
import member.dto.MemberAndClass;
import member.service.MemberService;
import member.service.MemberServiceImpl;


@WebServlet("/member/updatemember.do")
public class MemberUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private MemberService service= new MemberServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");

		request.setAttribute("userInformation", service.getMemberInformation(id));
		
		String phone = (String)service.getMemberInformation(id).getPhone();
		
		String phone1 = phone.split("-")[0];
		String phone2 = phone.split("-")[1];
		String phone3 = phone.split("-")[2];
		
		request.setAttribute("phone1", phone1);
		request.setAttribute("phone2", phone2);
		request.setAttribute("phone3", phone3);
		
		String birth = service.getMemberInformation(id).getBirthDay();
		
		String birth1 = birth.split("-")[0];
		String birth2 = birth.split("-")[1];
		String birth3 = birth.split("-")[2];
		
		request.setAttribute("birth1", birth1);
		request.setAttribute("birth2", birth2);
		request.setAttribute("birth3", birth3);
		
		request.getRequestDispatcher("/view/member/updateMember.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		String newPassword = request.getParameter("password");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		String birth1 = (String)request.getParameter("birth1");
		String birth2 = (String)request.getParameter("birth2");
		String birth3 = (String)request.getParameter("birth3");
		
		String birth = birth1+"-"+birth2+"-"+birth3;
		
		// 전화번호
		String phone1 = (String)request.getParameter("phone1");
		String phone2 = (String)request.getParameter("phone2");
		String phone3 = (String)request.getParameter("phone3");
		String phone = phone1+"-"+phone2+"-"+phone3;
		
		
			
		Member member = new Member();
		member.setPassword(newPassword);
		member.setName(name);
		member.setPhone(phone);
		member.setBirthDay(birth);
		member.setEmail(email);
		member.setId((String)session.getAttribute("id"));

		if(service.updateMember(member)==true) {
			System.out.println("회원정보변경 성공");
			out.println("<script>alert('수정되었습니다 !'); location.href='/member/mypage.do';</script>");
			out.flush();
		}
		else {
			System.out.println("정보변경 실패");
		}	
		
		out.close();
		
	}

}
