package board.dao.d;

public interface DBoardDao {

}
