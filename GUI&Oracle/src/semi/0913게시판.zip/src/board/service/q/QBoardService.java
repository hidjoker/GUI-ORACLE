package board.service.q;

import java.util.List;

import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public interface QBoardService {

	// 총 게시글 수 조회
	public int getAllCnt(PagingModel paging);
	
	// 총 게시글 리스트 얻기
	public List<BoardModel> getPagingList(PagingModel paging);
	
	// 게시글 입력하기
	public int getWriteBoard(BoardModel board);
	
	// 게시글 뷰 얻기
	public BoardModel getViewBoard(BoardModel board);
	
	// 댓글 리스트 얻기
	public List<CommentModel> getCommentList(BoardModel board);
	
	// 게시글 코멘트 제거하기
	public int getCommentsAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 삭제하기
	public int getDeleteBoard(BoardModel board);
	
	// 댓글 추가하기
	public int getInsertComment(CommentModel comment);
	
	// 댓글 삭제하기
	public int getDeleteComment(CommentModel comment);
	
	// 댓글 추천하기
	public void getRecommendComment(CommentModel comment);
	
	// 해당 글 댓글 추천 전부 제거
	public int getAllRecommendDeleteByBoardNo(BoardModel board);
	
	// 해당 댓글 추천 전부 제거
	public int getAllRecommendDeleteByCommentNo(CommentModel comment);	
}
