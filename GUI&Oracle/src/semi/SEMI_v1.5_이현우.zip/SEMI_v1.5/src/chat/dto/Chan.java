package chat.dto;

public class Chan {
	String name;
	String hostid;
	String code;
	String userid;
	
	
	@Override
	public String toString() {
		return "Chan [name=" + name + ", hostid=" + hostid + ", code=" + code + ", userid=" + userid + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHostid() {
		return hostid;
	}
	public void setHostid(String hostid) {
		this.hostid = hostid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
}
