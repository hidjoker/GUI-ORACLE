package board.dao.d;

public class DBoardDaoImpl2 implements DBoardDao{

}
