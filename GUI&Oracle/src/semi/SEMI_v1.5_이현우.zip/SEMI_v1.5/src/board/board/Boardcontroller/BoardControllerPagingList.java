package board.board.Boardcontroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.Board;
import board.service.BoardService;
import board.service.BoardServiceImpl;
import board.util.Paging;

@WebServlet("/board/pagingList.do")
public class BoardControllerPagingList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private BoardService boardService = new BoardServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		// 현재 페이지 
		String param = request.getParameter("curPage");

		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				request.getParameter("curPage") );
		}
		
		String search = (String)request.getParameter("search");
		
		if(search == null) {
			int totalCount = boardService.getTotal("board");
			Paging paging = new Paging(totalCount, curPage);
			paging.setSearch(search);
			
			List<Board> boardList = boardService.getPagingList(paging, "board");
			request.setAttribute("boardList", boardList);
			request.setAttribute("paging", paging);
		}else {

			int totalCountSearch = boardService.getTotalSearch(search,"board");
			Paging paging = new Paging(totalCountSearch, curPage);
			paging.setSearch(search);
			
			List<Board> boardListSearch	= boardService.getPagingListSearch(paging,"board");
			
			request.setAttribute("boardList", boardListSearch);
			request.setAttribute("paging", paging);
			
			// Id에 따른 권한 부여
			String id = String.valueOf(session.getAttribute("id"));
			System.out.println(id);
			if (id.equals("ADMIN")) {
				session.setAttribute("level", 2);
			} else {
				String[] arr = id.split("-");
				if (arr[arr.length - 1].equals("0") || arr[arr.length - 1].equals("1")) {
					session.setAttribute("level", 1);
				} else if (arr[arr.length - 1].equals("null")) {
					session.setAttribute("level", -1);
				} else {
					session.setAttribute("level", 0);
				}

				System.out.println(session.getAttribute("level"));
			}
		}

		
		// 포워딩
		request.getRequestDispatcher("/view/board.board/list.jsp")
			.forward(request, response);
		
	}
}









