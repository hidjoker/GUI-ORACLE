package board.controller.s;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Board;
import board.service.s.SBoardServiceImpl;

@WebServlet("/board/s/delete.do")
public class SBoardDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		Board board = new Board();
		board.setBoardNo(boardNo);
		
		SBoardServiceImpl service = new SBoardServiceImpl();
	
		//게시글 코멘트 삭제
		int res = service.getCommentDeleteByBoardNo(board);
		if(res>0) System.out.println("코멘트 삭제 성공");		
		
		//게시글 삭제
		res = service.getDeleteBoard(board);
		if(res>0) System.out.println("게시글 삭제 성공");
		
		response.sendRedirect("/board/s/pagingList.do");
		
	}

}
