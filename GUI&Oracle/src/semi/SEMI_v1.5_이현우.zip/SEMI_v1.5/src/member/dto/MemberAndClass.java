package member.dto;

import java.util.Date;

public class MemberAndClass {

	// MemberDTO
	private String id;
	private String password;
	private String name;
	private String group;
	private String phone;
	private String birthDay;
	private String email;
	private String gender;
	
	// ClassDTO
	private String className;
	private String startDate; 
	private String endDate; 
	private String subject;
	private int stuNo;
	private int total;
	private String teacher;
	private String jobTeacher;
	private String image;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getStuNo() {
		return stuNo;
	}
	public void setStuNo(int stuNo) {
		this.stuNo = stuNo;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getJobTeacher() {
		return jobTeacher;
	}
	public void setJobTeacher(String jobTeacher) {
		this.jobTeacher = jobTeacher;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "MemberAndClass [id=" + id + ", password=" + password + ", name=" + name + ", group=" + group
				+ ", phone=" + phone + ", birthDay=" + birthDay + ", email=" + email + ", gender=" + gender
				+ ", className=" + className + ", startDate=" + startDate + ", endDate=" + endDate + ", subject="
				+ subject + ", stuNo=" + stuNo + ", total=" + total + ", teacher=" + teacher + ", jobTeacher="
				+ jobTeacher + ", image=" + image + "]";
	}
	
	
	
}
