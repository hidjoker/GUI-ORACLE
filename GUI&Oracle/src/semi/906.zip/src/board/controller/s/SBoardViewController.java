package board.controller.s;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.Board;
import board.dto.Comment;
import board.service.s.SBoardServiceImpl;


@WebServlet("/board/s/view.do")
public class SBoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		HttpSession session = request.getSession();
		String writerId = (String)session.getAttribute("logId");
		
		// boardno를 담은 객체
		Board board = new Board();
		board.setBoardNo(boardNo);
		board.setWriterId(writerId);
		
		// 보드 조회
		SBoardServiceImpl service = new SBoardServiceImpl();
		Board viewBoard = service.getViewBoard(board);
		
		// 코멘트 조회
		int commentCnt = service.getCntCommentByBoardNo(board);
		Comment comment = new Comment();
		if(commentCnt > 0) comment = service.getComment(board);
		
		request.setAttribute("board", viewBoard);
		request.setAttribute("comment", comment);
		request.setAttribute("commentCnt", commentCnt);
		
		request.getRequestDispatcher("/view/board/s/s_view.jsp")
			.forward(request, response);	
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
