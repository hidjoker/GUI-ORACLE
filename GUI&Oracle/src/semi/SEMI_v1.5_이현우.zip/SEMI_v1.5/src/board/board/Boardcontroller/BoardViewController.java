package board.board.Boardcontroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Board;
import board.dto.Comments;
import board.dto.Upload;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/board/view.do")
public class BoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BoardService boardService = new BoardServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String param = request.getParameter("boardno");
		
		int boardno=0;
		if(!"".equals(param) && param != null) {
			boardno = Integer.parseInt(param);
		}
		
		Board board = new Board();
		board.setBoardno(boardno);
		
		board = boardService.view(board);
		// 게시글 정보 전달
		request.setAttribute("board", board);
		
		
		//추천수 
		Board recommend = new Board();
		recommend.setBoardno(board.getBoardno());
		recommend.setWriterid((String) request.getSession().getAttribute("writerid") );

		//추천 상태 정보 전달
		request.setAttribute("recommend", boardService.recommendCheck(recommend));
		
		
		// 댓글 정보
		Comments comment = new Comments();
		List commentList = boardService.getCommentList(board);
	
		request.setAttribute("commentList", commentList);
		
		
		
		// 첨부 파일 정보
		List<Upload> result = boardService.getUpFile(board); 
		request.setAttribute("fileList", result);
				
				
		
		request.getRequestDispatcher("/view/board.board/view.jsp")
			.forward(request, response);
	}

}







