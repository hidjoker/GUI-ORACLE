package admin.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.dto.AdminDto;
import admin.dto.AdminUserDto;
import admin.service.AdminService;
import admin.service.AdminServiceImpl;


@WebServlet("/adminuser/update.do")
public class adminUserUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		String userid= (request.getParameter("userid"));
		AdminService service = new AdminServiceImpl();
		
		
		AdminUserDto dto = service.userview(userid);
		request.setAttribute("userinfo", dto);
		
		request.setAttribute("group", dto.getClassname().split("-")[0]);
		request.setAttribute("time", dto.getClassname().split("-")[1]);
		
		//휴대폰 번호
		request.setAttribute("phone1", dto.getPhone().split("-")[0]);
		request.setAttribute("phone2", dto.getPhone().split("-")[1]);
		request.setAttribute("phone3", dto.getPhone().split("-")[2]);
		
		//생일
		request.setAttribute("birth1", dto.getBirth().split("-")[0]);
		request.setAttribute("birth2", dto.getBirth().split("-")[1]);
		request.setAttribute("birth3", dto.getBirth().split("-")[2]);
		
		
		request.getRequestDispatcher("/admin/adminUserUpdate.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		AdminService service = new AdminServiceImpl();
		AdminUserDto dto = new AdminUserDto();
		
		
		//회원이름
		dto.setId(request.getParameter("upuserid"));
		dto.setPw(request.getParameter("upuserpw"));
		dto.setName(request.getParameter("upusername"));
		dto.setPhone(request.getParameter("phone1")+"-"+request.getParameter("phone2")+"-"+request.getParameter("phone3"));
		dto.setBirth(request.getParameter("birth1")+"-"+request.getParameter("birth2")+"-"+request.getParameter("birth3"));
		dto.setGender(request.getParameter("upusergender"));
		System.out.println(request.getParameter("upusergender"));
		
	
		service.userUpdate(dto);
		
		 response.sendRedirect("/admin/user.do?classname="+request.getParameter("upuserclassname"));
	
	}

}
