package member.dto;

public class Group {

	private String className;
	private String startDate; 
	private String endDate; 
	private String subject;
	private int stuNo;
	private int total;
	private String teacher;
	private String jobTeacher;
	private String image;
	
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getStuNo() {
		return stuNo;
	}
	public void setStuNo(int stuNo) {
		this.stuNo = stuNo;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getJobTeacher() {
		return jobTeacher;
	}
	public void setJobTeacher(String jobTeacher) {
		this.jobTeacher = jobTeacher;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "Group [className=" + className + ", startDate=" + startDate + ", endDate=" + endDate + ", subject="
				+ subject + ", stuNo=" + stuNo + ", total=" + total + ", teacher=" + teacher + ", jobTeacher="
				+ jobTeacher + ", image=" + image + "]";
	}
	
	
}
