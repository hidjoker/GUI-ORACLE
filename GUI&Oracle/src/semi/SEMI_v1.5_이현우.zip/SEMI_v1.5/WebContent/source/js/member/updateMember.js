

var checkstate = false;
var checkstate2 = false;


//DB에 있는 비밀번호와 일치하는지 체크
function checkPassword() {

	var pw1 = document.getElementById("pw1").value;
	var params= "pw1="+encodeURIComponent(pw1);
	sendRequest("POST", "/member/checkPassword.do", params, fromServer);
}

function fromServer(){
	if(httpRequest.readyState==4){
		if(httpRequest.status == 200) {
			var res = httpRequest.responseText;

			if(res == "null"){
				document.getElementById('samePassword').style.color = "green";
				document.getElementById('samePassword').innerHTML = "비밀번호를 입력하세요";
				checkstate = false;
			}

			else if(res =="false"){
				document.getElementById('samePassword').style.color = "red";
				document.getElementById('samePassword').innerHTML = "비밀번호 안 맞음";
				checkstate = false;

			}else{
				checkstate = true;
				document.getElementById('samePassword').style.color = "blue";
				document.getElementById('samePassword').innerHTML = "성공";
			}
		}
	}	



}

//새로 입력한 비밀번호와 비밀번호 확인이 같은지 체크
function isSame() {
	var pw2 = document.getElementById('pw2').value;
	var pw3 = document.getElementById('pw3').value;

	if(pw2  == pw3 ){
		document.getElementById('same').style.color = "blue";
		document.getElementById('same').innerHTML = "일치";
		checkstate2 = true;
	}

	else{
		document.getElementById('same').style.color = "red";
		document.getElementById('same').innerHTML = "일치하지 않습니다";
		checkstate2 = false;
	}
}

//새로 입력한 비밀번호와 비밀번호 확인이 같은지 체크
function isSame2() {
	var pw2 = document.getElementById('pw2').value;
	var pw3 = document.getElementById('pw3').value;

	if(pw2  == pw3 ){
		document.getElementById('same').style.color = "blue";
		document.getElementById('same').innerHTML = "일치";
		checkstate2 = true;
	}

	else{
		document.getElementById('same').style.color = "red";
		document.getElementById('same').innerHTML = "일치하지 않습니다";
		checkstate2 = false;
	}
}

function check() {
	var pw1 = document.getElementById('pw1').value;
	var pw2 = document.getElementById('pw2').value;
	var pw3 = document.getElementById('pw3').value;

	if(pw1==''){
		alert('기존 비밀번호를 입력하세요');
		return;
	}

	else if(!checkstate) {
		alert('입력하신 비밀번호가 틀립니다');
		$("#pw1").val("");
		$("#pw2").val("");
		$("#pw3").val("");
		return;
	}

	else if(pw2==''){
		alert('변경할 비밀번호를 입력하세요');
		return;
	}
	else if(pw3==''){
		alert('비밀번호 확인을 입력하세요');
		return;
	}

	else if(pw2.length <8){
		alert('8자리 이상 20자리 이하의 비밀번호를 입력하세요');
		$("#pw2").val("");
		$("#pw3").val("");
		return;
	}

	else{
		if(!checkstate2){
			alert('비밀번호가 일치하지 않습니다');
			$("#pw2").val("");
			$("#pw3").val("");	
			return;
		}
		else{

			var regex = /^.*(?=^.{8,20}$)(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&+=]).*$/; 
			var regex2 = /^[A-Za-z0-9]{8,20}$/;
			var regex3 = /^[0-9]*$/;
			var regex4= /^[a-zA-Z]*$/;
			var regex5 =/^[!@#$%^&+=]*$/;

			// 숫자만 입력했을때
			if(regex3.test(pw2)){
				$("#pw1").val("");
				$("#pw2").val("");
				$("#pw3").val("");	
				$("#password").val(pw2);
				document.getElementById('security').style.color = "red";
				document.getElementById('security').innerHTML = "보안등급 : 위험";
				document.getElementById('samePassword').style.color = "green";
				document.getElementById('samePassword').innerHTML = "비밀번호를 입력하세요";
				document.getElementById('same').innerHTML = "";
				$('#myModal').modal('hide');

				return;
			}
			
			// 문자만 입력했을때
			else if(regex4.test(pw2)){
				$("#pw1").val("");
				$("#pw2").val("");
				$("#pw3").val("");	
				$("#password").val(pw2);
				document.getElementById('security').style.color = "red";
				document.getElementById('security').innerHTML = "보안등급 : 위험";
				document.getElementById('samePassword').style.color = "green";
				document.getElementById('samePassword').innerHTML = "비밀번호를 입력하세요";
				document.getElementById('same').innerHTML = "";
				$('#myModal').modal('hide');

				return;
			}
			
			
			// 특수문자만 입력 했을때
			else if(regex5.test(pw2)){
				$("#pw1").val("");
				$("#pw2").val("");
				$("#pw3").val("");	
				$("#password").val(pw2);
				document.getElementById('security').style.color = "red";
				document.getElementById('security').innerHTML = "보안등급 : 위험";
				document.getElementById('samePassword').style.color = "green";
				document.getElementById('samePassword').innerHTML = "비밀번호를 입력하세요";
				document.getElementById('same').innerHTML = "";
				$('#myModal').modal('hide');

				return;
			}
			
			// 문자, 숫자, 특수문자 모두 입력 했을때
			else if(regex.test(pw2)){
				$("#pw1").val("");
				$("#pw2").val("");
				$("#pw3").val("");	
				$("#password").val(pw2);
				document.getElementById('security').style.color = "blue";
				document.getElementById('security').innerHTML = "보안등급 : 높음";
				document.getElementById('samePassword').style.color = "green";
				document.getElementById('samePassword').innerHTML = "비밀번호를 입력하세요";
				document.getElementById('same').innerHTML = "";
				$('#myModal').modal('hide');
				return;
			}

			// 그 외 나머지
			else {
				$("#pw1").val("");
				$("#pw2").val("");
				$("#pw3").val("");	
				$("#password").val(pw2);
				document.getElementById('security').style.color = "orange";
				document.getElementById('security').innerHTML = "보안등급 : 보통";
				document.getElementById('samePassword').style.color = "green";
				document.getElementById('samePassword').innerHTML = "비밀번호를 입력하세요";
				document.getElementById('same').innerHTML = "";
				$('#myModal').modal('hide');

				
			}



		}
	}


}

function modalCancel() {
	$("#pw1").val("");
	$("#pw2").val("");
	$("#pw3").val("");
	document.getElementById('samePassword').style.color = "blue";
	document.getElementById('samePassword').innerHTML = "비밀번호를 입력하세요";
	document.getElementById('same').innerHTML = "";
	$('#myModal').modal('hide');
}

//비밀번호 모달 성공 시 스크립트
function success() {


}



