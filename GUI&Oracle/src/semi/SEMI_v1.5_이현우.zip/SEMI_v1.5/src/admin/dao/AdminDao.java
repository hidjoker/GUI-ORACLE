package admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import DBUtil.DBConn;
import admin.dto.AdminDto;
import admin.dto.AdminUserDto;


public class AdminDao {

	private Connection conn = DBConn.getConnection();
	// JDBC 객체
		private PreparedStatement ps;
		private PreparedStatement ps2;
		private PreparedStatement ps3;
		private ResultSet rs;
		private ResultSet rs2;

	//전체 조회 - 몇개의 강좌가 개설되었는지
	public int ClassSelect() {
		
		int a = 0;
	
		String sql= "select count(*) from class";
		

			try {
				ps=conn.prepareStatement(sql);
				rs=ps.executeQuery();
				
		
				while(rs.next()) {
					
				a= rs.getInt(1); 
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null)	rs.close();
					if(ps!=null)	ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
					
				}
				
			}
	
			
	
			return a;

		
	
	
}
	//몇 명의 강사가 활동하고 있는지
	public int teacherSelect() {
		
		int a = 0;
		
		String sql= "select count(*) from USERDATA WHERE (ID NOT LIKE '_______') and (ID LIKE '%0' OR ID LIKE '%1')";

			try {
				ps=conn.prepareStatement(sql);
				rs=ps.executeQuery();
				
		
				while(rs.next()) {
					
				a= rs.getInt(1); 
				
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null)	rs.close();
					if(ps!=null)	ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
					
				}
				
			}
	
			
	
			
		
		return a;
	}



	//몇 명의 학생이 수강하고 있는지
public int StudentSelect() {
	
	int b = 0;
	
	String sql= "select count(*) from userdata where NOT((ID LIKE '______') AND (ID LIKE '%0' OR ID LIKE '%1'))";

		try {
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			
	
			while(rs.next()) {
				
			b= rs.getInt(1); 
	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
		}

		

		
	
	return b;
}


//전체 클래스 정보 조회
public List viewClass() {
	
	
	
	List<AdminDto> list = new ArrayList<>();
	String sql="select * from class";
//	String sql2 = "SELECT * , "
//			+ " (SELECT COUNT(*) FROM userdata U WHERE U.className = C.className ) stuno"
//			+ " FROM class C";
	try {
		ps=conn.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		
		AdminDto dto;	
	
	
		
		while(rs.next()) {
		dto= new AdminDto();
				
		String classname=	rs.getString("CLASSNAME");
		int a = stutotal(classname);
		dto.setClassname(classname);
		dto.setStartdate((rs.getString("STARTDATE")));
		dto.setEnddate(rs.getString("ENDDATE"));
		dto.setSubject(rs.getString("SUBJECT"));
//		dto.setStuno(rs.getInt("STUNO"));	//원래버전
		dto.setStuno(a);
		dto.setTotal(rs.getInt("TOTAL"));
		dto.setTeacher(rs.getString("TEACHER"));
		dto.setJobteacher(rs.getString("JOBTEACHER"));
		dto.setImage(rs.getString("IMAGE"));
		

		
		list.add(dto);
		}
				
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	return list;
	


}

//클래스 상세 조회
public AdminDto view(String classname) {
	
	String sql="select * from class where CLASSNAME='"+classname+"'";
	
	AdminDto dto = new AdminDto();
	try {
		ps=conn.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		
	
	
		while(rs.next()) {
		dto.setClassname(rs.getString("CLASSNAME"));
		dto.setStartdate(rs.getString("STARTDATE"));
		dto.setEnddate(rs.getString("ENDDATE"));
		dto.setSubject(rs.getString("SUBJECT"));
		dto.setStuno(stutotal(rs.getString("CLASSNAME")));
		dto.setTotal(rs.getInt("TOTAL"));
		dto.setTeacher(rs.getString("TEACHER"));
		dto.setJobteacher(rs.getString("JOBTEACHER"));
		dto.setImage(rs.getString("IMAGE"));
		}
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	return dto;

}
//클래스 이미지 수정
public void imgmodify(String imgurl, String classname) {

	String sql ="UPDATE CLASS SET IMAGE=? WHERE CLASSNAME=?";
			
	try {
	
		ps=conn.prepareStatement(sql);
		ps.setString(1, imgurl);
		ps.setString(2, classname);
		
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	

}
//클래스 생성

public boolean createClass(AdminDto dto) {
	
	String sql="INSERT INTO class(CLASSNAME, STARTDATE, ENDDATE, SUBJECT, STUNO, TOTAL, TEACHER, JOBTEACHER, IMAGE)"
			+" VALUES (?,?,?,?,?,?,?,?,?)";


	
boolean a=false;	
			
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, dto.getClassname());
			ps.setString(2, dto.getStartdate());
			ps.setString(3, dto.getEnddate());
			ps.setString(4, dto.getSubject());
			ps.setInt(5, dto.getStuno());
			ps.setInt(6, dto.getTotal());
			ps.setString(7, dto.getTeacher());
			ps.setString(8, dto.getJobteacher());
			ps.setString(9, dto.getImage());

			
			a=ps.executeQuery() != null;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
		}
		return a;
	
		
	
}


// 클래스 체그

public boolean checkclass(String param) {
	boolean result = true;
	String sql="select count(*) from class where CLASSNAME=?";
	
	try {
		ps=conn.prepareStatement(sql);
		ps.setString(1, param);
		rs = ps.executeQuery();
		while(rs.next()) {
			if(rs.getInt(1)>0) {
				result = false;
			}
		}
	} catch (SQLException e) {
				e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	return result;
}


//계정 생성

public int createUser(AdminDto dto) {
	
	
	//학생
	String sql="INSERT INTO USERDATA"
			+ " (ID, PW, NAME, CLASS, PHONE, BIRTH, EMAIL, GENDER) "
			+ " VALUES (?, ?, '0000', ?, '000-000-0000', '0000-00-00', '000000@000000', '0000')";
	//강사 
	String sql2="INSERT INTO USERDATA"
			+ " (ID, PW, NAME, CLASS, PHONE, BIRTH, EMAIL, GENDER) "
			+ " VALUES (?, ?, ?, ?, '000-000-0000', '0000-00-00', '000000@000000', '0000')";
	
	
	
	//취엄담임
	String sql3="INSERT INTO USERDATA"
			+ " (ID, PW, NAME, CLASS, PHONE, BIRTH, EMAIL, GENDER) "
			+ " VALUES (?, ?, ?, ?, '000-000-0000', '0000-00-00', '000000@000000', '0000')";
	
	
	List<ResultSet> list = new ArrayList<>();
	
	try {
		
		//학생
		for(int i =2; i<=dto.getStuno()+1; i++) {
			ps=conn.prepareStatement(sql);
			//아이디
			ps.setString(1, dto.getClassname()+"-"+Integer.toString(i));
			//패스워드 디폴트넣을거면 지우기
			ps.setString(2, "0000");
			ps.setString(3, dto.getClassname());
			
			
			list.add(ps.executeQuery());
			
					
		}
		
		//담당강사
		ps2= conn.prepareCall(sql2);
		ps2.setString(1, dto.getClassname()+"-0");
		ps2.setString(2, "0000");
		ps2.setString(3, dto.getTeacher());
		ps2.setString(4, dto.getClassname());
		ps2.executeUpdate();
	
		//취업담임
		ps3= conn.prepareCall(sql3);
		ps3.setString(1, dto.getClassname()+"-1");
		ps3.setString(2, "0000");
		ps3.setString(3, dto.getJobteacher());
		ps3.setString(4, dto.getClassname());
		ps3.executeUpdate();
		

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	
	
	return list.size();
}


//종강처리
public boolean classclose(String classname) {
	
	
	//학생 지우기
	String sql="delete userdata where class='"+classname+"'";
	
	// 클래스지우기
	String sql2="delete class where classname='"+classname+"'";
	
	try {
	
	
		ps=conn.prepareStatement(sql);
		ps2=conn.prepareStatement(sql2);
		
		
		//해당하는 유저데이터가 없으면    두번째 조건은 실행하지 않음
		if(ps.executeUpdate()>0 && ps2.executeUpdate()>0) {
			
			return true;
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	return false;
	

}

//유저정보 조회 제이슨버전
public JsonArray userinfo(String classname) {
	
	


	JsonArray jsArr = new JsonArray();
	String sql="select * from userdata where class='"+classname+"'";
	
	try {
		ps=conn.prepareStatement(sql);
		rs=ps.executeQuery();
		int i = 1;
		while(rs.next()) {
			
		
			JsonArray obj = new JsonArray(); 
			obj.add(i);
			obj.add(rs.getString("ID"));		
			obj.add(rs.getString("PW"));		
			obj.add(rs.getString("NAME"));		
			obj.add(rs.getString("CLASS"));	
			obj.add(rs.getString("PHONE"));	
			obj.add(rs.getString("BIRTH"));	
			obj.add(rs.getString("EMAIL"));	
			obj.add(rs.getString("GENDER"));	
			
			jsArr.add(obj);
			
			i++;
			}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	return jsArr;
}


//유저 조회 리스트버전
public List userinfoListVersion(String classname) {
	
	


	ArrayList<AdminUserDto> list = new ArrayList<>();
	String sql="select * from userdata where class='"+classname+"'";
	int i =1;
	try {
		ps=conn.prepareStatement(sql);
		rs=ps.executeQuery();
	
		while(rs.next()) {
			
		
		AdminUserDto dto = new AdminUserDto();
			dto.setNum(i);
			dto.setId(rs.getString("ID"));		
			dto.setPw(rs.getString("PW"));		
			dto.setName(rs.getString("NAME"));		
			dto.setClassname(rs.getString("CLASS"));	
			dto.setPhone(rs.getString("PHONE"));	
			dto.setBirth(rs.getString("BIRTH"));
			dto.setEmail(rs.getString("EMAIL"));	
			dto.setGender(rs.getString("GENDER"));	
			
			list.add(dto);
			i++;
		
			}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	return list;
}

//클래스 정보 업데이트
public void classupdate(AdminDto dto) {
	

	
	String sql="UPDATE CLASS SET STARTDATE = ?,"
			+" ENDDATE = ?,"
			+" SUBJECT = ?,"
			+" TOTAL = ? WHERE CLASSNAME=?";
	


			
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, dto.getStartdate());
			ps.setString(2, dto.getEnddate());
			ps.setString(3, dto.getSubject());
			ps.setInt(4, dto.getTotal());
			ps.setString(5, dto.getClassname());
		

			
			ps.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
		}
		
	
	
}

//유저정보조회
public AdminUserDto userview(String userid) {
	
	String sql="select * from userdata where ID='"+userid+"'";
	AdminUserDto dto = new AdminUserDto();
	try {
		ps=conn.prepareStatement(sql);
		rs= ps.executeQuery();
		
		while(rs.next()) {
		dto.setId(rs.getString("ID"));		
		dto.setPw(rs.getString("PW"));		
		dto.setName(rs.getString("NAME"));		
		dto.setClassname(rs.getString("CLASS"));	
		dto.setPhone(rs.getString("PHONE"));	
		dto.setBirth(rs.getString("BIRTH"));
		dto.setEmail(rs.getString("EMAIL"));	
		dto.setGender(rs.getString("GENDER"));	
		}
		
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	return dto;
}

public void deleteuser(String userid) {
	String sql="delete userdata where ID='"+userid+"'";
	try {
		ps=conn.prepareStatement(sql);
		ps.executeUpdate();
	} catch (SQLException e) {

		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
}


//유저 업데이트

public void userUpdate(AdminUserDto dto) {
	
	String sql="UPDATE userdata SET PW = ?,"
			+" NAME = ?,"
			+" PHONE = ?,"
			+" BIRTH = ?,"
			+" GENDER = ? WHERE ID=?";
	


			
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, dto.getPw());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getPhone());
			ps.setString(4, dto.getBirth());
			ps.setString(5, dto.getGender());
			ps.setString(6, dto.getId());
		

			
			ps.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
		}
		


}
//학생 수 조회
public int stutotal(String classname) {
	
	int a = 0;
String sql= "select count(*) from userdata where (CLASS='" + classname + "') AND NOT((ID LIKE '%0' OR ID LIKE '%1') AND(ID LIKE '______'))";


	try {
		ps=conn.prepareStatement(sql);
		rs2=ps.executeQuery();
		
	
	
		rs2.next(); 
		a= rs2.getInt(1);
	
		
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			if(rs!=null)	rs.close();
			if(ps!=null)	ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
	}
	

	
	
	return a;
}
}