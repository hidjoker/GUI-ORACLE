package board.service.a;

import java.util.List;

import board.dao.a.ABoardDaoImpl;
import board.dto.Board;
import board.util.Paging;

public class ABoardServiceImpl implements ABoardService{

	private ABoardDaoImpl boardDao = new ABoardDaoImpl();
	
	@Override
	public int getAllCnt(Paging paging) {
		return boardDao.boardAllCnt(paging);
	}

	@Override
	public List<Board> getPagingList(Paging paging) {		
		return boardDao.boardAllList(paging);
	}

}
