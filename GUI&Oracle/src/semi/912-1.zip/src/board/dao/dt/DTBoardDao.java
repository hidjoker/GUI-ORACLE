package board.dao.dt;

import java.util.List;

import board.dto.Board;
import board.dto.BoardFile;
import board.util.Paging;

public interface DTBoardDao {
	
	// upload boardNo 조회(ALL)
	public int uploadBoardNo();
	
	// 총 게시글 수 조회(+제목)
	public int boardAllCntByTitle(Paging paging);
	
	// 총 게시글 수 조회(글번호)
	public int boardAllCntByBoardNo(Paging paging);
	
	
	// 총 게시글 리스트 조회(+제목)
	public List<Board> boardAllListByTitle(Paging paging);
	
	// 총 게시글 리스트 조회(글번호)
	public List<Board> boardAllListByBoardNo(Paging paging);
	
	// 게시글 추가
	public int insertBoard(Board board);
	
	// 게시글 뷰 얻기
	public Board viewBoard(Board board);
	
	// 게시글 수정하기
	public int updateBoard(Board board);
	
	// 게시글 조회수 +1
	public void addHit(Board board);
	
	// 게시글 첨부파일 제거하기
	public int filesAllDeleteByBoardNo(Board board);
	
	// 게시글 삭제하기
	public int deleteBoard(Board board);

	// 파일 추가하기
	public int insertFile(BoardFile file);
	
	// 파일 리스트 얻기
	public List<BoardFile> fileList(Board board);
	
}
