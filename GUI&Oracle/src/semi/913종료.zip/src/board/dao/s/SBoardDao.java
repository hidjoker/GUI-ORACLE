package board.dao.s;

import java.util.List;

import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public interface SBoardDao {
	
	// 총 게시글 수 조회(타이틀-보낸사람)
	public int boardAllCntMsgFromByTitle(PagingModel paging);
	
	// 총 게시글 수 조회(작성자-받는사람)
	public int boardAllCntMsgToByWriter(PagingModel paging);
	
	// 총 게시글 수 조회(작성자ID-받는사람)
	public int boardAllCntMsgToByWriterId(PagingModel paging);
	
	// 총 게시글 수 조회(타이틀-받는사람)
	public int boardAllCntMsgToByTitle(PagingModel paging);
	
	// 총 게시글 수 조회(답변여부)
	public int boardAllCntByAnswer(PagingModel paging);
	
	// 총 게시글 리스트 조회(타이틀-보낸사람)
	public List<BoardModel> boardAllListMsgFromByTitle(PagingModel paging);
	
	// 총 게시글 리스트 조회(작성자-받는사람)
	public List<BoardModel> boardAllListMsgToByWriter(PagingModel paging);
	
	// 총 게시글 리스트 조회(작성자ID-받는사람)
	public List<BoardModel> boardAllListMsgToByWriterId(PagingModel paging);
	
	// 총 게시글 리스트 조회(타이틀-받는사람)
	public List<BoardModel> boardAllListMsgToByTitle(PagingModel paging);
	
	// 총 게시글 리스트 조회(답변여부)
	public List<BoardModel> boardAllListByAnswer(PagingModel paging);
	
	// 게시글 추가
	public int insertBoard(BoardModel board);
	
	// 게시글 뷰 얻기
	public BoardModel viewBoard(BoardModel board);
	
	// 댓글 얻기
	public CommentModel selectComment(BoardModel board);
	
	// 게시글 조회수 +1
	public void addHit(BoardModel board);
	
	// 게시글 코멘트 제거하기
	public int commentDeleteByBoardNo(BoardModel board);
	
	// 게시글 삭제하기
	public int deleteBoard(BoardModel board);
	
	// 댓글 추가하기
	public int insertComment(CommentModel comment);
	
	// 댓글 삭제하기
	public int deleteComment(CommentModel comment);
	
	// 댓글 수정하기
	public int updateComment(CommentModel comment);
	
	// 댓글 수 얻기
	public int commentCntByBoardNo(BoardModel board);
	

	
	//
	
}
