package chat.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import chat.service.ChatService;


@WebServlet("/chat/join.do")
public class ChatJoinController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//서비스 join 채팅방 name return
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String uid = request.getParameter("joinchancode");
		ChatService cs = new ChatService();
		String result = cs.join(uid , (String)request.getSession().getAttribute("id"));
		System.out.println("return : " + result);
		out.print(result);
	}

}
