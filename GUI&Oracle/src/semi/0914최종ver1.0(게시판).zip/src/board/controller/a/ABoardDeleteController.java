package board.controller.a;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.BoardModel;
import board.service.a.ABoardServiceImpl;


@WebServlet("/board/a/delete.do")
public class ABoardDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		BoardModel board = new BoardModel();
		board.setBoardNo(boardNo);
		
		ABoardServiceImpl service = new ABoardServiceImpl();

		//게시글 추천 삭제
		int res = service.getRecommendAllDeleteByBoardNo(board);
		if(res>0) System.out.println("추천 삭제 성공");
		
		//게시글 코멘트 삭제
		res = service.getCommentsAllDeleteByBoardNo(board);
		if(res>0) System.out.println("코멘트 삭제 성공");		
		
		//게시글 삭제
		res = service.getDeleteBoard(board);
		if(res>0) System.out.println("게시글 삭제 성공");
		
		response.sendRedirect("/board/a/pagingList.do");
	
	}


}
