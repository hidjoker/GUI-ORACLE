package board.service.q;

import java.util.List;

import board.dao.q.QBoardDaoImple;
import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public class QBoardServiceImpl implements QBoardService{

	QBoardDaoImple boardDao = new QBoardDaoImple();
	
	@Override
	public int getAllCnt(PagingModel paging) {
		String word = paging.getWord();
		int cnt = 0;
		if(word.equals("title")){
			cnt = boardDao.boardAllCntByTitle(paging);
		}else if(word.equals("boardNo")) {
			cnt = boardDao.boardAllCntByBoardNo(paging);
		}else if(word.equals("writer")) {
			cnt = boardDao.boardAllCntByWriter(paging);
		}else if(word.equals("writerId")) {
			cnt = boardDao.boardAllCntByWriterId(paging);
		}
		return cnt;
	}

	@Override
	public List<BoardModel> getPagingList(PagingModel paging) {
		String word = paging.getWord();
		List<BoardModel> list = null;
		if(word.equals("title")){
			list = boardDao.boardAllListByTitle(paging);
		}else if(word.equals("boardNo")) {
			list = boardDao.boardAllListByBoardNo(paging);
		}else if(word.equals("writer")) {
			list = boardDao.boardAllListByWriter(paging);
		}else if(word.equals("writerId")) {
			list = boardDao.boardAllListByWriterId(paging);
		}
		return list;
	}

	@Override
	public int getWriteBoard(BoardModel board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public BoardModel getViewBoard(BoardModel board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public List<CommentModel> getCommentList(BoardModel board) {
		return boardDao.commentList(board);
	}

	@Override
	public int getCommentsAllDeleteByBoardNo(BoardModel board) {
		return boardDao.commentsAllDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(BoardModel board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public int getInsertComment(CommentModel comment) {
		return boardDao.insertComment(comment);
	}

	@Override
	public int getDeleteComment(CommentModel comment) {
		return boardDao.deleteComment(comment);
	}

	@Override
	public void getRecommendComment(CommentModel comment) {
		boolean res = boardDao.selectRecommendCommentById(comment);
		if(!res) {
			int r = boardDao.insertRecommendComment(comment);
			if(r>0) System.out.println("댓글 추천 완료!");
			
		}else{
			int r = boardDao.deleteRecommendComment(comment);
			if(r>0) System.out.println("댓글 추천취소 완료!");
		}
	}

	@Override
	public int getAllRecommendDeleteByBoardNo(BoardModel board) {
		return boardDao.allRecommendDeleteByBoardNo(board);
	}

	@Override
	public int getAllRecommendDeleteByCommentNo(CommentModel comment) {
		return boardDao.allRecommendDeleteByCommentNo(comment);
	}

}
