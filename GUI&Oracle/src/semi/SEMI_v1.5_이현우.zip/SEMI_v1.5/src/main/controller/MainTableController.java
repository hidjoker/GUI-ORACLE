package main.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.dao.MainBoardDao;
import main.dto.MainBoardDto;

/**
 * Servlet implementation class TableController
 */
@WebServlet("/main/bodytable.do")
public class MainTableController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		request.setCharacterEncoding("UTF-8");
			// 응답객체 문서 형식 설정(+인코딩)
			response.setContentType("text/html;charset=utf-8");
    		
    		String tableType = request.getParameter("tabletype");
    		String orderby = request.getParameter("orderby");
    		String desc = request.getParameter("desc");
    		String boardName = request.getParameter("boardname");
    		String adress = request.getParameter("adress");
    		
    		
    		MainBoardDao dao = new MainBoardDao();
			//조회 테이블, 오더바이 기준,  오름/내림차순
    		ArrayList<MainBoardDto> list = dao.select(tableType,orderby,desc);
    		request.setAttribute("list", list);
    		request.setAttribute("name", boardName);
    		request.setAttribute("adress", adress);
    		
    		request.getRequestDispatcher("/view/main/semi_main_table.jsp").forward(request, response);

 
    		
    	}


}
