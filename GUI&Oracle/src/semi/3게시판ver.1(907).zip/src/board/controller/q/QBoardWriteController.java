package board.controller.q;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Board;
import board.service.q.QBoardServiceImpl;


@WebServlet("/board/q/write.do")
public class QBoardWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/view/board/q/q_write.jsp")
			.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		QBoardServiceImpl service =  new QBoardServiceImpl();
		Board board = new Board();
		String writerId = (String)request.getSession().getAttribute("logId");
		String writer = (String)request.getSession().getAttribute("logName");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
				
		board.setWriterId(writerId);
		board.setWriter(writer);
		board.setTitle(title);
		board.setContent(content);
		
		int res = service.getWriteBoard(board);
		if(res>0) System.out.println("게시판 db 추가 성공!");
		
		response.sendRedirect("/board/q/pagingList.do");
	}

}
