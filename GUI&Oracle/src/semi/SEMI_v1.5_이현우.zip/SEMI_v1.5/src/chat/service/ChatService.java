package chat.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import chat.dao.ChatDao;
import chat.dto.Chan;
import chat.dto.Chat;
import chat.util.SendMail;
import member.dao.MemberDao;
import member.dao.MemberDaoImpl;

public class ChatService {
	private ChatDao chatDao = new ChatDao();
	
	public List<Chan> checkChan(String userid) {
		return chatDao.checkChan(userid);
	}
	
	public void write(Chat chat) {
		chatDao.write(chat);
		if((chat.getMsg()).substring(0, 1).equals("!")) {//명령어 체크 리스트
			help(chat);
		}
	
	}
	
	public void exit(String chancode,String userid) {
		chatDao.exitChan(chancode, userid);
	}
	
	public List<String> proc(String lastReq,String chancode){
		return chatDao.proc(lastReq, chancode);
	}

	public String create(Chan chan) {
		if(chatDao.selectChanName(chan.getName())) {
			String uid = chatDao.createChan(chan);
			 // 이메일로 UUID 발송(chan.getHostid)/uid
			try {
				MemberDao md = new MemberDaoImpl();
//				new SendMail(md.MemberFind(chan.getHostid()).getEmail(),uid,chan.getHostid(),chan.getName());
			} catch (Exception e) {
				e.printStackTrace();
			}
			chatDao.updateChan(uid, chan.getHostid());
			 return uid;
		}
		else {
			return "false";
		}
	}
	public String join(String uid, String userid) {
		chatDao.updateChan(uid,userid); 
		return chatDao.joinChan(uid);
	}
	
	public void help(Chat chat) {
		String str = chat.getMsg().substring(1);
		Chat ct = new Chat();
		ct.setName("YJBot");
		if(str.equals("쉬는시간")) {
			
			SimpleDateFormat time = new SimpleDateFormat("a:hh:mm");
			String[] arr = time.format(new Date()).split(":");
			int hour = Integer.parseInt(arr[1]);
			int min = Integer.parseInt(arr[2]);
			int res = 0;

			if(hour < 6) {
				res = 15-min;
			}else if(hour == 6 && min < 15) {
				res = 15-min;
			}
			else {
				res = 30-min;
			}
			
			if(res < 0) res += 60;
			ct.setMsg("다음 쉬는 시간까지 남은시간은 " + res+ "분 입니다.");
			
		}
		else if(str.equals("?")) {
			ct.setMsg("준비중 입니다.");
		}
		else {
			ct.setMsg("뭐요");
		}
		ct.setChan(chat.getChan());
		chatDao.write(ct);
	}
}
