package member.dao;

import member.dto.Group;
import member.dto.Member;
import member.dto.MemberAndClass;

public interface MemberDao {
	/**
	 * 
	 * @param member // 로그인 요청 Member 객체
	 * @return int // DB 검색 후 유저정보 반환 // 로그인 요청 응답
	 */
	
	// 아이디 비밀번호에 따른 로그인 확인
	public int login(Member member);
	
	// 아이디에 따른 회원이름
	public Member selectUserInfo(String id);
	
	public String selectName(Member member);
	
	public MemberAndClass Info(String id);
	
	public String userPassword(String id);
	
	// 마이페이지에 보여질 정보
	public MemberAndClass myPageInfo(String id);
	
	// 회원수정페이지에 보여질 정보
	public Member MemberInfo(String id);
	
	// 비밀번호 찾기
	public Member passwordSearch(String id, String name, String email );
	
	// 회원정보 수정
	public int update(Member member);
	
	// 반 생성
	public int insertClass(Group group);
	
	// 비밀번호 찾기 변경
	public int changePassword(String pw, String id, String name, String email);
	
	/**
	 * 
	 * @param member // 회원가입 요청 Member 객체
	 * @return boolean // 회원가입 성공 여부 // 회원가입 요청 응답
	 */
	public boolean join(Member member);
	/**
	 * @param String : inputId //중복확인 ID 값
	 * @return boolean // 중복 확인 여부 ( 이미 존재하는 아이디일 경우 false)
	 */
	public boolean checkId(String inputId);
}
