 


$(document).ready(function() {
		$("#logo").click(function() {
			$(location).attr("href", "/main.do");
		});
 });
 

//DB에 있는 비밀번호와 일치하는지 체크
function searchpassword() {

	var inputId = document.getElementById("inputId").value;
	var inputName = document.getElementById("inputName").value;
	var inputEmail = document.getElementById("inputEmail").value;

	var params= "inputId="+encodeURIComponent(inputId)+
					"&inputName="+encodeURIComponent(inputName)+
					"&inputEmail="+encodeURIComponent(inputEmail);

	sendRequest("POST", "/member/searchpassword.do", params, fromServer);
	
	
}

function fromServer(){
	if(httpRequest.readyState==4){
		if(httpRequest.status == 200) {
			var res = httpRequest.responseText;

			if(res == "null"){
				alert('회원정보를 입력하세여');
				
				return;
			}
			
			else if(res == "fail"){

				alert('일치하는 정보가 없습니다');
				$("#inputId").val("");
				$("#inputName").val("");
				$("#inputEmail").val("");
				return;
			}

			else {
				$("#inputId").val("");
				$("#inputName").val("");
				$("#inputEmail").val("");
				alert(res);
				$("#searchModal").modal('hide');
			}
			
		}
	

	}

}

function cancels() {
	console.log('modal cc');
	$("#inputId").val("");
	$("#inputName").val("");
	$("#inputEmail").val("");
	$("#searchModal").modal('hide');
}
 