package board.dao.s;

public interface SBoardDao {

}
