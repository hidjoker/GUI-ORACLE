package board.board.Noticecontroller;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import board.dto.Board;
import board.dto.Upload;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/notice/write.do")
public class NoticeWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BoardService boardService = new BoardServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/view/board.notice/write.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		ServletContext context = getServletContext();
		String saveDirectory = context.getRealPath("upload");
		int maxPostSize = 10 * 1024 * 1024; // 10MB
		String encoding = "UTF-8";
		FileRenamePolicy policy = new DefaultFileRenamePolicy();
		MultipartRequest mul = new MultipartRequest(request, saveDirectory, maxPostSize, encoding, policy);

		Board board = new Board();

		board.setTitle(mul.getParameter("title"));
		board.setContent(mul.getParameter("content"));
		board.setBoardtype("notice");
		board.setWriterid((String) request.getSession().getAttribute("id"));
		board.setWriter((String) request.getSession().getAttribute("name"));

		File up = mul.getFile("file");

		if (up == null || !up.exists()) {

			boardService.write(board);

		} else {
			Upload file = new Upload();

//			file.setBoardno(board.getBoardno());
			file.setBefore(mul.getOriginalFileName("file"));
			file.setAfter(mul.getFilesystemName("file"));

			boardService.write(board, file);

		}

		// 리다이렉트
		response.sendRedirect("/notice/pagingList.do");
	}

}
