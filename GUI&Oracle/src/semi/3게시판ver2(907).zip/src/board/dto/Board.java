package board.dto;

public class Board {

	private int boardNo;
	private String writerId;
	private String writer;
	private String title;
	private String content;
	private int hit;
	private String boardType;
	private int enable;
	private String inDate;
	private int msgTo; //건의게시판 전용
	private int recommend; //익명게시판 전용 
	private int commentCnt;
	
	
	@Override
	public String toString() {
		return "Board [boardNo=" + boardNo + ", writerId=" + writerId + ", writer=" + writer + ", title=" + title
				+ ", content=" + content + ", hit=" + hit + ", boardType=" + boardType + ", enable=" + enable
				+ ", inDate=" + inDate + ", msgTo=" + msgTo + ", recommend=" + recommend + "]";
	}
	

	public int getCommentCnt() {
		return commentCnt;
	}
	public void setCommentCnt(int commentCnt) {
		this.commentCnt = commentCnt;
	}
	public int getRecommend() {
		return recommend;
	}
	public void setRecommend(int recommend) {
		this.recommend = recommend;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getWriterId() {
		return writerId;
	}
	public void setWriterId(String writerId) {
		this.writerId = writerId;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getBoardType() {
		return boardType;
	}
	public void setBoardType(String boardType) {
		this.boardType = boardType;
	}
	public int getEnable() {
		return enable;
	}
	public void setEnable(int enable) {
		this.enable = enable;
	}
	public String getInDate() {
		return inDate;
	}
	public void setInDate(String inDate) {
		this.inDate = inDate;
	}
	public int getMsgTo() {
		return msgTo;
	}
	public void setMsgTo(int msgTo) {
		this.msgTo = msgTo;
	}
	
	
}
