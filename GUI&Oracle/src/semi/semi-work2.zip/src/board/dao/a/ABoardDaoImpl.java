package board.dao.a;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.Board;
import board.util.Paging;

public class ABoardDaoImpl implements ABoardDao {

	//멤버필드
	private Connection conn = DBConn.getConnection();
	private Statement st = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	// 총 게시글 수 조회
	@Override
	public int boardAllCnt(Paging paging) {
		
		String sql = "SELECT count(*) FROM board Where title Like ?"
				+ " AND boardtype='A' AND enable=1";	
		
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			 search="%"+search +"%";
		}else {
			search="%%";
		}
		
		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, search);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("총 게시글 수 : "+cnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(rs!=null) rs.close();
					if(st!=null) st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return cnt;
	}

	// 총 게시글 리스트 얻기
	@Override
	public List<Board> boardAllList(Paging paging) {
		
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board" + 
		"        WHERE title LIKE ? AND boardtype='A' AND enable=1" +
		"        ORDER BY boardno DESC" + 
		"    ) B" + 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN ? AND ?";
	
		// 검색어 처리
		String search = paging.getSearch();
		if( !"".equals(search) && search != null ) {
			search="%"+search +"%";
		}else {
			search="%%";
		}	
		
		ArrayList<Board> boardList = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, search);
			ps.setInt(2, paging.getStartNo() );
			ps.setInt(3, paging.getEndNo() );

			// ResultSet 반환
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				Board board = new Board();
				
				board.setBoardNo(rs.getInt(1));
				board.setWriterId(rs.getString(2));
				board.setWriter(rs.getString(3));
				board.setTitle(rs.getString(4));
				board.setContent(rs.getString(5));
				board.setHit(rs.getInt(6));
				board.setBoardType(rs.getString(7));
				board.setInDate(rs.getDate(9));
	
				boardList.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return boardList;
		
	}

}
