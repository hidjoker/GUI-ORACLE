package main.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DBUtil.DBConn;
import board.dao.BoardDao;
import board.dao.BoardDaoImpl;
import main.dto.MainBoardDto;

public class MainBoardDao {

	private Connection conn = DBConn.getConnection();
	// JDBC 객체
		private PreparedStatement ps;
		private ResultSet rs;
	//공지사항

	public ArrayList select(String tabletype, String orderby, String desc) {
		

		ArrayList<MainBoardDto> list = new ArrayList<>();
		String sql
		= "SELECT * FROM (" + 
		"    SELECT rownum rnum, B.* FROM (" + 
		"        SELECT * FROM board WHERE ENABLE= 1"+ 
		"        ORDER BY "+orderby+" "+desc+ 
		"    ) B WHERE BOARDTYPE= '"+tabletype+"'"+ 
		"    ORDER BY rnum" + 
		" )" + 
		" WHERE rnum BETWEEN 1 AND 5";
	
		try {
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();

		
			while(rs.next()) {
			MainBoardDto board = new MainBoardDto();
			board.setBoardno( rs.getInt("boardno") );
			board.setTitle( rs.getString("title") );
			board.setWriterid( rs.getString("writerid") );
			board.setWriter( rs.getString("writer") );
			board.setContent( rs.getString("content") );
			board.setHit( rs.getInt("hit") );
			board.setWrittendate( rs.getDate("indate") );
			
			list.add(board);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	rs.close();
				if(ps!=null)	ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
		}
		return list;
		
	
	
}
	
}
