package board.controller.s;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import board.dto.BoardModel;
import board.dto.CommentModel;
import board.service.s.SBoardServiceImpl;


@WebServlet("/board/s/view.do")
public class SBoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		HttpSession session = request.getSession();
		String writerId = (String)session.getAttribute("id");
		
		// boardno를 담은 객체
		BoardModel board = new BoardModel();
		board.setBoardNo(boardNo);
		board.setWriterId(writerId);
		
		// 보드 조회
		SBoardServiceImpl service = new SBoardServiceImpl();
		BoardModel viewBoard = service.getViewBoard(board);
		
		// 코멘트 조회
		int commentCnt = service.getCntCommentByBoardNo(board);
		CommentModel comment = new CommentModel();
		if(commentCnt > 0) comment = service.getComment(board);
		
		request.setAttribute("board", viewBoard);
		request.setAttribute("comment", comment);
		
		request.getRequestDispatcher("/view/board/s/s_view.jsp")
			.forward(request, response);	
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();

		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		String commentWriter = request.getParameter("commentwriter");
		String commentId = request.getParameter("commentid");
		String content = request.getParameter("content");
		String sort = request.getParameter("sort");
			
		CommentModel comment = new CommentModel();
		comment.setBoardNo(boardNo);
		comment.setWriter(commentWriter);
		comment.setWriterId(commentId);
		comment.setContent(content);
		
		if(request.getParameter("commentno")!=null) {
			int commentNo = Integer.parseInt(request.getParameter("commentno"));
			comment.setCommentNo(commentNo);
		}
			
		SBoardServiceImpl service = new SBoardServiceImpl();
		
		int res;
		if(sort.equals("add")) {		
			res = service.getInsertComment(comment);
			if(res>0) System.out.println("댓글 추가 완료");
		}else if(sort.equals("del")) {
			res = service.getDeleteComment(comment);
			if(res>0) System.out.println("댓글 삭제 완료");
		}else if(sort.equals("update")) {
			res = service.getUpdateComment(comment);
			if(res>0) System.out.println("댓글 수정 완료");
		}
		
		// boardNo를 담은 객체
		BoardModel board = new BoardModel();
		board.setBoardNo(boardNo);
		board.setWriterId(commentId);
		
		// 코멘트 조회
		int commentCnt = service.getCntCommentByBoardNo(board);
		CommentModel viewComment = new CommentModel();
		if(commentCnt > 0) viewComment = service.getComment(board);
		
		Gson gson = new Gson();
		String jsonComment = gson.toJson(viewComment);
		
		out.append(jsonComment);		
	}

}
