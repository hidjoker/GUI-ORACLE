package board.service.a;

import java.util.List;

import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public interface ABoardService {

	// 총 게시글 수 조회
	public int getAllCnt(PagingModel paging);
	
	// 총 게시글 리스트 얻기
	public List<BoardModel> getPagingList(PagingModel paging);
	
	// 해당 게시글 추천수 얻기
	public int getRecommentCntByBoardNo(BoardModel board);
	
	// 게시글 입력하기
	public int getWriteBoard(BoardModel board);
	
	// 게시글 뷰 얻기
	public BoardModel getViewBoard(BoardModel board);
	
	// ID의 추천 여부 조회
	public boolean getSelectRecommendById(BoardModel board);
	
	// 댓글 리스트 얻기
	public List<CommentModel> getCommentList(BoardModel board);
	
	// 게시글 수정하기
	public int getUpdateBoard(BoardModel board);
	
	// 게시글 추천수 제거하기
	public int getRecommendAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 코멘트 제거하기
	public int getCommentsAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 삭제하기
	public int getDeleteBoard(BoardModel board);
	
	// 게시글 추천하기/추천 취소하기
	public boolean getRecommendBoard(BoardModel board);
	
	// 댓글 추가하기
	public int getInsertComment(CommentModel comment);
	
	// 댓글 삭제하기
	public int getDeleteComment(CommentModel comment);
	
}
