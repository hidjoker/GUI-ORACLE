package board.dao.f;

public interface FBoardDao {

}
