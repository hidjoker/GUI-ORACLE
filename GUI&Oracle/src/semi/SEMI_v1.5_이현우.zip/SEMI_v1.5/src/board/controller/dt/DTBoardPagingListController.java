package board.controller.dt;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.BoardModel;
import board.service.dt.DTBoardServiceImpl;
import board.util.PagingModel;

@WebServlet("/board/dt/pagingList.do")
public class DTBoardPagingListController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		// 현재 페이지 처리
		String param = request.getParameter("curPage");		
		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				request.getParameter("curPage") );
		}
		
		// 총 게시글 수 얻어서 paging 객체 생성
		String word = request.getParameter("word");
		
		if(word == null||word.equals("")) {
			word = "title";
		}		
		String search = request.getParameter("search");
		DTBoardServiceImpl service = new DTBoardServiceImpl();
		
		int totalCnt = service.getAllCnt(new PagingModel(search,word));		
		
		PagingModel paging = new PagingModel(totalCnt, curPage);
		paging.setSearch(search);
		paging.setWord(word);
		
		
		// 총 게시글 리스트 객체 얻기
		List<BoardModel> list = service.getPagingList(paging);
		
		// MODEL 객체에 담기
		request.setAttribute("paging", paging);
		request.setAttribute("boardList", list);
		
		request.getRequestDispatcher("/view/board/dt/dt_list.jsp")
				.forward(request, response);	
	}

}
