package board.service.q;

import java.util.List;

import board.dao.q.QBoardDaoImple;
import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public class QBoardServiceImpl implements QBoardService{

	QBoardDaoImple boardDao = new QBoardDaoImple();
	
	@Override
	public int getAllCnt(Paging paging) {
		String word = paging.getWord();
		int cnt = 0;
		if(word == null || word.equals("title")){
			cnt = boardDao.boardAllCntByTitle(paging);
		}else if(word.equals("boardNo")) {
			cnt = boardDao.boardAllCntByBoardNo(paging);
		}else if(word.equals("writer")) {
			cnt = boardDao.boardAllCntByWriter(paging);
		}else if(word.equals("writerId")) {
			cnt = boardDao.boardAllCntByWriterId(paging);
		}
		return cnt;
	}

	@Override
	public List<Board> getPagingList(Paging paging) {
		String word = paging.getWord();
		List<Board> list = null;
		if(word == null || word.equals("title")){
			list = boardDao.boardAllListByTitle(paging);
		}else if(word.equals("boardNo")) {
			list = boardDao.boardAllListByBoardNo(paging);
		}else if(word.equals("writer")) {
			list = boardDao.boardAllListByWriter(paging);
		}else if(word.equals("writerId")) {
			list = boardDao.boardAllListByWriterId(paging);
		}
		return list;
	}

	@Override
	public int getWriteBoard(Board board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public Board getViewBoard(Board board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public List<Comment> getCommentList(Board board) {
		return boardDao.commentList(board);
	}

	@Override
	public int getCommentsAllDeleteByBoardNo(Board board) {
		return boardDao.commentsAllDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(Board board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public int getInsertComment(Comment comment) {
		return boardDao.insertComment(comment);
	}

	@Override
	public int getDeleteComment(Comment comment) {
		return boardDao.deleteComment(comment);
	}

	@Override
	public void getRecommendComment(Comment comment) {
		boolean res = boardDao.selectRecommendCommentById(comment);
		if(!res) {
			int r = boardDao.insertRecommendComment(comment);
			if(r>0) System.out.println("댓글 추천 완료!");
			
		}else{
			int r = boardDao.deleteRecommendComment(comment);
			if(r>0) System.out.println("댓글 추천취소 완료!");
		}
	}

	@Override
	public int getAllRecommendDeleteByBoardNo(Board board) {
		return boardDao.allRecommendDeleteByBoardNo(board);
	}

	@Override
	public int getAllRecommendDeleteByCommentNo(Comment comment) {
		return boardDao.allRecommendDeleteByCommentNo(comment);
	}

}
