package board.dao.s;

public class SBoardDaoImpl implements SBoardDao{

}
