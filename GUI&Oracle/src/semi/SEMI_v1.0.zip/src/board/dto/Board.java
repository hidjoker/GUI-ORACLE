package board.dto;

public class Board {

}
