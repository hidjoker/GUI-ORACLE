package board.controller.dt;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.BoardModel;
import board.dto.BoardFileModel;
import board.service.dt.DTBoardServiceImpl;


@WebServlet("/board/dt/delete.do")
public class DTBoardDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		BoardModel board = new BoardModel();
		board.setBoardNo(boardNo);
						
		DTBoardServiceImpl service = new DTBoardServiceImpl();
		
		//게시글 첨부파일 삭제
		List<BoardFileModel> list = service.getFileList(board);
		for(BoardFileModel boardFile : list) {
			String fileName = boardFile.getAfter();
			System.out.println(fileName);
			File file = new File(getServletContext().getRealPath("/view/board/upload"),fileName);
			System.out.println("(전) 파일 존재 여부:"+file.exists());
			file.delete();
			System.out.println("(후) 파일 존재 여부:"+file.exists());
		}
		
		int res = service.getFilesAllDeleteByBoardNo(board);
		if(res>0) System.out.println("파일DB 삭제 완료");
		
		
		//게시글 삭제
		res = service.getDeleteBoard(board);
		if(res>0) System.out.println("게시글 삭제 성공");	

		
		response.sendRedirect("/board/ds/pagingList.do");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
