package member.service;

import member.dto.Member;

public class MemberServiceImpl implements MemberService{

	@Override
	public Member login(Member member) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean join(Member member) {
		// TODO Auto-generated method stub
		return false;
	}

}
