package board.dao.dt;

import java.util.List;

import board.dto.BoardModel;
import board.dto.BoardFileModel;
import board.util.PagingModel;

public interface DTBoardDao {
	
	// upload boardNo 조회(ALL)
	public int uploadBoardNo();
	
	// 총 게시글 수 조회(+제목)
	public int boardAllCntByTitle(PagingModel paging);
	
	// 총 게시글 수 조회(글번호)
	public int boardAllCntByBoardNo(PagingModel paging);
	
	
	// 총 게시글 리스트 조회(+제목)
	public List<BoardModel> boardAllListByTitle(PagingModel paging);
	
	// 총 게시글 리스트 조회(글번호)
	public List<BoardModel> boardAllListByBoardNo(PagingModel paging);
	
	// 게시글 추가
	public int insertBoard(BoardModel board);
	
	// 게시글 뷰 얻기
	public BoardModel viewBoard(BoardModel board);
	
	// 게시글 수정하기
	public int updateBoard(BoardModel board);
	
	// 게시글 조회수 +1
	public void addHit(BoardModel board);
	
	// 게시글 첨부파일 제거하기
	public int filesAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 삭제하기
	public int deleteBoard(BoardModel board);

	// 파일 추가하기
	public int insertFile(BoardFileModel file);
	
	// 파일 리스트 얻기
	public List<BoardFileModel> fileList(BoardModel board);
	
}
