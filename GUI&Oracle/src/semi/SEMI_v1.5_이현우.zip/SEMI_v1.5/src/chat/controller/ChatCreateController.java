package chat.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import chat.dto.Chan;
import chat.service.ChatService;


@WebServlet("/chat/create.do")
public class ChatCreateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();
		String chanName = request.getParameter("createchanname");
		String sessionId = (String)request.getSession().getAttribute("id");
		ChatService cs = new ChatService();
		Chan ch = new Chan();
		ch.setName(chanName);
		ch.setHostid(sessionId);
		
		String result = cs.create(ch);
		out.println(result); //초대 코드 확인용
		
	}

}
