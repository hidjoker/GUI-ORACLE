package board.service.q;

import java.util.List;

import board.dao.q.QBoardDaoImple;
import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public class QBoardServiceImpl implements QBoardService{

	QBoardDaoImple boardDao = new QBoardDaoImple();
	
	@Override
	public int getAllCnt(Paging paging) {
		return boardDao.boardAllCnt(paging);
	}

	@Override
	public List<Board> getPagingList(Paging paging) {
		return boardDao.boardAllList(paging);
	}

	@Override
	public int getWriteBoard(Board board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public Board getViewBoard(Board board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public List<Comment> getCommentList(Board board) {
		return boardDao.commentList(board);
	}

	@Override
	public int getCommentsAllDeleteByBoardNo(Board board) {
		return boardDao.commentsAllDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(Board board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public int getInsertComment(Comment comment) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDeleteComment(Comment comment) {
		// TODO Auto-generated method stub
		return 0;
	}

}
