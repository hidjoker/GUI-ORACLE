package board.controller.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import board.dto.Board;
import board.dto.BoardFile;
import board.dto.Comment;
import board.service.ds.DSBoardServiceImpl;


@WebServlet("/board/ds/view.do")
public class DSBoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		HttpSession session = request.getSession();
		String writerId = (String)session.getAttribute("logId");

		DSBoardServiceImpl service = new DSBoardServiceImpl();
		
		// boardno를 담은 객체
		Board board = new Board();
		board.setBoardNo(boardNo);
		board.setWriterId(writerId);
		
		// 보드 조회
		Board viewBoard = service.getViewBoard(board);
				
		// 추천 조회	
		boolean res = service.getSelectRecommendById(board);
		viewBoard.setChkRecommend(res);
		
		// 코멘트 조회
		List<Comment> commentList = new ArrayList<>();
		commentList = service.getCommentList(board);
		
		// 첨부파일 조회
		List<BoardFile> fileList = service.getFileList(board);
		
		
		request.setAttribute("board", viewBoard);
		request.setAttribute("comment", commentList);
		request.setAttribute("file", fileList);
		
		session.setAttribute("boardNo", boardNo); //Multipart전송시 boardno사용하기 위함
		
		System.out.println("fileList 사이즈:"+fileList.size());
	
		request.getRequestDispatcher("/view/board/ds/ds_view.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
				
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		String commentWriter = request.getParameter("commentwriter");
		String commentId = request.getParameter("commentid");
		String content = request.getParameter("content");
		String sort = request.getParameter("sort");
			
		Comment comment = new Comment();
		comment.setBoardNo(boardNo);
		comment.setWriter(commentWriter);
		comment.setWriterId(commentId);
		comment.setContent(content);
		
		DSBoardServiceImpl service = new DSBoardServiceImpl();
		
		int res;
		if(sort.equals("add")) {		
			res = service.getInsertComment(comment);
			if(res>0) System.out.println("댓글 추가 완료");
		}else if(sort.equals("del")) {
			int commentNo = Integer.parseInt(request.getParameter("commentno"));
			comment.setCommentNo(commentNo);
			res = service.getDeleteComment(comment);
			if(res>0) System.out.println("댓글 삭제 완료");
		}
		
		// boardNo를 담은 객체
		Board board = new Board();
		board.setBoardNo(boardNo);
		board.setWriterId(commentId);
		
		List<Comment> list = new ArrayList<>();
		list = service.getCommentList(board);
		
		Gson gson = new Gson();
		String gsonList = gson.toJson(list);
		
		PrintWriter out = response.getWriter();
		out.append(gsonList);
	}

}
