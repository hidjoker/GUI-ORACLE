package chat.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import chat.service.ChatService;

@WebServlet("/chat/proc.do")
public class ChatProcController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("application/json;charset=UTF-8");

		PrintWriter out = response.getWriter();
		ChatService cs = new ChatService();
		//-----------------응답 환경 설정--------------------------
		JsonObject obj = new JsonObject();//전송용 JSON
		JsonArray chatArr = new JsonArray();// 채팅내용 Array
		
		
		String time = request.getParameter("date");//마지막요청시간
		String chancode = request.getParameter("chan");//요청 채널 코드
		String text = "";
		List<String> result = cs.proc(time,chancode); //마지막 요청시간 이후 데이터 요청
		Iterator<String> itr = result.iterator();//반환값 iterator
		
		while (itr.hasNext()) {
			JsonObject chat = new JsonObject();
			String[] msg = itr.next().split("_");
			chancode = msg[0];
			time = msg[msg.length - 1];
			text = msg[msg.length - 2];
			
			chat.addProperty("chan", chancode);
			chat.addProperty("name", text.split(">>")[0]);
			chat.addProperty("msg", text.split(">>")[1].replaceAll("&#39", "'").replace( "&#170", ">>").replace( "&#171", "_"));

			chatArr.add(chat);
		} // While end

		obj.add("data", chatArr); // 배열에 채팅 내용 추가
		obj.addProperty("date", time);// 마지막 채팅 내용 시간 설정

		out.println(new Gson().toJson(obj));//{data:채팅배열 /date:로드 시간}

	}

}
