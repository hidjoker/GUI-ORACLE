package board.dao.a;

public class ABoardDaoImpl implements ABoardDao {

}
