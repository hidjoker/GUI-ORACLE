package admin.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.service.AdminService;
import admin.service.AdminServiceImpl;

@WebServlet("/admin/class.do")
public class adminClass_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
	
			AdminService service = new AdminServiceImpl();
				//대시보드
				request.setAttribute("menu", request.getParameter("menu"));
				
				//테이블 리스트
				List list= service.viewClass();
				
		
				request.setAttribute("List", list);
		
		request.getRequestDispatcher("/admin/adminClass.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
