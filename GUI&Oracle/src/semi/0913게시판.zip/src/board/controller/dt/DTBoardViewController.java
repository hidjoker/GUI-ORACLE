package board.controller.dt;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.BoardModel;
import board.dto.BoardFileModel;
import board.service.dt.DTBoardServiceImpl;

@WebServlet("/board/dt/view.do")
public class DTBoardViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		HttpSession session = request.getSession();
		String writerId = (String)session.getAttribute("id");

		DTBoardServiceImpl service = new DTBoardServiceImpl();
		
		// boardno를 담은 객체
		BoardModel board = new BoardModel();
		board.setBoardNo(boardNo);
		board.setWriterId(writerId);
		
		// 보드 조회
		BoardModel viewBoard = service.getViewBoard(board);
		
		// 첨부파일 조회
		List<BoardFileModel> fileList = service.getFileList(board);
		
		
		request.setAttribute("board", viewBoard);
		request.setAttribute("file", fileList);
		
		session.setAttribute("boardNo", boardNo); //Multipart전송시 boardno사용하기 위함
		
		System.out.println("fileList 사이즈:"+fileList.size());
	
		request.getRequestDispatcher("/view/board/dt/dt_view.jsp")
			.forward(request, response);
	
	}

}
