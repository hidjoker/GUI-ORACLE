package board.service.s;

public class SBoardServiceImpl {

}
