package admin.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import admin.dao.AdminDao;
import admin.service.AdminService;
import admin.service.AdminServiceImpl;

/**
 * Servlet implementation class adminPage
 */
@WebServlet("/admin.do")
public class adminMain_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

	
		AdminService service = new AdminServiceImpl();
		
		
		//전체 클래스 수
		int Cstotal=service.ClassSelect();
		request.setAttribute("Cstotal", Cstotal);

		//전체 학생 수
		int Sttotal=service.StudentSelect();
		request.setAttribute("Sttotal", Sttotal);
	
		//전체 강사 수
		int Tetotal=service.TeacherSelect();
		request.setAttribute("Tetotal", Tetotal);
			
		//가운데 카드
		List list= service.viewClass();
		request.setAttribute("List", list);
		
		//대시보드
		request.setAttribute("menu", request.getParameter("menu"));
		
		request.getRequestDispatcher("/admin/adminMain_body.jsp").forward(request, response);
		
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		
	}

}
