package board.dto;

import java.util.Date;

public class Upload {

	private int fileno;
	private int boardno;
	private String before;
	private String after;
	private int filesize;
	private Date uploaddate;
	
	@Override
	public String toString() {
		return "Upload [fileno=" + fileno + ", boardno=" + boardno + ", before=" + before + ", after=" + after + ",filesize=" + filesize
				+ ", uploaddate=" + uploaddate + "]";
	}

	public int getFileno() {
		return fileno;
	}

	public void setFileno(int fileno) {
		this.fileno = fileno;
	}

	public int getBoardno() {
		return boardno;
	}

	public void setBoardno(int boardno) {
		this.boardno = boardno;
	}

	public String getBefore() {
		return before;
	}

	public void setBefore(String before) {
		this.before = before;
	}

	public String getAfter() {
		return after;
	}

	public void setAfter(String after) {
		this.after = after;
	}

	public int getFilesize() {
		return filesize;
	}

	public void setFilesize(int filesize) {
		this.filesize = filesize;
	}

	public Date getUploaddate() {
		return uploaddate;
	}

	public void setUploaddate(Date uploaddate) {
		this.uploaddate = uploaddate;
	}
	
	
}
