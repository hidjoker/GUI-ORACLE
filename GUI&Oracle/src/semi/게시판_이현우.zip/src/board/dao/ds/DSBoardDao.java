package board.dao.ds;

import java.util.List;

import board.dto.BoardModel;
import board.dto.BoardFileModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public interface DSBoardDao{
	
	// upload boardNo 조회(ALL)
	public int uploadBoardNo();
	
	// 총 게시글 수 조회(+제목)
	public int boardAllCntByTitle(PagingModel paging);
	
	// 총 게시글 수 조회(글번호)
	public int boardAllCntByBoardNo(PagingModel paging);
	
	// 총 게시글 수 조회(작성자)
	public int boardAllCntByWriter(PagingModel paging);
	
	// 총 게시글 수 조회(작성자ID)
	public int boardAllCntByWriterId(PagingModel paging);
	
	// 총 게시글 리스트 조회(+제목)
	public List<BoardModel> boardAllListByTitle(PagingModel paging);
	
	// 총 게시글 리스트 조회(글번호)
	public List<BoardModel> boardAllListByBoardNo(PagingModel paging);
	
	// 총 게시글 리스트 조회(작성자)
	public List<BoardModel> boardAllListByWriter(PagingModel paging);
	
	// 총 게시글 리스트 조회(작성자ID)
	public List<BoardModel> boardAllListByWriterId(PagingModel paging);
	
	// 게시글의 추천수 조회
	public int recommendCntByBoardNo(BoardModel board);
	
	// 게시글 추가
	public int insertBoard(BoardModel board);
	
	// 게시글 뷰 얻기
	public BoardModel viewBoard(BoardModel board);
	
	// Id의 추천 여부 조회
	public boolean selectRecommendById(BoardModel board);
	
	// 댓글 리스트 얻기
	public List<CommentModel> commentList(BoardModel board);
	
	// 게시글 수정하기
	public int updateBoard(BoardModel board);
	
	// 게시글 조회수 +1
	public void addHit(BoardModel board);
	
	// 게시글 추천 제거하기
	public int recommendAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 코멘트 제거하기
	public int commentsAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 첨부파일 제거하기
	public int filesAllDeleteByBoardNo(BoardModel board);
	
	// 게시글 삭제하기
	public int deleteBoard(BoardModel board);
	
	// 추천수 추가하기
	public int insertRecommend(BoardModel board);
	
	// 추천수 제거하기
	public int deleteRecommend(BoardModel board);
	
	// 댓글 추가하기
	public int insertComment(CommentModel comment);
	
	// 댓글 삭제하기
	public int deleteComment(CommentModel comment);

	// 파일 추가하기
	public int insertFile(BoardFileModel file);
	
	// 파일 리스트 얻기
	public List<BoardFileModel> fileList(BoardModel board);
	
	// 댓글 수 얻기
	public int commentCntByBoardNo(BoardModel board);

}
