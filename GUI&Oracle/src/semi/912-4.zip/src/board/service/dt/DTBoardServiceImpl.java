package board.service.dt;

import java.util.List;

import board.dao.dt.DTBoardDaoImpl;
import board.dto.BoardModel;
import board.dto.BoardFileModel;
import board.util.PagingModel;

public class DTBoardServiceImpl implements DTBoardService{

	DTBoardDaoImpl boardDao = new DTBoardDaoImpl();

	@Override
	public int getUploadBoardNo() {
		return boardDao.uploadBoardNo();
	}

	@Override
	public int getAllCnt(PagingModel paging) {
		String word = paging.getWord();
		int cnt = 0;
		if(word == null || word.equals("title")) {
			cnt = boardDao.boardAllCntByTitle(paging);
		}else if(word.equals("boardNo")) {
			cnt = boardDao.boardAllCntByBoardNo(paging);
		}
		return cnt;
	}

	@Override
	public List<BoardModel> getPagingList(PagingModel paging) {
		
		String word = paging.getWord();
		
		List<BoardModel> list = null;
		if(word == null || word.equals("title")){
			list = boardDao.boardAllListByTitle(paging);

		}else if(word.equals("boardNo")) {
			list = boardDao.boardAllListByBoardNo(paging);
		}
		return list;
	}

	@Override
	public int getWriteBoard(BoardModel board) {
		return boardDao.insertBoard(board);				
	}

	@Override
	public BoardModel getViewBoard(BoardModel board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public int getUpdateBoard(BoardModel board) {
		return boardDao.updateBoard(board);
	}

	@Override
	public int getFilesAllDeleteByBoardNo(BoardModel board) {
		return boardDao.filesAllDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(BoardModel board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public int getInsertFile(BoardFileModel file) {
		return boardDao.insertFile(file);
	}

	@Override
	public List<BoardFileModel> getFileList(BoardModel board) {
		return boardDao.fileList(board);

	}

	

}
