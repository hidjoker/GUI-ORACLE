package board.controller.a;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.Board;
import board.service.a.ABoardServiceImpl;
import board.util.Paging;

@WebServlet("/board/a/pagingList.do")
public class ABoardPagingListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		// 로그인 세션 처리(초기값) - 관리자
		session.setAttribute("logIn", true);
		session.setAttribute("logName", "관리자");
		session.setAttribute("logId", "admin");				
		
		// 로그인 세션 처리(초기값) - 강사
//		session.setAttribute("logIn", true);
//		session.setAttribute("logName", "강사");
//		session.setAttribute("logId", 2);
//		
//		// 로그인 세션 처리(초기값) - 학생
//		session.setAttribute("logIn", true);
//		session.setAttribute("logName", "학생");
//		session.setAttribute("logId", "student");
//		
//		// 로그인 세션 처리(초기값) - 비로그인
//		session.setAttribute("logIn", false);
					
		// 현재 페이지 처리
		String param = request.getParameter("curPage");		
		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				request.getParameter("curPage") );
		}
		
		// 총 게시글 수 얻어서 paging 객체 생성
		String word = request.getParameter("word");
		String search = request.getParameter("search");
		ABoardServiceImpl service = new ABoardServiceImpl();
		
		int totalCnt = 0;
		
		if(word==null ||word.equals("title")){
			totalCnt = service.getAllCnt(new Paging(search));		
		}else if(word.equals("writer")){
//			totalCnt = service.getAllCntByWriter(new Paging(search));
		}else if(word.equals("writerId")){
//			totalCnt = service.getAllCntById(new Paging(search));
		}else if(word.equals("boardNo")){
//			totalCnt = service.getAllCntByBoardNo(new Paging(search));
		}
		
		Paging paging = new Paging(totalCnt, curPage);
		paging.setSearch(search);
		
		// 총 게시글 리스트 객체 얻기
		List<Board> list = service.getPagingList(paging);
		
		// MODEL 객체에 담기
		request.setAttribute("paging", paging);
		request.setAttribute("boardList", list);
		
		request.getRequestDispatcher("/view/board/a/a_list.jsp")
			.forward(request, response);
				
		
	}

}
