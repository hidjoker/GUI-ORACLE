package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBConn;
import board.dto.Board;
import board.dto.Upload;
import board.util.Paging;

public class BoardDaoImpl implements BoardDao {

	// DB 연결 객체
	private Connection conn = DBConn.getConnection();

	// JDBC 객체
	private PreparedStatement ps;
	private ResultSet rs;

	// 해당 테이블 전체 조회
	@Override
	public List selectAll(String boardType) {
		String sql = "SELECT * FROM board where boardtype=? and enable = 1 ORDER BY boardno desc";

		List boardList = new ArrayList();
		try {
			// PreparedStatement 생성
			ps = conn.prepareStatement(sql);
			ps.setString(1, boardType);

			// ResultSet 반환
			rs = ps.executeQuery();

			while (rs.next()) {
				Board board = new Board();

				board.setBoardno(rs.getInt(1));
				board.setWriterid(rs.getString(2));
				board.setWriter(rs.getString(3));
				board.setTitle(rs.getString(4));
				board.setContent(rs.getString(5));
				board.setHit(rs.getInt(6));
				board.setBoardtype(rs.getString(7));
				board.setEnable(rs.getInt(8));
				board.setIndate(rs.getDate(9));

				boardList.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return boardList;
	}

	// 총 게시글 수 조회
	@Override
	public int selectCntAll(String boardType) {
		String sql = "SELECT count(*) FROM board where boardtype=? and enable = 1";
		
		int cnt = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, boardType);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return cnt;
	}

	// 해당 게시글 총개수
	@Override
	public int selectCntAllSearch(String search, String boardType) {
		String sql = "SELECT count(*) FROM board WHERE boardtype=? and title LIKE '%'||?||'%' and enable = 1";

		int cnt = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, boardType);
			ps.setString(2, search);
			rs = ps.executeQuery();
			rs.next();
			cnt = rs.getInt(1);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return cnt;
	}

	// 페이징 리스트 조회
	@Override
	public List<Board> selectPagingList(Paging paging, String boardType) { // ,String boardType (게시판 이름)
		String sql = "SELECT * FROM (" + "	SELECT rownum rnum, B.* FROM (" + "		SELECT" + "	boardno,"
				+ "		title," + "		writerid," + "		writer," + "		content," + "	hit,"
				+ "		(SELECT COUNT(*) FROM board_recommend WHERE boardno=board.boardno) AS recommendCount," + "	indate, boardType"
				+ "		FROM board" + "		WHERE ENABLE= 1 and boardType=? ORDER BY boardno DESC" + "	) B"
				+ "	ORDER BY boardno DESC " + " )" + " WHERE rnum BETWEEN ? AND ?";
							//recommendCount
		List boardList = new ArrayList();
		try {
			ps = conn.prepareStatement(sql);

			ps.setString(1, boardType);
			ps.setInt(2, paging.getStartNo());
			ps.setInt(3, paging.getEndNo());
			
			// ResultSet 반환
			rs = ps.executeQuery();

			while (rs.next()) {
				Board board = new Board();

				board.setBoardno(rs.getInt("boardno"));
				board.setTitle(rs.getString("title"));
				board.setWriterid(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setRecommend(selectTotalRecommend(board));
				board.setIndate(rs.getDate("indate"));

				boardList.add(board);
				
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
//		System.out.println("board size : " +boardType+ "  =  "+boardList.size()+ " 개  ");
		return boardList;
	}

	// 페이징 리스트 검색
	@Override
	public List selectPagingListSearch(Paging paging, String boardType) {
		String sql = "SELECT * FROM (" + "	SELECT rownum rnum, B.* FROM (" + "		SELECT" + "		boardno,"
		+ "	title," + "	writerid," + "	writer," + "	content," + "hit,"
		+ "	(SELECT COUNT(*) FROM board_recommend WHERE boardno=board.boardno)," + "		indate"
		+ "	FROM board" + "	WHERE enable = 1 and boardtype=? AND title LIKE '%'||?||'%'"+"ORDER BY boardno DESC" + ") B"
		+ "	ORDER BY rnum" + " )" + " WHERE rnum BETWEEN ? AND ? ";

		List boardList = new ArrayList();
		try {
			ps = conn.prepareStatement(sql);

			ps.setString(1, boardType);
			ps.setString(2, paging.getSearch());
			ps.setInt(3, paging.getStartNo());
			ps.setInt(4, paging.getEndNo());

			// ResultSet 반환
			rs = ps.executeQuery();

			while (rs.next()) {
				Board board = new Board();

				board.setBoardno(rs.getInt("boardno"));
				board.setTitle(rs.getString("title"));
				board.setWriterid(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setRecommend(selectTotalRecommend(board));
				board.setIndate(rs.getDate("indate"));

				boardList.add(board);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		return boardList;
	}

	// 게시글 삽입
	@Override
	public void write(Board board) {
		String sql = "INSERT INTO board ( BOARDNO, TITLE, WRITERID, WRITER, CONTENT,BOARDTYPE, HIT)"
				+ " VALUES ( board_seq.nextval, ?, ?, ?, ?,?, 0)";

		try {
			ps = conn.prepareStatement(sql);

			ps.setString(1, board.getTitle());
			ps.setString(2, board.getWriterid());
			ps.setString(3, board.getWriter());
			ps.setString(4, board.getContent());
			ps.setString(5, board.getBoardtype());
			ps.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 게시글 조회
	@Override
	public Board selectBoardByBoardno(Board board) {
		String sql = "SELECT" + "	boardno," + "	title," + "	writerid," + "	writer," + "	content," + "	hit,"
				+ "	indate" + " FROM board" + " WHERE boardno=? and enable = 1";

		Board result = new Board();
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());

			rs = ps.executeQuery();

			while (rs.next()) {
				board.setBoardno(rs.getInt("boardno"));
				board.setTitle(rs.getString("title"));
				board.setWriterid(rs.getString("writerid"));
				board.setWriter(rs.getString("writer"));
				board.setContent(rs.getString("content"));
				board.setHit(rs.getInt("hit"));
				board.setRecommend(selectTotalRecommend(board));
				board.setIndate(rs.getDate("indate"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return board;
	}

	// 조회수 증가
	@Override
	public void updateHit(Board board) {
		String sql = "UPDATE board SET hit=hit+1 WHERE boardno = ?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	// 게시글 수정
	@Override
	public void update(Board board) {
		String sql = "UPDATE board SET title=?, content=? WHERE boardno=?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getTitle());
			ps.setString(2, board.getContent());
			ps.setInt(3, board.getBoardno());

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 게시글 삭제
	@Override
	public void delete(Board board) {
		String sql = "UPDATE board SET enable = 0 WHERE boardno=?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 리스트에서 게시글 삭제하기
	@Override
	public void deleteBoardList(String names) {
		String sql = "UPDATE board SET enable=0 WHERE boardno IN ( " + names + " )";

		try {
			ps = conn.prepareStatement(sql);

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 추천 수 구하기
	@Override
	public int selectCountRecommend(Board board) {
		String sql = "SELECT COUNT(*) FROM board_recommend WHERE id=? AND boardno=?";

		int cnt = 0;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getWriterid());
			ps.setInt(2, board.getBoardno());

			rs = ps.executeQuery();

			while (rs.next()) {
				cnt = rs.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return cnt;
	}

	// 추천 넣기
	@Override
	public void insertRecommend(Board board) {
		String sql = "INSERT INTO board_recommend (id, boardno) VALUES( ?, ? )";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getWriterid());
			ps.setInt(2, board.getBoardno());

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 추천 삭제
	@Override
	public void deleteRecommend(Board board) {
		String sql = "DELETE board_recommend WHERE id=? AND boardno=?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getWriterid());
			ps.setInt(2, board.getBoardno());

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 총 추천수 구하기
	@Override
	public int selectTotalRecommend(Board board) {
		String sql = "SELECT COUNT(*) FROM board_recommend WHERE boardno=?";

		int cnt = 0;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());

			rs = ps.executeQuery();

			while (rs.next()) {
				cnt = rs.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return cnt;
	}
	
	
	public void fileUpdate(Upload file, Board board) {
		String sql = "INSERT INTO upload ( FILENO, BOARDNO, BEFORE, AFTER, FILESIZE) VALUES ( upload_seq.NEXTVAL, ?, ?, ?, ? )";

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());
			ps.setString(2, file.getBefore());
			ps.setString(3, file.getAfter());
			ps.setInt(4, file.getFilesize());
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}


	// 첨부파일 업로드
	@Override
	public void insert(Upload file, int boardNo) {
		String sql = "INSERT INTO upload ( FILENO, BOARDNO, BEFORE, AFTER, FILESIZE) VALUES ( upload_seq.NEXTVAL, board_seq.currval, ?, ?, ? )";

		try {
			ps = conn.prepareStatement(sql);
			System.out.println("dao : "+ boardNo);
//			ps.setInt(1, boardNo);
			ps.setString(1, file.getBefore());
			ps.setString(2, file.getAfter());
			ps.setInt(3, file.getFilesize());
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 첨부파일 조회
	@Override
	public List<Upload> selectFileByBoardno(Board board) {
		String sql = "SELECT fileno, boardno, before, after, filesize FROM UPLOAD WHERE boardno = ?";
		List<Upload> list = new ArrayList<>();
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, board.getBoardno());

			rs = ps.executeQuery();

			while (rs.next()) {
				Upload file = new Upload();
				
				file.setFileno(rs.getInt("fileno"));
				file.setBefore(rs.getString("before"));
				file.setAfter(rs.getString("after"));
				file.setFilesize(rs.getInt("filesize"));

				list.add(file);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		return list;

	}
	
	@Override
	public void deleteFile(Integer fileNo) {
		String sql = "DELETE upload WHERE fileno=?";

		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, fileNo);

			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null)
					ps.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public Upload downFile(int fileNo) {
		String sql = "SELECT fileno, boardno, before, after FROM UPLOAD WHERE fileno = ?";
		
		Upload upload = new Upload();
		try {
			// PreparedStatement 생성
			ps = conn.prepareStatement(sql);
			ps.setInt(1, fileNo);

			// ResultSet 반환
			rs = ps.executeQuery();
			while (rs.next()) {
				upload.setFileno(rs.getInt(1));
				upload.setBoardno(rs.getInt(2));
				upload.setBefore(rs.getString(3));
				upload.setAfter(rs.getString(4));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return upload;
	}
	
}
