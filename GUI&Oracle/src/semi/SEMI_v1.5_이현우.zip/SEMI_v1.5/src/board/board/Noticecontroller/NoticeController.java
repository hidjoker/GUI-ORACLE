package board.board.Noticecontroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/notice/list.do")
public class NoticeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private BoardService boardService = new BoardServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 게시글 조회 결과
		List boardList = boardService.getList("notice");
		// JSP에 전달할 MODEL 처리
		request.setAttribute("boardList", boardList);

		// 포워딩
		request.getRequestDispatcher("/view/board.notice/list.jsp").forward(request, response);

	}
}
