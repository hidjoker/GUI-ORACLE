package board.service.q;

import java.util.List;

import board.dao.q.QBoardDaoImple;
import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public class QBoardServiceImpl implements QBoardService{

	QBoardDaoImple boardDao = new QBoardDaoImple();
	
	@Override
	public int getAllCnt(Paging paging) {
		return boardDao.boardAllCnt(paging);
	}

	@Override
	public List<Board> getPagingList(Paging paging) {
		return boardDao.boardAllList(paging);
	}

	@Override
	public int getWriteBoard(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Board getViewBoard(Board board) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Comment> getCommentList(Board board) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getUpdateBoard(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCommentsAllDeleteByBoardNo(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDeleteBoard(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getInsertComment(Comment comment) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDeleteComment(Comment comment) {
		// TODO Auto-generated method stub
		return 0;
	}

}
