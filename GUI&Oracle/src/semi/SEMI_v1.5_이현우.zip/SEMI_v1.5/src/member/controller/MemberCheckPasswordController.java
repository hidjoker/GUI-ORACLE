package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.dto.Member;
import member.service.MemberService;
import member.service.MemberServiceImpl;


@WebServlet("/member/checkPassword.do")
public class MemberCheckPasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService service = new MemberServiceImpl(); 

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/view/member/passwordCheck.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		HttpSession session  = request.getSession();
		
		String id = (String)session.getAttribute("id");
		String pw1= request.getParameter("pw1");
		

		
		PrintWriter out = response.getWriter();

		if( pw1=="") {
			System.out.println("비밀번호 입력 X"); 
			out.print("null");
		}
		else if(service.getPassword(id).equals(pw1)) {
			System.out.println("비밀번호 일치"); 
			out.print("true");

		}
		
		else {
			System.out.println("비밀번호 불일치");
			out.print("false");

		}
		
	}

}
