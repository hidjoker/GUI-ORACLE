package board.controller.q;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Board;
import board.service.q.QBoardServiceImpl;

@WebServlet("/board/q/delete.do")
public class QBoardDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int boardNo = Integer.parseInt(request.getParameter("boardno"));
		Board board = new Board();
		board.setBoardNo(boardNo);
		
		QBoardServiceImpl service = new QBoardServiceImpl();

		//게시글 코멘트 삭제
		int res = service.getCommentsAllDeleteByBoardNo(board);
		if(res>0) System.out.println("코멘트 삭제 성공");		
		
		//게시글 코멘트 추천 전부 삭제
		res = service.getCommentAllRecomendDelete(board);
		if(res>0) System.out.println("코멘트 추천 전부 삭제");
		
		//게시글 삭제
		res = service.getDeleteBoard(board);
		if(res>0) System.out.println("게시글 삭제 성공");
		
		response.sendRedirect("/board/q/pagingList.do");
				
	}

}
