package board.service.dt;

import java.util.List;

import board.dto.Board;
import board.dto.Comment;
import board.util.Paging;

public class DTBoardServiceImpl implements DTBoardService{

	@Override
	public int getAllCnt(Paging paging) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Board> getPagingList(Paging paging) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getRecommentCntByBoardNo(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getWriteBoard(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Board getViewBoard(Board board) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean getSelectRecommendById(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Comment> getCommentList(Board board) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getUpdateBoard(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRecommendAllDeleteByBoardNo(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCommentsAllDeleteByBoardNo(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDeleteBoard(Board board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean getRecommendBoard(Board board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getInsertComment(Comment comment) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDeleteComment(Comment comment) {
		// TODO Auto-generated method stub
		return 0;
	}

}
