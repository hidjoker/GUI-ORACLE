package board.controller.a;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.Board;
import board.service.a.ABoardServiceImpl;
import board.util.Paging;

@WebServlet("/board/a/pagingList.do")
public class ABoardPagingListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
//		// 로그인 세션 처리(초기값) - 관리자
		session.setAttribute("logIn", true);
		session.setAttribute("logName", "관리자");
		session.setAttribute("logId", "admin");			
//		
//		// 로그인 세션 처리(초기값) - 강사
//		session.setAttribute("logIn", true);
//		session.setAttribute("logName", "b-pm-0");
//		session.setAttribute("logId", 2);
		
		// 로그인 세션 처리(초기값) - 학생
//		session.setAttribute("logIn", true);
//		session.setAttribute("logName", "학생");
//		session.setAttribute("logId", "b-pm-2");
		
		// 로그인 세션 처리(초기값) - 비로그인
//		session.setAttribute("logIn", false);
		
		//Id에 따른 권한 부여
		String id = String.valueOf(session.getAttribute("logId"));		
		if(id.equals("admin")) {
			session.setAttribute("level", 2);
		}else{
			String[] arr = id.split("-");
			if(arr[2].equals("0")||arr[2].equals("1")) {
				session.setAttribute("level", 1);
			}else {
				session.setAttribute("level", 0);
			}			
		}	
		System.out.println(session.getAttribute("level").toString());
					
		// 현재 페이지 처리
		String param = request.getParameter("curPage");		
		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				request.getParameter("curPage") );
		}
		
		// 총 게시글 수 얻어서 paging 객체 생성
		String word = request.getParameter("word");
		if(word == null||word.equals("")) {
			word = "title";
		}
		String search = request.getParameter("search");
		ABoardServiceImpl service = new ABoardServiceImpl();
		
		int totalCnt = service.getAllCnt(new Paging(search,word));		
		
		Paging paging = new Paging(totalCnt, curPage);
		paging.setSearch(search);
		paging.setWord(word);
		
		// 총 게시글 리스트 객체 얻기
		List<Board> list = service.getPagingList(paging);		
		
		// MODEL 객체에 담기
		request.setAttribute("paging", paging);
		request.setAttribute("boardList", list);
		
		request.getRequestDispatcher("/view/board/a/a_list.jsp")
			.forward(request, response);
						
	}

}
