package admin.dto;

import java.util.Date;

public class AdminDto {

private String classname;
private String startdate;
private String enddate;
private String subject;
private int stuno;
private int total;
private String teacher;
private String jobteacher;
private String image;

@Override
public String toString() {
	return "AdminDto [classname=" + classname + ", startdate=" + startdate + ", enddate=" + enddate + ", subject="
			+ subject + ", stuno=" + stuno + ", total=" + total + ", teacher=" + teacher + ", jobteacher=" + jobteacher
			+ ", image=" + image + "]+테스트";
}
public String getClassname() {
	return classname;
}
public void setClassname(String classname) {
	this.classname = classname;
}
public String getStartdate() {
	return startdate;
}
public void setStartdate(String startdate) {
	this.startdate = startdate;
}
public String getEnddate() {
	return enddate;
}
public void setEnddate(String enddate) {
	this.enddate = enddate;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public int getStuno() {
	return stuno;
}
public void setStuno(int stuno) {
	this.stuno = stuno;
}
public int getTotal() {
	return total;
}
public void setTotal(int total) {
	this.total = total;
}
public String getTeacher() {
	return teacher;
}
public void setTeacher(String teacher) {
	this.teacher = teacher;
}
public String getJobteacher() {
	return jobteacher;
}
public void setJobteacher(String jobteacher) {
	this.jobteacher = jobteacher;
}
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}



}
