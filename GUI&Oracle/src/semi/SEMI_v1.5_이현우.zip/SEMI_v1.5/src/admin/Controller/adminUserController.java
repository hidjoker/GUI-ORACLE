package admin.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import admin.service.AdminService;
import admin.service.AdminServiceImpl;


@WebServlet("/admin/user.do")
public class adminUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
AdminService service = new AdminServiceImpl();
		
//클래스 리스트를 조회하고 리퀘스트에 넣는다
request.setAttribute("classlist",service.viewClass());		
//파라미터를 받아와서
String classname = request.getParameter("classname");
//유저리스트를 조회하고 리퀘스트에 넣는다
request.setAttribute("userlist", service.userinfoListVersion(classname));

//디스패처에 넣어준다.	
request.getRequestDispatcher("/admin/adminUser.jsp").forward(request, response);


	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		
		
		String classname = request.getParameter("classname");
		
		AdminService service = new AdminServiceImpl();
		JsonArray res = service.userinfo(classname);
		JsonObject obj = new JsonObject();
		obj.add("list",res);
		PrintWriter out = response.getWriter();
		
		out.print(new Gson().toJson(obj));
		
		
		
	}

}
