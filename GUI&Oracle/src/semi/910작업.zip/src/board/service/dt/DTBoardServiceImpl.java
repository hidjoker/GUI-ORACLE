package board.service.dt;

import java.util.List;

import board.dao.dt.DTBoardDaoImpl;
import board.dto.Board;
import board.dto.BoardFile;
import board.util.Paging;

public class DTBoardServiceImpl implements DTBoardService{

	DTBoardDaoImpl boardDao = new DTBoardDaoImpl();

	@Override
	public int getUploadBoardNo() {
		return boardDao.uploadBoardNo();
	}

	@Override
	public int getAllCnt(Paging paging) {
		String word = paging.getWord();
		int cnt = 0;
		if(word == null || word.equals("title")) {
			cnt = boardDao.boardAllCntByTitle(paging);
			System.out.println("널일떄"+cnt);
		}else if(word.equals("boardNo")) {
			cnt = boardDao.boardAllCntByBoardNo(paging);
		}
		return cnt;
	}

	@Override
	public List<Board> getPagingList(Paging paging) {
		
		String word = paging.getWord();
		
		List<Board> list = null;
		if(word == null || word.equals("title")){
			list = boardDao.boardAllListByTitle(paging);
			System.out.println("널일떄"+list.size());

		}else if(word.equals("boardNo")) {
			list = boardDao.boardAllListByBoardNo(paging);
		}
		return list;
	}

	@Override
	public int getWriteBoard(Board board) {
		return boardDao.insertBoard(board);				
	}

	@Override
	public Board getViewBoard(Board board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);
	}

	@Override
	public int getUpdateBoard(Board board) {
		return boardDao.updateBoard(board);
	}

	@Override
	public int getFilesAllDeleteByBoardNo(Board board) {
		return boardDao.filesAllDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(Board board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public int getInsertFile(BoardFile file) {
		return boardDao.insertFile(file);
	}

	@Override
	public List<BoardFile> getFileList(Board board) {
		return boardDao.fileList(board);

	}

	

}
