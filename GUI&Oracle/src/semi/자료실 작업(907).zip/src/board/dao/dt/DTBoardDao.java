package board.dao.dt;

public interface DTBoardDao {

}
