package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.mail.SendMailPw;
import member.service.MemberService;
import member.service.MemberServiceImpl;

@WebServlet("/member/searchpassword.do")
public class MemberFindPasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private MemberService service = new MemberServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String inputId = request.getParameter("inputId");
		String inputName = request.getParameter("inputName");
		String inputEmail = request.getParameter("inputEmail");
		
		String inputId1 =  inputId.toUpperCase();
		
		System.out.println(inputId1);
		System.out.println(inputName);
		
		
		PrintWriter out = response.getWriter();

		String ranPw = randomPw();
		
		
		
//		String result;
		
		if("".equals(inputId1) || ("".equals(inputName)) || ("".equals(inputEmail)) ||
				inputId1== null || inputName ==null || inputEmail == null) {
			out.print("null");
			System.out.println("빈칸!");
		}
		
		else if(service.searchPassword(inputId1, inputName, inputEmail) == null) {
			
			out.print("fail");	
			System.out.println("존재하지 않음!");
			
		}
		else {
			
			
			if (service.changePassword(ranPw, inputId1, inputName, inputEmail)) {
					System.out.println("비밀번호 찾기 성공");
					
					try {
						new SendMailPw(inputName, inputEmail, ranPw);
						out.print("이메일로 임시비밀번호가 전송되었습니다.");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				
			}
			else {
				System.out.println("비밀번호 찾기 실패");
				out.print("success");
			}
		}
		
		out.close();
	}
	
	
	// 임시비밀번호
	public static String randomPw(){ 
	      char pwCollection[] = new char[] { 
	                        '1','2','3','4','5','6','7','8','9','0', 
	                        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z', 
	                        'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z', 
	                        '!','@','#','$','%','^','&','*','(',')'};

	      String ranPw = ""; 

	      for (int i = 0; i < 10; i++) { 
	        int selectRandomPw = (int)(Math.random()*(pwCollection.length));
	        ranPw += pwCollection[selectRandomPw]; 
	      } 
	    return ranPw; 
	  

}

}
