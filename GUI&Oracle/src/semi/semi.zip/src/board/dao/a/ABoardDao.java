package board.dao.a;

public interface ABoardDao {

}
