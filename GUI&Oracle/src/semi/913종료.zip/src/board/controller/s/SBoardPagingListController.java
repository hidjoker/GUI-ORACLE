package board.controller.s;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import board.dto.BoardModel;
import board.service.s.SBoardServiceImpl;
import board.util.PagingModel;

@WebServlet("/board/s/pagingList.do")
public class SBoardPagingListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		//--------------------------------------------------------------		
//		session.invalidate();
		
		// 로그인 세션 처리(초기값) - 관리자
//		session.setAttribute("login", true);
//		session.setAttribute("name", "관리자");
//		session.setAttribute("id", "ADMIN");
//		session.setAttribute("admin", true);
//		
////		// 로그인 세션 처리(초기값) - 강사(0,1)
//		session.setAttribute("login", true);
//		session.setAttribute("name", "강사");
//		session.setAttribute("id", "B-PM-0");
//		session.setAttribute("teacher", true);
//		
//		// 로그인 세션 처리(초기값) - 학생(2~)
//		session.setAttribute("login", true);
//		session.setAttribute("name", "학생");
//		session.setAttribute("id", "B-PM-2");
//		session.setAttribute("student", true);		
//---------------------------------------------------------		
		
		// 현재 페이지 처리
		String param = request.getParameter("curPage");		
		int curPage = 0;
		if( !"".equals(param) && param != null ) {
			curPage = Integer.parseInt(
				request.getParameter("curPage") );
		}
		
		//Id에 따른 권한 부여
		String id = String.valueOf(session.getAttribute("id"));		
		System.out.println("id : "+id);
		if(id.equals("ADMIN")) {
			session.setAttribute("level", 2);
		}else{
			String[] arr = id.split("-");
			if(arr[arr.length-1].equals("0")||arr[arr.length-1].equals("1")) {
				session.setAttribute("level", 1);
			}else if(arr[arr.length-1].equals("null")){
				session.setAttribute("level", -1);
			}else {
				session.setAttribute("level", 0);
			}
		}	
		System.out.println(session.getAttribute("level").toString());
		
		// 총 게시글 수 얻어서 paging 객체 생성
		// 검색타입
		String word = request.getParameter("word");
		if(word == null||word.equals("")) {
			word = "title";
		}
		
		// 답변여부로 검색
		String answer = request.getParameter("answer");
		if(answer!=null && answer.equals("on")) {
			answer = "on";
		}else {
			answer = "off";
		}
		
		int level = Integer.parseInt(String.valueOf(session.getAttribute("level")));
		String search = request.getParameter("search");
		String logId = String.valueOf(session.getAttribute("id"));
		
		SBoardServiceImpl service = new SBoardServiceImpl();
		int totalCnt = service.getAllCnt(new PagingModel(search,word,level,logId,answer));
		
		PagingModel paging = new PagingModel(totalCnt, curPage);
		paging.setSearch(search);
		paging.setWord(word);
		paging.setLevel(level);
		paging.setLogId(logId);	
		paging.setAnswer(answer);
		
		// 총 게시글 리스트 객체 얻기
		List<BoardModel> list = service.getPagingList(paging);
		
		// MODEL 객체에 담기
		request.setAttribute("paging", paging);
		request.setAttribute("boardList", list);
		
		request.getRequestDispatcher("/view/board/s/s_list.jsp")
			.forward(request, response);
	}
}
