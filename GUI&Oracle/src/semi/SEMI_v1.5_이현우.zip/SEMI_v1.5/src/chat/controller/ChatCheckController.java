package chat.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import chat.dto.Chan;
import chat.service.ChatService;


@WebServlet("/chat/check.do")
public class ChatCheckController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String userid = (String)request.getSession().getAttribute("id");

		
		
		ChatService cs = new ChatService();
		JsonObject obj = new JsonObject();
		JsonArray chanArr = new JsonArray();
		List<Chan> result = cs.checkChan(userid);
		Iterator<Chan> itr = result.iterator();

		while(itr.hasNext()) {
			Chan ch = itr.next();
			JsonObject chan = new JsonObject();
			chan.addProperty("name", ch.getName());
			chan.addProperty("code", ch.getCode());
			
			chanArr.add(chan);
		}
		obj.add("chanList", chanArr);
		
		out.println(new Gson().toJson(obj));
		
	}

}
