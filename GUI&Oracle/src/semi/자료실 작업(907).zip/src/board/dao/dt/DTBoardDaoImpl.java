package board.dao.dt;

public class DTBoardDaoImpl implements DTBoardDao{

}
