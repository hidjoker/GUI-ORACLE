package board.service;

import java.util.List;

import board.dto.Board;
import board.util.Paging;

public interface BoardService {
	/**
	 * @param String BoardType //게시판 이름
	 * @return List<Board> // 보드 객체 리스트//
	 * 게시글 목록 불러오기
	 */
	public List<Board> getList(String boardType);
	/**
	 * 
	 * @param String BoardType // 게시판 이름
	 * @return int // 게시글  count//
	 * 총 게시글 갯수 불러오기
	 */
	public int getTotal(String boardType);
	/**
	 * @param Paging// 페이징 객체 
	 * @return List<Board> // 해당 페이지 게시글 리스트//
	 * 해당 페이지 게시글 목록 불러오기 
	 */
	public List<Board> getPagingList(Paging paging);
	/**
	 * 
	 * @param board //등록할 게시글 객체
	 * @return boolean // 성공여부//
	 * 게시글 등록하기
	 */
	public boolean insertBoard(Board board);
	/**
	 * 
	 * @param boardNo // 보여줄 게시글 번호
	 * @return Board // 보여줄 Board 객체//
	 * 게시글 상세보기
	 */
	public Board view(int boardNo);
	/**
	 * 
	 * @param board // 수정할 게시글 객체
	 * @return boolean //수정 성공 여부//
	 * 게시글 수정하기
	 */
	public boolean update(Board board);// 게시글 수정
	/**
	 * 
	 * @param board // 삭제할 게시글 객체 (Enable -> false 변경
	 * @return boolean //삭제 성공 여부//
	 * 게시글 삭제하기 ( Enable 컬럼 1-> 0  update하기 )
	 */
	public boolean delete(Board board);// 게시글 삭제
	/**
	 * 
	 * @param recommendBoard // 추천할 게시글 Board 객체
	 * @return boolean //추천 성공 여부//
	 * 게시글 추천 (AJAX 형태로 구현)
	 */
	public boolean recommend(Board recommendBoard);
	/**
	 * 
	 * @param board // 대상 게시글 객체
	 * @return int //게시글의 추천 수//
	 * 추천했을때  and 화면을 띄울떄 현재 추천수 불러오기
	 */
	public int recommendCnt(Board board);//게시글 추천수 불러오기

	/**
	 * @param board , (  ) 등록할 게시글 객체와 파일 객체 넘기기
	 * @return boolean 업로드 성공 여부 // 파일 업로드 하기
	 */
	public boolean uploadFile();
	
}
