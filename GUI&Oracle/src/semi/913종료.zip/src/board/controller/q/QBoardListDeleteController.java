package board.controller.q;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import board.dto.BoardModel;
import board.service.q.QBoardServiceImpl;

@WebServlet("/board/q/listDelete.do")
public class QBoardListDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		String jsonList = request.getParameter("chkList");
		Gson gson = new Gson();
		List list = gson.fromJson(jsonList,List.class);
		
		QBoardServiceImpl service = new QBoardServiceImpl();		
		for (Object boardNo : list) {
			int num = Integer.parseInt(String.valueOf(boardNo));
			BoardModel board = new BoardModel();
			board.setBoardNo(num);
			int res=0;
			//코멘트 추천 삭제
			res = service.getAllRecommendDeleteByBoardNo(board);
			if(res>0)System.out.println("코멘트 추천 삭제");
			//코멘트 삭제
			res = service.getCommentsAllDeleteByBoardNo(board);
			if(res>0)System.out.println("코멘트 삭제");
			//게시글 삭제
			res = service.getDeleteBoard(board);
			if(res>0)System.out.println("게시글 삭제");
		}
		
		response.sendRedirect("/board/q/pagingList.do");
		
	}

}
