package board.board.Noticecontroller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.dto.Upload;
import board.service.BoardService;
import board.service.BoardServiceImpl;


@WebServlet("/notice/download.do")
public class NoticeDownloadController extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private BoardService boardService = new BoardServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Integer fileNo = (request.getParameter("fileNo") != null ? Integer.parseInt(request.getParameter("fileNo").toString()) : 0);        
		
		Upload upload = boardService.downFile(fileNo);
		if (upload == null) {
			return;
		}
		
		String url = request.getRealPath("upload") + "\\" + upload.getBefore();  
		
		File file = new File(url);
		
		String fileName = new String(file.getName().getBytes("utf-8"), "iso-8859-1");
		
		
		
//		StringBuffer sb = new StringBuffer();
//		for (int i = 0; i < file.getName().length(); i++) {
//			char c = file.getName().charAt(i);
//			if (c > '~') {
//				sb.append(URLEncoder.encode("" + c, "UTF-8"));
//			} else {
//				sb.append(c);
//			}
//		}
//		
//		fileName = sb.toString();
		
		response.setContentType("application/download; UTF-8");
		response.setContentLength((int)file.length());
		response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\";");
		
		FileInputStream fis = new FileInputStream(file);
		BufferedInputStream bis = new BufferedInputStream(fis);
		ServletOutputStream so = response.getOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(so);
		
		byte[] data = new byte[2048];
		int input = 0;
		while ((input = bis.read(data)) != -1) {
			bos.write(data, 0, input);
			bos.flush();
		}
		
		if (bos != null) bos.close();
		if (bis != null) bis.close();
		if (so != null) so.close();
		if (fis != null) fis.close();
    }
}
