package board.service.a;

import java.util.List;

import board.dao.a.ABoardDaoImpl;
import board.dto.BoardModel;
import board.dto.CommentModel;
import board.util.PagingModel;

public class ABoardServiceImpl implements ABoardService{

	private ABoardDaoImpl boardDao = new ABoardDaoImpl();
	
	@Override
	public int getAllCnt(PagingModel paging) {
		String word = paging.getWord();
		int cnt = 0;
		if(word.equals("title")){
			cnt = boardDao.boardAllCntByTitle(paging);
		}else if(word.equals("boardNo")) {
			cnt = boardDao.boardAllCntByBoardNo(paging);
		}		
		return cnt;
	}

	@Override
	public List<BoardModel> getPagingList(PagingModel paging) {		
		String word = paging.getWord();
		List<BoardModel> list = null;
		if(word.equals("title")){
			list = boardDao.boardAllListByTitle(paging);
		}else if(word.equals("boardNo")) {
			list = boardDao.boardAllListByBoardNo(paging);
		}	
		return list;
	}

	@Override
	public int getRecommentCntByBoardNo(BoardModel board) {		
		return boardDao.recommendCntByBoardNo(board);
	}

	@Override
	public int getWriteBoard(BoardModel board) {
		return boardDao.insertBoard(board);
	}

	@Override
	public BoardModel getViewBoard(BoardModel board) {
		boardDao.addHit(board);
		return boardDao.viewBoard(board);	
	}

	@Override
	public boolean getSelectRecommendById(BoardModel board) {
		return boardDao.selectRecommendById(board);
	}

	@Override
	public List<CommentModel> getCommentList(BoardModel board) {
		return boardDao.commentList(board);
	}

	@Override
	public int getUpdateBoard(BoardModel board) {
		return boardDao.updateBoard(board);
	}

	@Override
	public int getRecommendAllDeleteByBoardNo(BoardModel board) {
		return boardDao.recommendAllDeleteByBoardNo(board);
	}

	@Override
	public int getCommentsAllDeleteByBoardNo(BoardModel board) {
		return boardDao.commentsAllDeleteByBoardNo(board);
	}

	@Override
	public int getDeleteBoard(BoardModel board) {
		return boardDao.deleteBoard(board);
	}

	@Override
	public boolean getRecommendBoard(BoardModel board) {
		boolean res = boardDao.selectRecommendById(board);
		if(!res) {
			int r = boardDao.insertRecommend(board);
			if(r>0) System.out.println("게시글 추천 완료!");
			
		}else {
			int r = boardDao.deleteRecommend(board);
			if(r>0) System.out.println("게시글 추천취소 완료!");
		}
		return res;
		
	}

	@Override
	public int getInsertComment(CommentModel comment) {
		return boardDao.insertComment(comment);
	}

	@Override
	public int getDeleteComment(CommentModel comment) {
		return boardDao.deleteComment(comment);
	}

}
