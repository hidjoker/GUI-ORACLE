 $(document).ready(function() {

		$("#confirm").click(function() {
			$(location).attr("href", "/main.do");
		});
		$("#update").click(function () {
			$(location).attr("href", "/member/updatemember.do");
		});
	});