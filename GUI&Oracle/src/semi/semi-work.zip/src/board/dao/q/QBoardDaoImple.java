package board.dao.q;

public class QBoardDaoImple implements QBoardDao{

}
