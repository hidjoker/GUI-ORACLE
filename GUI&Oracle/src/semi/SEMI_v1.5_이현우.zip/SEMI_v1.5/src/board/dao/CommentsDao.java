package board.dao;

import java.util.List;

import board.dto.Board;
import board.dto.Comments;

public interface CommentsDao {
	
	// 코멘트 조회 - 코멘트 번호를 rnum을 통해 같이 조회한다
	public List selectComment(Board board);
	
	// 코멘트 INSERT
	public void insertComment(Comments comment);

	// 댓글 삭제하기
	public void deleteComment(Comments comment);

	// 댓글 카운트 - 댓글 존재 여부 확인 
	public int countComment(Comments comment);

}
