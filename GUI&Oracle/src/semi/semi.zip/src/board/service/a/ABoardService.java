package board.service.a;

public interface ABoardService {

}
