package member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import DBUtil.DBConn;
import member.dto.Group;
import member.dto.Member;
import member.dto.MemberAndClass;

public class MemberDaoImpl implements MemberDao{
	
	private Connection conn = DBConn.getConnection();
	
	private PreparedStatement ps;
	private ResultSet rs;

	@Override
	public int login(Member member) {
		String sql = "SELECT count(*) FROM userdata"
				+ " WHERE id=?"
				+ "	 AND pw=?";
		int cnt = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, member.getId());
			ps.setString(2, member.getPassword());
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				cnt = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cnt;
	}
	
	@Override
	public String selectName(Member member) {
		String sql = "SELECT name FROM userdata"
				+ " WHERE id=?";
		
		String nick = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, member.getId());
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				nick = rs.getString(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return nick;
	}

	@Override
	public boolean join(Member member) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkId(String inputId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Member selectUserInfo(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberAndClass Info(String id) {
		String sql = "select u.id, u.pw, u.name, u.class, u.phone, u.birth " + 
				" , u.email, u.gender, " + 
				"  c.startdate, c.enddate, c.subject, c.stuno, c.total from class c, userdata u where"
				+ " u.class=c.classname and u.id = ? ";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if(rs.next()) {
				MemberAndClass dto = new MemberAndClass();
			
				String id1 = rs.getString("id");
				String password = rs.getString("pw");
				String name = rs.getString("name");
				String birthday = rs.getString("birth");
				String phone = rs.getString("phone");
				String group = rs.getString("class");
				String email = rs.getString("email");
				String gender = rs.getString("gender");
				String startdate = rs.getString("startdate");
				String enddate = rs.getString("enddate");
				String subject = rs.getString("subject");
				int stuno = rs.getInt("stuno");
				int total = rs.getInt("total");
				
				dto.setId(id1);
				dto.setPassword(password);
				dto.setName(name);
				dto.setBirthDay(birthday);
				dto.setPhone(phone);
				dto.setGroup(group);
				dto.setEmail(email);
				dto.setGender(gender);
				dto.setStartDate(startdate);
				dto.setEndDate(enddate);
				dto.setSubject(subject);
				dto.setStuNo(stuno);
				dto.setTotal(total);
	
				return dto;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally {
				try {
					if(rs!=null)	rs.close();
					if(ps!=null) 	ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}

	@Override
	public int update(Member member) {
		String sql ="update userdata set pw=?, name=?, birth=?, email=?, phone=? where id=?";
		
		try {
			ps = conn.prepareStatement(sql);
			
						
				ps.setString(1, member.getPassword());
				ps.setString(2, member.getName());
				ps.setString(3, member.getBirthDay());
				ps.setString(4, member.getEmail());
				ps.setString(5, member.getPhone());
				ps.setString(6, member.getId());

				int n = ps.executeUpdate();
			
			return n;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return -1;
		}
		finally {
			
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}

	@Override
	public int insertClass(Group group) {
		String sql="insert into class values(?,?,?,?,?)";
		
		try {
			ps=conn.prepareStatement(sql);
			
			ps.setString(1, "classname");
			ps.setString(2, "startdate");
			ps.setString(3, "enddate");
			ps.setString(4, "subject");
			ps.setString(5, "stuNo");
			
			int n = ps.executeUpdate();
			
			return n;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return -1;
			
		} finally {
			try {
				if(ps !=null) ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public MemberAndClass myPageInfo(String id) {
		String sql = "select u.id, u.name, u.class, u.phone, u.birth " + 
				" , u.email, u.gender, " + 
				"  c.startdate, c.enddate, c.subject from class c, userdata u where"
				+ " u.class=c.classname and u.id = ? ";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if(rs.next()) {
				MemberAndClass dto = new MemberAndClass();
			
				String id1 = rs.getString("id");
				String name = rs.getString("name");
				String birthday = rs.getString("birth");
				String phone = rs.getString("phone");
				String group = rs.getString("class");
				String email = rs.getString("email");
				String gender = rs.getString("gender");
				String startdate = rs.getString("startdate");
				String enddate = rs.getString("enddate");
				String subject = rs.getString("subject");

				
				dto.setId(id1);
				dto.setName(name);
				dto.setBirthDay(birthday);
				dto.setPhone(phone);
				dto.setGroup(group);
				dto.setEmail(email);
				dto.setGender(gender);
				dto.setStartDate(startdate);
				dto.setEndDate(enddate);
				dto.setSubject(subject);

	
				return dto;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally {
				try {
					if(rs!=null)	rs.close();
					if(ps!=null) 	ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}

	@Override
	public Member MemberInfo(String id) {
		{
			String sql = "select pw, name, class, phone, birth " + 
					" , email from userdata where id = ? ";
			try {
				ps = conn.prepareStatement(sql);
				ps.setString(1, id);
				rs=ps.executeQuery();
				if(rs.next()) {
					Member dto = new Member();
				
					String password=rs.getString("pw");
					String name = rs.getString("name");
					String birthday = rs.getString("birth");
					String phone = rs.getString("phone");
					String group = rs.getString("class");
					String email = rs.getString("email");


					dto.setPassword(password);
					dto.setName(name);
					dto.setBirthDay(birthday);
					dto.setPhone(phone);
					dto.setGroup(group);
					dto.setEmail(email);

					return dto;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}finally {
					try {
						if(rs!=null)	rs.close();
						if(ps!=null) 	ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return null;
		}
	}

	@Override
	public String userPassword(String id) {
		String sql = "SELECT pw FROM userdata"
				+ " WHERE id=?";
		
		String pw = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				pw = rs.getString(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return pw;
	}

	@Override
	public Member passwordSearch(String id, String name, String email) {
		
		String sql ="select * from userdata where id= ? and name =? and email =?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, name);
			ps.setString(3, email);
			
			rs=ps.executeQuery();
			if(rs.next()) {
				Member dto = new Member();
			
				String id1 = rs.getString("id");
				String password=rs.getString("pw");
				String name1 = rs.getString("name");
				String group = rs.getString("class");
				String birthday = rs.getString("birth");
				String phone = rs.getString("phone");
				String email1 = rs.getString("email");
				String gender = rs.getString("gender");


				dto.setPassword(password);
				dto.setName(name1);
				dto.setBirthDay(birthday);
				dto.setPhone(phone);
				dto.setGroup(group);
				dto.setEmail(email1);
				dto.setGender(gender);

				return dto;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally {
				try {
					if(rs!=null)	rs.close();
					if(ps!=null) 	ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}

	@Override
	public int changePassword(String pw,  String id, String name, String email) {

		String sql = "update userdata set pw =? where id=? and name =? and email=? ";
		
		try {
			ps = conn.prepareStatement(sql);
				
				ps.setString(1, pw);
				ps.setString(2, id);
				ps.setString(3, name);
				ps.setString(4, email);
				
				System.out.println("1"+ pw);
				System.out.println("2"+ id);
				
				

				int n = ps.executeUpdate();
			
			return n;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return -1;
		}
		finally {
			
				try {
					if(ps!=null) ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
	

	
	
	





}
