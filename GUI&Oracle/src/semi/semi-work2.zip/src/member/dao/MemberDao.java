package member.dao;

import member.dto.Member;

public interface MemberDao {
	/**
	 * 
	 * @param member // 로그인 요청 Member 객체
	 * @return Member // DB 검색 후 유저정보 반환 // 로그인 요청 응답
	 */
	public Member login(Member member);
	/**
	 * 
	 * @param member // 회원가입 요청 Member 객체
	 * @return boolean // 회원가입 성공 여부 // 회원가입 요청 응답
	 */
	public boolean join(Member member);
	/**
	 * @param String : inputId //중복확인 ID 값
	 * @return boolean // 중복 확인 여부 ( 이미 존재하는 아이디일 경우 false)
	 */
	public boolean checkId(String inputId);
}
