package admin.service;

import java.util.List;

import com.google.gson.JsonArray;

import admin.dto.AdminDto;
import admin.dto.AdminUserDto;

public interface AdminService {

	// 클래스  전체 수 조회
public int ClassSelect();
	

	// 학생 조회

public int StudentSelect();



	//강사 조회
public int TeacherSelect();


//클래스 정보 조회 
public List viewClass();


//클래스 뷰 조회

public AdminDto view(String classname);

//클래스 이미지 수정
public void imgmodify(String imgurl, String classname);

//클래스 생성
public boolean createClass(AdminDto dto);

//유저생성 - 클래스생성시 함께 
public int createUser(AdminDto dto);

//클래스 종강처리
public boolean classclose(String classname);

//유저 정보 조회
public JsonArray userinfo(String classname);

//유저 정보 조회 리스터버전
public List userinfoListVersion(String clssanme);

//클래스 정보 수정

public void classupdate(AdminDto dto);

//유저 정보 상세조회
public AdminUserDto userview(String userid);

//유저 삭제

public void deleteuser(String userid);


//유저 정보 업데이트

public void userUpdate(AdminUserDto dto);

}
